T = int(input())
while T > 0:
    m, x, y = [int(t) for t in input().split()]
    n = 1
    ept = True
    for i in range(m):
        xr = (x // n) % 5
        yr = (y // n) % 5
        if yr + abs(xr - 2) < 2:
            ept = False
            break
        n *= 5
    if ept:
        print("empty")
    else:
        print("crystal")
    T -= 1