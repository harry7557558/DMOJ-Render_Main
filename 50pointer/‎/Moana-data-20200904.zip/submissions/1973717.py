R, C = [int(t) for t in input().split()]
i0, j0 = [int(t) for t in input().split()]
i1, j1 = [int(t) for t in input().split()]
S = []
INF = float('inf')
for i in range(R):
    S.append([c for c in input()])
    for j in range(C):
        if S[i][j]=='O': S[i][j]=INF
T = [[False for i in range(C)] for j in range(R)]
Tn = int(input())
for t in range(Tn):
    i, j = input().split()
    T[int(i)][int(j)] = True

def dbgPrint(k):
    for i in range(R):
        for j in range(C):
            print(str(k[i][j])[0],end='')
        print()

S[i0][j0] = 0
while S[i1][j1] == INF:
    for i in range(R):
        for j in range(C):
            if S[i][j]!='X':
                if i>0 and S[i-1][j]!='X' and S[i-1][j]+1<S[i][j]: S[i][j]=S[i-1][j]+1
                if j>0 and S[i][j-1]!='X' and S[i][j-1]+1<S[i][j]: S[i][j]=S[i][j-1]+1
                if i+1<R and S[i+1][j]!='X' and S[i+1][j]+1<S[i][j]: S[i][j]=S[i+1][j]+1
                if j+1<C and S[i][j+1]!='X' and S[i][j+1]+1<S[i][j]: S[i][j]=S[i][j+1]+1
    #dbgPrint(S)
D0 = S[i1][j1]

for i in range(R):
    for j in range(C):
        if S[i][j]!='X':
            S[i][j]=INF
S[i0][j0] = 0
while S[i1][j1] == INF:
    for i in range(R):
        for j in range(C):
            if S[i][j]!='X' and S[i][j]!=INF:
                if T[i][j]:
                    S[i1][j1] = S[i][j]
                if i>0 and S[i-1][j]!='X' and S[i-1][j]>S[i][j]+1: S[i-1][j]=S[i][j]+1
                if j>0 and S[i][j-1]!='X' and S[i][j-1]>S[i][j]+1: S[i][j-1]=S[i][j]+1
                if i+1<R and S[i+1][j]!='X' and S[i+1][j]>S[i][j]+1: S[i+1][j]=S[i][j]+1
                if j+1<C and S[i][j+1]!='X' and S[i][j+1]>S[i][j]+1: S[i][j+1]=S[i][j]+1
    #dbgPrint(S)
D1 = S[i1][j1]
print(D0-D1)