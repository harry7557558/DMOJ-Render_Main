#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)

#define INF 0x7FFFFFFF

#ifdef __DEBUG

#include <chrono>

unsigned _IDUM = 0;
#define rand(a,b) ((_IDUM=1664525u*_IDUM+1013904223u)%(b-a)+a)

#define MAX_ELE 1000000000
void generateCase(int N, int M) {
	freopen("stdout.dat", "w", stdout);
	printf("%d %d\n", N, M);
	for (int i = 0; i < N; i++) printf("%d%c", rand(0, MAX_ELE) + 1, i == N - 1 ? '\n' : ' ');
	for (int i = 0; i < M; i++) {
		int cmd = rand(0, 2);
		if (cmd == 0) {
			int x = rand(0, N) + 1;
			int v = rand(0, MAX_ELE) + 1;
			printf("C %d %d\n", x, v);
		}
		else if (cmd == 1) {
			int l = rand(0, N) + 1;
			int r = rand(0, N) + 1;
			if (l > r) swap(l, r);
			printf("M %d %d\n", l, r);
		}
	}
	exit(0);
}

#endif


template<typename T> T gcd(T a, T b) {
	while (b) {
		T t = b;
		b = a % b;
		a = t;
	}
	return a;
}



int N;
int A[100000];


struct Node {
	int l, r;
	int Min = INF;
	Node *c1 = 0, *c2 = 0;
} R;

void initTree(Node *R, int l, int r) {
	R->l = l, R->r = r;
	if (r - l < 2) {
		for (int i = l; i < r; i++) {
			R->Min = min(R->Min, A[i]);
		}
		return;
	}
	int c = (l + r) / 2;
	R->c1 = new Node, R->c2 = new Node;
	initTree(R->c1, l, c);
	initTree(R->c2, c, r);
	R->Min = min(R->c1->Min, R->c2->Min);
}
void modifyTree(Node *R, int x, int v) {
	if (!(R->c1 || R->c2)) {
		R->Min = v; return;
	}
	if (x < R->c1->r) {
		modifyTree(R->c1, x, v);
		R->Min = min(R->c1->Min, R->c2->Min);
	}
	else {
		modifyTree(R->c2, x, v);
		R->Min = min(R->c1->Min, R->c2->Min);
	}
}

int qMin(Node *R, int l, int r) {
	if (l <= R->l && r >= R->r) return R->Min;
	if (r <= R->l || l >= R->r) return INF;
	if (R->c1 || R->c2) return min(qMin(R->c1, l, r), qMin(R->c2, l, r));
	return R->Min;
}


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	freopen("stdout.dat", "w", stdout);
	auto t0 = chrono::high_resolution_clock::now();
	//generateCase(100000, 100000);
#endif
	scanu(N);
	int M; scanu(M);
	for (int i = 0; i < N; i++) scanu(A[i]);
	initTree(&R, 0, N);
	while (M--) {
		char cmd; do; while ((cmd = getchar()) < 'A');
#if 0
		// bruteforce solution for reference
		if (cmd == 'C') {
			int x, v; scanu(x); scanu(v); x--;
			A[x] = v;
		}
		if (cmd == 'M') {
			int l, r; scanu(l); scanu(r); l--;
			int Min = INF;
			for (int i = l; i < r; i++) {
				if (A[i] < Min) Min = A[i];
			}
			printf("%d\n", Min);
		}
		if (cmd == 'G') {
			int l, r; scanu(l); scanu(r); l--;
			int Gcd = A[l];
			for (int i = l + 1; i < r; i++) {
				Gcd = gcd(Gcd, A[i]);
			}
			printf("%d\n", Gcd);
		}
		if (cmd == 'Q') {
			int l, r; scanu(l); scanu(r); l--;
			int Gcd = A[l];
			for (int i = l + 1; i < r; i++) {
				Gcd = gcd(Gcd, A[i]);
			}
			int Count = 0;
			for (int i = l; i < r; i++) {
				Count += A[i] == Gcd;
			}
			printf("%d\n", Count);
		}
#else
		if (cmd == 'C') {
			int x, v; scanu(x); scanu(v); x--;
			modifyTree(&R, x, v);
			A[x] = v;
		}
		if (cmd == 'M') {
			int l, r; scanu(l); scanu(r); l--;
			printf("%d\n", qMin(&R, l, r));
		}
		if (cmd == 'G') {
			int l, r; scanu(l); scanu(r); l--;
			int Gcd = A[l];
			for (int i = l + 1; i < r; i++) {
				Gcd = gcd(Gcd, A[i]);
			}
			printf("%d\n", Gcd);
		}
		if (cmd == 'Q') {
			int l, r; scanu(l); scanu(r); l--;
			int Gcd = A[l];
			for (int i = l + 1; i < r; i++) {
				Gcd = gcd(Gcd, A[i]);
			}
			int Count = 0;
			for (int i = l; i < r; i++) {
				Count += A[i] == Gcd;
			}
			printf("%d\n", Count);
		}
#endif
	}
#ifdef __DEBUG
	printf("%lfs elapsed\n", std::chrono::duration<double>(std::chrono::high_resolution_clock::now() - t0).count());
#endif
	return 0;
}