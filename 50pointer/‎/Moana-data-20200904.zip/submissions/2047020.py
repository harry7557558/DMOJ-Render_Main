def _(N):
    if N%2==0 or N%3==0: return False
    for i in range(4,int(N**.5),6):
        if N%(i+1)==0 or N%(i+3)==0: return False
    return True

print("2\n3*")
for i in range(5,int(input())): print(str(i)+'*\n' if _(i-2) or _(i+2) else str(i)+'\n' if _(i) else '',end='')