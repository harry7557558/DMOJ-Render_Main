#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

int A[10000], B[10000];

int main() {
#ifdef _DEBUG
	freopen("stdin.dat", "r", stdin);
#endif

	int N; cin >> N;
	for (int i = 0; i < N; i++) cin >> B[i];

	if (N == 3) {
		cout << B[0] << "\n0\n0\n";
		return 0;
	}

	if (N % 3) {
		A[0] = 0;
		for (int i = 0; i != N - 3; i = (i + 3) % N) {
			A[(i + 3) % N] = A[i] + B[(i + 2) % N] - B[(i + 1) % N];
		}
		long long int sA = 0, sB = 0;
		for (int i = 0; i < N; i++) sA += A[i], sB += B[i];
		int d = (sB / 3 - sA) / N;
		for (int i = 0; i < N; i++) cout << (A[i] + d) << endl;
		return 0;
	}

	{
		A[0] = A[1] = A[2] = 0;
		for (int i = 3; i < N; i++) A[i] = A[i - 3] + B[i - 1] - B[i - 2];
		long long int sA = 0, sB = 0;
		for (int i = 0; i < N; i++) sA += A[i], sB += B[i];
		int d = (sB - 3 * sA) / N;
		int m1 = 0, m2 = 0, m3 = 0;
		for (int i = 0; i < N; i += 3) {
			m1 = min(m1, A[i]);
			m2 = min(m2, A[i + 1]);
			m3 = min(m3, A[i + 2]);
		}
		d += m1 + m2 + m3;
		m1 = -m1 + d / 3, m2 = -m2 + d / 3, m3 = -m3 + d - 2 * (d / 3);
		for (int i = 0; i < N; i += 3) {
			cout << (A[i] + m1) << endl;
			cout << (A[i + 1] + m2) << endl;
			cout << (A[i + 2] + m3) << endl;
		}
		return 0;
	}

	return 0;
}