#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long int lint;

lint modInverse(lint a, lint m) {
	lint m0 = m;
	lint y = 0, x = 1;
	if (m == 1) return 0;
	while (a > 1) {
		lint q = a / m;
		lint t = m;
		m = a % m, a = t;
		t = y;
		y = (x + m0 - q * y) % m0;
		x = t;
	}
	if (x < 0) x += m0;
	return x % m0;
}


int main() {
	lint N, M; cin >> N >> M;
	cout << modInverse(N, M) << endl;
	return 0;
}