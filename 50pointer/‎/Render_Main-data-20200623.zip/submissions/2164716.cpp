#include <bits/stdc++.h>
using namespace std;

double c[1024];
int N;

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> N;
	for (int i = 0; i <= N; i++) {
		scanf("%lf", &c[i]);
	}
	printf("%lf\n", -c[1] / c[0] / N);
	return 0;
}