#include <bits/stdc++.h>
using namespace std;


typedef long long lint;
typedef long double ldouble;
#define inf 0x7FFFFFFF
#define INF 0x7FFFFFFFFFFFFFFF

lint Mod = INF;


lint pow(lint x, lint e, lint m) {
	lint r = 1;
	x %= m;
	while (e) {
		if (e & 1) r = (r*x) % m;
		if (e >>= 1) x = (x*x) % m;
	}
	return r;
}
lint modInverse(lint a, lint m) {
	lint m0 = m;
	lint y = 0, x = 1;
	if (m == 1) return 0;
	while (a > 1) {
		lint q = a / m;
		lint t = m;
		m = a % m, a = t;
		t = y;
		y = x - q * y;
		x = t;
	}
	return (x + m0) % m0;
}





lint catsum_bf(lint a, lint b, lint m) {
	lint e = 1, ans = 0;
	for (lint u = b; u >= a; u--) {
		ans = (ans + u * e) % Mod;
		e = e * m % Mod;
	}
	return ans;
}
lint catsum_mi(lint a, lint b, lint m) {
	lint n = b - a;
	lint mn = pow(m, n, Mod);
	lint r = ((m - 1)*(a*(m*mn%Mod) % Mod + Mod - b % Mod) % Mod + m * (mn - 1) % Mod) % Mod;
	lint d = modInverse((m - 1)*(m - 1) % Mod, Mod);
	return r * d % Mod;
}
lint catsum(lint a, lint b, lint m) {
	ldouble n = b - a;
	ldouble mn = powl(m, n);
	ldouble r = (m - 1.l)*(a*m*mn - b) + m * (mn - 1.l);
	ldouble d = 1.l / ((m - 1.l)*(m - 1.l));
	return lint(fmodl(r*d, Mod) + Mod) % Mod;
}

lint concat(lint N) {
	vector<pair<lint, lint>> v;
	lint m = 1;
	while (m <= N) {
		v.push_back(pair<lint, lint>(m, min(10 * m - 1, N)));
		m *= 10;
	}
	lint e = 0, ans = 0;
	for (int i = v.size() - 1; i >= 0; i--) {
		lint m = pow(10, i + 1, Mod);
		lint cat = catsum(v[i].first, v[i].second, m);
		m = pow(10, e, Mod);
		ans = (ans + cat * m) % Mod;
		e += (i + 1)*(v[i].second - v[i].first + 1);
	}
	return ans;
}



int main() {
#ifdef __DEBUG
	{
		Mod = 13;
		lint a = 10, b = 13, m = 9;
		cout << catsum(a, b, m) << " " << catsum_bf(a, b, m) << endl;
	}
	freopen("stdin.dat", "r", stdin);
#endif
	lint N;
	cin >> N >> Mod;
	cout << concat(N) << endl;
	return 0;
}