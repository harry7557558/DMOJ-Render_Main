#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)


class ivec2 {
public:
	int x, y;
	ivec2() {}
	explicit ivec2(int a) :x(a), y(a) {}
	ivec2(int x, int y) :x(x), y(y) {}
	bool operator == (ivec2 v) const { return x == v.x && y == v.y; }
	ivec2 operator - () const { return ivec2(-x, -y); }
	ivec2 operator + (ivec2 v) const { return ivec2(x + v.x, y + v.y); }
	ivec2 operator - (ivec2 v) const { return ivec2(x - v.x, y - v.y); }
	ivec2 operator * (int a) const { return ivec2(x*a, y*a); }
	int sqr() const { return x * x + y * y; }
	friend int dot(ivec2 u, ivec2 v) { return u.x*v.x + u.y*v.y; }
	friend int det(ivec2 u, ivec2 v) { return u.x*v.y - u.y*v.x; }
	ivec2 rot() const { return ivec2(-y, x); }
};

ivec2 P[1001];
int N;

bool existPoint(ivec2 p) {
	ivec2 *d = lower_bound(P, P + N, p, [](ivec2 p, ivec2 q) {return p.x < q.x ? true : p.x > q.x ? false : p.y < q.y; });
	return *d == p;
}

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	scanu(N);
	for (int i = 0; i < N; i++) {
		int x, y; scan(x); scan(y);
		P[i] = ivec2(x, y);
	}
	P[N] = ivec2(0x7FFFFFFF);
	std::sort(P, P + N, [](ivec2 p, ivec2 q) {return p.x == q.x ? p.y < q.y : p.x < q.x; });

	int Count = 0;
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < i; j++) {
			ivec2 ij = P[j] - P[i];
			for (int k = 0; k < j; k++) {
				ivec2 ik = P[k] - P[i];
				if (dot(ij, ik) == 0)
					Count += existPoint(P[i] + ij + ik);
			}
		}
	}
	printf("%d\n", Count);

	return 0;
}