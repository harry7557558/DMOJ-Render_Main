#include <bits/stdc++.h>
using namespace std;


#ifdef __DEBUG
typedef long long lint;
#else
typedef __int128 lint;
#endif
typedef long double ldouble;
#define inf 0x7FFFFFFF
#define INF 0x7FFFFFFFFFFFFFFF

lint Mod = INF;


lint pow(lint x, lint e, lint m) {
	lint r = 1;
	x %= m;
	while (e) {
		if (e & 1) r = (r*x) % m;
		if (e >>= 1) x = (x*x) % m;
	}
	return r;
}
lint modInverse(lint a, lint m) {
	lint m0 = m;
	lint y = 0, x = 1;
	if (m == 1) return 0;
	while (a > 1) {
		if (m == 0) throw(m);
		lint q = a / m;
		lint t = m;
		m = a % m, a = t;
		t = y;
		y = x - q * y;
		x = t;
	}
	return (x + m0) % m0;
}





lint catsum_bf(lint a, lint b, lint m) {
	lint e = 1, ans = 0;
	for (lint u = b; u >= a; u--) {
		ans = (ans + u * e) % Mod;
		e = e * m % Mod;
	}
	return ans;
}
lint catsum_mi(lint a, lint b, lint m) {
	lint n = b - a;
	lint mn = pow(m, n, Mod);
	lint r = ((m - 1)*(a*(m*mn%Mod) % Mod + Mod - b % Mod) % Mod + m * (mn - 1) % Mod) % Mod;
	lint d;
	try { d = modInverse((m - 1)*(m - 1) % Mod, Mod); }
	catch (...) { throw(0); }
	return r * d % Mod;
}
lint catsum_lf(lint a, lint b, lint m) {
	ldouble n = b - a;
	ldouble mn = powl(m, n);
	ldouble r = (m - 1.l)*(a*m*mn - b) + m * (mn - 1.l);
	ldouble d = 1.l / ((m - 1.l)*(m - 1.l));
	return lint(fmodl(r*d, Mod) + Mod) % Mod;
}

lint concat(lint N) {
	vector<pair<lint, lint>> v;
	lint m = 1;
	while (m <= N) {
		v.push_back(pair<lint, lint>(m, min(10 * m - 1, N)));
		m *= 10;
	}
	lint e = 0, ans = 0;
	for (int i = v.size() - 1; i >= 0; i--) {
		lint m = pow(10, i + 1, Mod);
		lint cat;
		try { cat = catsum_mi(v[i].first, v[i].second, m); }
		catch (...) { cat = catsum_lf(v[i].first, v[i].second, m); }
		m = pow(10, e, Mod);
		ans = (ans + cat * m) % Mod;
		e += (i + 1)*(v[i].second - v[i].first + 1);
	}
	return ans;
}



// reason to use this: __int128
char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)


int main() {
#ifdef __DEBUG
	{
		Mod = 13;
		lint a = 10, b = 13, m = 9;
		cout << catsum_mi(a, b, m) << " " << catsum_bf(a, b, m) << endl;
	}
	freopen("stdin.dat", "r", stdin);
#endif
	lint N; scanu(N);
	scanu(Mod);
	lint res = concat(N);
	if (res < 0) cout << N << " " << Mod << endl;
	cout << res << endl;
	return 0;
}