#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

#define MAXW 502
bool O[MAXW][MAXW];  // true: water
int K[MAXW][MAXW], K1[MAXW][MAXW];
int R, C, M;

bool isPossible(string S, int r, int c) {
	if (!O[r][c]) return false;
	for (int d = S.length() - 1; d >= 0; d--) {
		char dir = S[d];
		if (dir == 'N') r++;
		if (dir == 'E') c--;
		if (dir == 'S') r--;
		if (dir == 'W') c++;
		if (dir == '?') {
			S = S.substr(0, d);
			return isPossible(S, r - 1, c)
				|| isPossible(S, r + 1, c)
				|| isPossible(S, r, c - 1)
				|| isPossible(S, r, c + 1);
		}
		if (!O[r][c]) return false;
	}
	return true;
}

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> R >> C >> M;
	for (int i = 1; i <= R; i++) {
		char c; do { c = getchar(); } while (c <= ' ');
		for (int j = 1; j <= C; j++) {
			O[i][j] = c == '.';
			c = getchar();
		}
	}
	string S; cin >> S;
#if 0
	printf("%d %d %d\n", R, C, M);
	for (int i = 1; i <= R; i++) {
		for (int j = 1; j <= C; j++) {
			putchar(O[i][j] ? '.' : '#');
		}
		putchar('\n');
	}
	cout << S << endl << endl;
#endif

	for (int d = 0; d < S.size(); d++) {
		char dir = S[d];
		for (int i = 1; i <= R; i++) {
			for (int j = 1; j <= C; j++) {
				if (O[i][j] && K[i][j] == d) {
					if (dir == '?' || dir == 'N') {
						if (O[i - 1][j]) K1[i - 1][j] = d + 1;
					}
					if (dir == '?' || dir == 'S') {
						if (O[i + 1][j]) K1[i + 1][j] = d + 1;
					}
					if (dir == '?' || dir == 'E') {
						if (O[i][j + 1]) K1[i][j + 1] = d + 1;
					}
					if (dir == '?' || dir == 'W') {
						if (O[i][j - 1]) K1[i][j - 1] = d + 1;
					}
				}
			}
		}
		for (int i = 1; i <= R; i++) for (int j = 1; j <= C; j++) K[i][j] = K1[i][j];
#if 0
		for (int i = 1; i <= R; i++) {
			for (int j = 1; j <= C; j++) {
				putchar(K[i][j] + '0');
			}
			putchar('\n');
		}
		putchar('\n');
#endif
	}

	int count = 0;
	int d = S.size();
	for (int i = 1; i <= R; i++) {
		for (int j = 1; j <= C; j++) {
			count += K[i][j] == d;
		}
	}
	cout << count << endl;

	return 0;
}