#include <stdio.h>

struct vec2{
    double x,y;
};

int main(){
    double x = 3, y = 2;
    vec2 g{x,y};
    printf("%lf,%lf\n", g.x, g.y);
    return 0;
}