#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

typedef long long lint;
typedef unsigned char byte;
#define inf 0x7FFFFFFF
#define INF 0x7FFFFFFFFFFFFFFF

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)


class ivec2 {
public:
	int x, y;
	ivec2() {}
	explicit ivec2(int a) :x(a), y(a) {}
	ivec2(int x, int y) :x(x), y(y) {}
	bool operator == (ivec2 v) const { return x == v.x && y == v.y; }
	ivec2 operator - () const { return ivec2(-x, -y); }
	ivec2 operator + (ivec2 v) const { return ivec2(x + v.x, y + v.y); }
	ivec2 operator - (ivec2 v) const { return ivec2(x - v.x, y - v.y); }
	ivec2 operator * (int a) const { return ivec2(x*a, y*a); }
	int sqr() const { return x * x + y * y; }
	friend int dot(ivec2 u, ivec2 v) { return u.x*v.x + u.y*v.y; }
	friend int det(ivec2 u, ivec2 v) { return u.x*v.y - u.y*v.x; }
	ivec2 rot() const { return ivec2(-y, x); }
};

template<typename T> T pMax(T p, T q) { return T(max(p.x, q.x), max(p.y, q.y)); }
template<typename T> T pMin(T p, T q) { return T(min(p.x, q.x), min(p.y, q.y)); }



// debug
void randCase(int N) {
	printf("%d\n", N);
	for (int i = 0; i < N; i++) {
		printf("%d %d %d\n", rand() % 20, rand() % 20, rand() % 20);
	}
	exit(0);
}


#define MAXN 10000
int N;
ivec2 P[MAXN];
int D[MAXN];

struct Add {
	int x; int val;
};
Add S[2 * MAXN]; int Sn = 0;


int main() {
#ifdef _DEBUG
	freopen("stdin.dat", "r", stdin);
	//srand(3); randCase(20);
#endif
	scanu(N);
	for (int i = 0; i < N; i++) {
		int x, y, d;
		scanu(x); scanu(y); scanu(d);
		P[i] = ivec2(x, y), D[i] = d;
	}
	lint Area = 0;

#if 0
	// rasterization solution for reference
	ivec2 Min = ivec2(inf), Max = -Min;
	for (int i = 0; i < N; i++) {
		Min = pMin(Min, P[i]);
		Max = pMax(Max, P[i] + ivec2(D[i]));
		printf("max(%d-x,%d-y,x+y%+d)=0\n", P[i].x, P[i].y, -(P[i].x + P[i].y + D[i]));
	}
	//printf("\b=0\n");
	ivec2 dP = Max - Min; int dX = dP.x, dY = dP.y, A = dX * dY;
	byte *S = new byte[A];
	for (int i = 0; i < A; i++) S[i] = 0;
	for (int i = 0; i < N; i++) {
		ivec2 p = P[i] - Min; int d = D[i];
		for (int x = 0; x < d; x++) {
			for (int y = 0; x + y < d; y++) {
				byte* s = &S[(y + p.y)*dX + (x + p.x)];
				*s = max(*s, (byte)(x + y == d - 1 ? 1 : 2));
			}
		}
	}
	for (int j = 0; j < dY; j++) {
		A = 0;
		for (int i = 0; i < dX; i++) {
			byte k = S[j*dX + i];
			A += k;
		}
		cout << A << endl;
		Area += A;
	}
#else

	int minY = inf, maxY = -inf;
	for (int i = 0; i < N; i++) {
		minY = min(minY, P[i].y);
		maxY = max(maxY, P[i].y + D[i]);
	}
	for (int y = minY; y < maxY; y++) {
		Sn = 0;
		for (int i = 0; i < N; i++) if (D[i]) {
			if (y >= P[i].y && y < P[i].y + D[i]) {
				Add t; t.x = P[i].x, t.val = 1;
				S[Sn++] = t;
				t.x = P[i].x + D[i] - (y - P[i].y), t.val = -1;
				S[Sn++] = t;
			}
		}
		sort(S, S + Sn, [](Add a, Add b) { return a.x == b.x ? a.val < b.val : a.x < b.x; });
		int Sa = 0, A = 0;
		int i0, i1;
		for (int i = 0; i < Sn; i++) {
			if (!Sa) i0 = S[i].x;
			Sa += S[i].val;
			if (!Sa) {
				i1 = S[i].x;
				A += 2 * (i1 - i0) - 1;
			}
		}
		//cout << A << endl;
		Area += A;
	}

#endif

	printf("%lld", Area / 2);
	if (Area & 1) printf(".5\n");
	else printf(".0\n");

	return 0;
}