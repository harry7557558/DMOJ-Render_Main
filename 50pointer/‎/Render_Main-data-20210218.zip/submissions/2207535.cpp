#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

typedef long long lint;
int N, K;
lint A[100000], S[200001];

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
	cin >> N >> K;
	for (int i = 0; i < N; i++) {
		cin >> A[i];
	}
	S[0] = 0; for (int i = 0; i < N; i++) S[i + 1] = S[i] + A[i];
	for (int i = 0; i < K; i++) S[i + N + 1] = S[i + N] + A[i];

	lint mm = 0;
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < K; j++) {
			lint m = S[i + j] - S[i];
			mm = max(mm, m);
		}
	}
	cout << mm << endl;
	return 0;
}