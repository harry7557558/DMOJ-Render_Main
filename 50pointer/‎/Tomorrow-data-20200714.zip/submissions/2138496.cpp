#include <bits/stdc++.h>
using namespace std;

string f(int N) {
	string s;
	int n = abs(N);
	while (n) {
		s.insert(s.begin(), char(n % 10 + '0'));
		n /= 10;
	}
	if (N < 0) s = "-" + s;
	if (s == "") s = "0";
	return s;
}

int main() {
	freopen("stdin.dat", "r", stdin);
	int Q; cin >> Q;
	while (Q--) {
		int N; cin >> N;
		cout << f(N) << endl;
	}
}