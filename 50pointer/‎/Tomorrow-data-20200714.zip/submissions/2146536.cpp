// https://dmoj.ca/problem/fastbit#comment-12611
// seems like I need to update my profile

#pragma GCC optimize "Ofast"
#include <bitset>
int setbits (unsigned long long x){
    return std::bitset<64>(x).count();
}