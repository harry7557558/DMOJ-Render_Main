#include <bits/stdc++.h>
using namespace std;

bool f(int n) {
	if (n < 2) return false;
	int k = sqrt(n) + 0.5;
	for (int i = 2; i <= k; i++) if (n%i == 0) return false;
	return true;
}

int main() {
	freopen("stdin.dat", "r", stdin);
	int Q; cin >> Q;
	while (Q--) {
		int N; cin >> N;
		cout << f(N) << endl;
	}
}