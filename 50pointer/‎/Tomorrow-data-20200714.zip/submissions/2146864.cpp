#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;


int main() {
	unsigned long long A, B, C;
	cin >> A >> B >> C;
	unsigned long long S = A + B + C;
	cout << (S % 42069900169420) << endl;
	return 0;
}