#include <bits/stdc++.h>
using namespace std;

int main() {
    puts(Hello, World!);
}