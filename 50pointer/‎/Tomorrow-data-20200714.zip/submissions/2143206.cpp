#pragma GCC optimize "Os"
#include <stdio.h>
int main(){
    int N; scanf("%d",&N);
    char c;
    while ((c=getchar())!=EOF) putchar(c);
    return 0;
}