bool f(int n) {
    return n%4==1;
}