// Hello, World!

#include <stdio.h>
#define lol printf("Hello, World!\nHello, World!\rHello, World!\r\n");
#define lol1 lol lol lol lol lol
#define lol2 lol1 lol1 lol1 lol1 lol1
#define lol3 lol2 lol2 lol2 lol2 lol2
#define lol4 lol3 lol3 lol3 lol3 lol3
#define lol5 lol4 lol4 lol4 lol4 lol4
#define lol6 lol5 lol5 lol5 lol5 lol5
#define lol7 lol6 lol6 lol6 lol6 lol6
#define lol8 lol7 lol7 lol7 lol7 lol7
#define lol9 lol8 lol8 lol8 lol8 lol8
#define lol0 lol9 lol9 lol9 lol9 lol9
#define LOL lol4 lol3 lol2 lol1 lol0
int main() { LOL }