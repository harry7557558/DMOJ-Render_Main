#include <stdio.h>
int main() {
	printf("Hello, World!\rHello, World!\rHello, World!\r\n");
	return 0;
}