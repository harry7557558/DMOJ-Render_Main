#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;


#define bd 1000000000

int main() {
	ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
	int N; cin >> N;
	for (int i = 0; i < N; i++) {
		int A, B; cin >> A >> B;
		int S;
		if (i % 5 < 2) {
			S = A - B;
			if (S > bd || S < -bd) S = A + B;
		}
		else {
			S = A + B;
			if (S > bd || S < -bd) S = A - B;
		}
		cout << S << endl;
	}
}