// https://dmoj.ca/problem/fastbit#comment-12611
// seems like I need to update my profile

#pragma GCC optimize "Os"
int setbits(unsigned long long n) {
    return __builtin_popcountll(n);
}