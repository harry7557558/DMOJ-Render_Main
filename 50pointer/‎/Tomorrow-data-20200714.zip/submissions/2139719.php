<?php

echo "abcd\n";
echo "abce\n";

?>