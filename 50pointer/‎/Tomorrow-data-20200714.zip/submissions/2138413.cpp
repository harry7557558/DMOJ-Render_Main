#include <stdio.h>
int main() {
	printf("Hello, World!\nHello, World!\rHello, World!\r");
	return 0;
}