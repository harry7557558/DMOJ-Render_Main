def Sum(a,b):
    c = a^b
    e = (a&b)<<1
    if e==0: return c
    return Sum(c,e)

N = int(input())
for i in range(N):
    a, b = [int(t) for t in input().split()]
    print(Sum(a,b))