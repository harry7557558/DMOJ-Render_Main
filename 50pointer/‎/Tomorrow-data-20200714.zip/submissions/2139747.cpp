#include <bits/stdc++.h>
using namespace std;

int main() {
    print("Hello, World!");
}