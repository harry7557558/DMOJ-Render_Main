// https://dmoj.ca/problem/fastbit#comment-12611
// seems like I need to update my profile

#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
int setbits(unsigned long long x) {
	int n = 0;
	while (x) x &= x - 1, n++;
	return n;
}