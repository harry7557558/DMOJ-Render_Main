import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt(), s = 0;
		for (int k=1; k<=n; k++) {
		    s += k*k*k*k*k;
		}
		System.out.println(s);
	}
}