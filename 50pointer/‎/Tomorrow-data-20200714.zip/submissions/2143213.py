import sys
input = sys.stdin.readline
for i in xrange(input()):
    print input()