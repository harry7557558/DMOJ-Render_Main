// https://dmoj.ca/problem/fastbit#comment-12611
// seems like I need to update my profile

#pragma GCC optimize "Ofast"
#include <bitset>
int setbits (unsigned long long x){
    int* k = (int*)&x;
    return std::bitset<32>(k[0]).count() + std::bitset<32>(k[1]).count();
}