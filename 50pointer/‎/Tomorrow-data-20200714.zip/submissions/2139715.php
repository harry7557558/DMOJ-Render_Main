<?php

$fp = fopen( 'php://stdin', 'r' );

$N = (int)fgets($fp);

$A = array();
for ($i = 0; $i < $N; $i++) {
    array_push($A, fgets($fp));
}

asort($A);

for ($i = 0; $i < $N; $i++) {
    echo $A[$i];
}

?>