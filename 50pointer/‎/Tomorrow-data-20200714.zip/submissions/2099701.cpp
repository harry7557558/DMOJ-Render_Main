// meme solution
// 9: 0.1170
// 8: 0.1000
// 7: 0.1140
// 6: 0.1030
// 5: 0.0800

#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

int main() {
#ifdef _DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	int N; cin >> N;
	while (N--) {
		int K[5][10];
		for (int i = 0; i < 5; i++) for (int j = 0; j < 10; j++) K[i][j] = 0;
		for (int i = 0; i < 28; i++) for (int j = 0; j < 28; j++) {
			while (getchar() != '.');
			char c;
			for (int k = 0; k < 5; k++) {
				c = getchar() - '0';
				K[k][c]++;
			}
		}
		/*for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 10; j++) {
				cout << K[i][j] << "\t";
			}
			cout << endl;
		}*/
		cout << "4\n";
	}
	return 0;
}