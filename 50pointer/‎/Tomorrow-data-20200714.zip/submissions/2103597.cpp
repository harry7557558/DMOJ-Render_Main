// See if I can get IE

#include <bits/stdc++.h>
using namespace std;

#ifdef _DEBUG
int count_common_roads(int* r) {
	return r[0];
}
#endif

int* find_roads(int n, int* u, int* v) {
	return u;
}

int main() {
	return 0;
}