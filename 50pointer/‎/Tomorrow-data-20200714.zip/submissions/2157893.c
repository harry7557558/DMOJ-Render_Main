#include <stdio.h>
int main() {
    printf("");
    return 0;
}