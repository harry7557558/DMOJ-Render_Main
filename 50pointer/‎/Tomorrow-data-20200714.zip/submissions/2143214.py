import sys
input = sys.stdin.readline
for i in xrange(int(input())):
    print input()