import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int k = n * (n+1) * (2*n+1) * (1+n*(-3+n*n*(6+3*n)));
		System.out.println((k/42)%1000000000);
	}
}