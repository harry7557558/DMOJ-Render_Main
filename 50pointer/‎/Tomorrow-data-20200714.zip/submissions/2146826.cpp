#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

string add(string a, string b);
string sub(string a, string b);

string add(string a, string b) {
	if (a[0] == '-') return sub(b, a.substr(1, a.size() - 1));
	if (b[0] == '-') return sub(a, b.substr(1, b.size() - 1));
	while (a.length() < b.length()) a = "0" + a;
	while (b.length() < a.length()) b = "0" + b;
	if (a[0] + b[0] - '0' >= '9') a = "0" + a, b = "0" + b;
	for (int i = a.length() - 1; i >= 0; i--) {
		a[i] += b[i] - '0';
		if (a[i] > '9') a[i] -= 10, a[i - 1]++;
	}
	while (a[0] && a[0] == '0') a.erase(0, 1);
	if (a.empty()) return "0";
	return a;
}

string sub(string a, string b) {
	while (a[0] && a[0] == '0') a.erase(0, 1);
	while (b[0] && b[0] == '0') b.erase(0, 1);
	bool sgn = a.size() < b.size();
	if (a.size() == b.size()) {
		int i; for (i = 0; i < a.size(); i++) {
			if (a[i] > b[i]) break;
			else if (a[i] < b[i]) { sgn = true; break; }
		}
		if (i == a.size()) return "0";
	}
	if (sgn) swap(a, b);
	while (b.size() < a.size()) b = "0" + b;
	for (int i = a.length() - 1; i >= 0; i--) {
		a[i] -= b[i] - '0';
		if (a[i] < '0') a[i] += 10, a[i - 1]--;
	}
	while (a[0] && a[0] == '0') a.erase(0, 1);
	if (sgn) a = "-" + a;
	return a;
}

int main() {
	string A, B, C;
	cin >> A >> B >> C;
	cout << add(add(A, B), C) << endl;
	return 0;
}