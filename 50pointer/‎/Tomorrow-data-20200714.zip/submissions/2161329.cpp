#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

long long f(string s) {
	long long ln = 0, on = 0, vn = 0, en = 0;
	for (int i = s.size() - 1; i >= 0; i--) {
		if (s[i] == 'e') en++;
		if (s[i] == 'v') vn += en;
		if (s[i] == 'o') on += vn;
		if (s[i] == 'l') ln += on;
	}
	return ln;
}

int main() {
	string s; cin >> s;
	cout << f(s) << endl;
}