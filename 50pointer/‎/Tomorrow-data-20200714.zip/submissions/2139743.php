<?php

$fp = fopen( 'php://stdin', 'r' );

$N = (int)fgets($fp);

$A = array();
for ($i = 0; $i < $N; $i++) {
    array_push($A, fgets($fp));
}

sort($A,2);

for ($i = 0; $i < $N; $i++) {
    echo $A[$i];
    echo "\n";
}

?>