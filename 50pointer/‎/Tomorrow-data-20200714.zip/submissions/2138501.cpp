#include <bits/stdc++.h>
using namespace std;

#define Mod 998244353
vector<int> f(int n) {
	vector<int> r;
	r.push_back(1);
	for (long long i = 2; i <= n; i++) r.push_back(r.back()*i%Mod);
	return r;
}

int main() {
	vector<int> k = f(10);
	for (int i = 0; i < k.size(); i++) cout << k[i] << " ";
}