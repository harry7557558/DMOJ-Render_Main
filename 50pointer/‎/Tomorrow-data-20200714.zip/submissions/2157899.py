s = input().split()
P = int(s[len(s)-1])

N = int(input())
print(N)