#include <bits/stdc++.h>
using namespace std;

int main() {
	int N; cin >> N;
	while (N--) {
		long long int t; cin >> t;
		cout << t << endl;
	}
	return 0;
}