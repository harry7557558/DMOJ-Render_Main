#pragma GCC target ("avx2")
#pragma GCC optimize ("O3")
#pragma GCC optimize ("unroll-loops")
#include <bits/stdc++.h>
using namespace std;

#define Mod 1000000007

int a, b, c, d, s = 1;

int f() {
	int k = (c + (rand() ^ a) << b) % (d + 1);
	int m = (k << 4) ^ (a + b + c + d);
	return s = s * (m * m + 1) % Mod;
}

__attribute__((optimize("unroll-loops")))
int main() {
	srand((unsigned)clock());

	for (a = 0; a < 0x10; a++)
		for (b = 0; b < 0x10; b++)
			for (c = 0; c < 0x10; c++)
				for (d = 0; d < 0x10; d++)
					f();

	if (s != 0) {
		printf("Hello, World!\n");
	}
	else cout << s << endl;

	return 0;
}