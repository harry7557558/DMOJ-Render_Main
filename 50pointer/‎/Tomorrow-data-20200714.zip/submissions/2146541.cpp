// https://dmoj.ca/problem/fastbit#comment-12611
// seems like I need to update my profile

#pragma GCC optimize "Ofast"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bitset>
int setbits (unsigned long long x){
    return std::bitset<64>(x).count();
}