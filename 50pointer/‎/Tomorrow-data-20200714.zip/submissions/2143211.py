for i in range(input()):
    print input()