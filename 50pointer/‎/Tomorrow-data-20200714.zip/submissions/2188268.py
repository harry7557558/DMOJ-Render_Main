print("Hello, World!", end='\n')
print("Hello, World!", end='\r')
print("Hello, World!", end='\r\n')