#include <bits/stdc++.h>
using namespace std;


bool f(int n) {
	for (int i = 0; i < 1000; i++) {
		int m = 0;
		while (n) {
			int k = n % 10;
			m += k * k;
			n /= 10;
		}
		if (m == 1) return true;
		n = m;
	}
	return false;
}

int main() {
	freopen("stdin.dat", "r", stdin);
	int Q; cin >> Q;
	while (Q--) {
		int N; cin >> N;
		cout << f(N) << endl;
	}
}