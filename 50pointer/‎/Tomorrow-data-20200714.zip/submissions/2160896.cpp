#include <stdio.h>
char P[0xF], *p = P;
int main() {
	--*p;--*p;--*p;++p;--*p;++p;--*p;++p;++p;++*p;++p;++*p;++p;++p;++*p;while(*p){++*p;++*p;++*p;++*p;while(*p){++p;++*p;++*p;++*p;while(*p){++p;++*p;++*p;++*p;++*p;++p;--*p;--*p;++p;++*p;++*p;++*p;--p;--p;--p;--*p;}--p;--*p;}--p;++*p;++*p;++*p;}++p;++p;++p;putchar(*p);++p;--*p;--*p;++p;--*p;putchar(*p);++p;putchar(*p);putchar(*p);++*p;++p;++*p;++*p;++*p;++*p;++p;++*p;++*p;++*p;putchar(*p);++*p;++p;--*p;--*p;++p;while(*p){++p;--*p;putchar(*p);--p;--p;}
}