#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

#pragma region fast_io
#ifndef __DEBUG
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#define fread fread_unlocked
#define fwrite fwrite_unlocked
#endif
#define INPUT_SIZE 1<<22
#define OUTPUT_SIZE 1<<22
int _i0 = 0, _o0 = 0;
char _, _n, __[20], _i[INPUT_SIZE], _o[OUTPUT_SIZE];
#define readin _i[fread(_i, 1, INPUT_SIZE, stdin)]=0
#define writeout fwrite(_o, 1, _o0, stdout)
#define scanu(x) do{while((_=_i[_i0++])<48);for(x=_-48;47<(_=_i[_i0++]);x=x*10+_-48);}while(0)
#define scan(x) do{while((_n=_i[_i0++])<45);if(_n-45)x=_n;else x=_i[_i0++];for(x-=48;47<(_=_i[_i0++]);x=x*10+_-48);if(_n<46)x=-x;}while(0)
inline void putnumu(int x) { _ = 0; do __[_++] = x % 10; while (x /= 10); while (_--)_o[_o0++] = __[_] + '0'; }
#define putnl _o[_o0++]='\n'
#pragma endregion


int A[200000], Ap[200000];
int N, Mod;

struct Add {
	int x, val;
};
vector<Add> Adds;

void addVal(int l, int r, int val) {
	if ((val %= Mod) == 0) return;
	int d0 = lower_bound(Adds.begin(), Adds.end(), l, [](Add a, int x) {return a.x < x; }) - Adds.begin();
	int d1 = lower_bound(Adds.begin(), Adds.end(), r, [](Add a, int x) {return a.x < x; }) - Adds.begin();
	if (Adds[d0].x == l) {
		if (Adds[d1].x == r) {
			for (int i = d0; i < d1; i++) Adds[i].val = (Adds[i].val + val) % Mod;
		}
		else {
			Add t; t.x = r, t.val = Adds[d1 - 1].val;
			Adds.insert(Adds.begin() + d1, t);
			for (int i = d0; i < d1; i++) Adds[i].val = (Adds[i].val + val) % Mod;
		}
	}
	else {
		Add t; t.x = r, t.val = Adds[d0 - 1].val;
		Adds.insert(Adds.begin() + d0, t); d0++, d1++;
		if (Adds[d1].x == r) {
			for (int i = d0; i < d1; i++) Adds[i].val = (Adds[i].val + val) % Mod;
		}
		else {
			t.x = r, t.val = Adds[d1 - 1].val;
			Adds.insert(Adds.begin() + d1, t);
			for (int i = d0; i < d1; i++) Adds[i].val = (Adds[i].val + val) % Mod;
		}
	}
}
int getSum(int l, int r) {
	int d0 = lower_bound(Adds.begin(), Adds.end(), l, [](Add a, int x) {return a.x < x; }) - Adds.begin();
	int d1 = lower_bound(Adds.begin(), Adds.end(), r, [](Add a, int x) {return a.x < x; }) - Adds.begin();
	int sum = 0;
	if (Adds[d0].x > l) sum = (sum + (Adds[d0].x - l)*Adds[d0 - 1].val) % Mod;
	if (Adds[d1].x > r) sum = (sum + (r - Adds[d1 - 1].x)*Adds[d1 - 1].val) % Mod, d1--;
	for (int i = d0; i < d1; i++) sum = (sum + (Adds[i + 1].x - Adds[i].x)*Adds[i].val) % Mod;
	return sum;
}


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	readin;
	int Q;
	scanu(Mod); scanu(N); scanu(Q);
	for (int i = 0; i < N; i++) {
		scanu(A[i]);
		A[i] %= Mod;
	}
	Ap[0] = A[0]; for (int i = 1; i < N; i++) Ap[i] = (Ap[i - 1] + A[i]) % Mod;
	Add t; t.x = 0, t.val = 0; Adds.push_back(t);
	t.x = N, t.val = 0; Adds.push_back(t);
	while (Q--) {
		int cmd; scanu(cmd);
#if 0
		// bruteforce solution as reference
		if (cmd == 1) {
			int l, r, x; scanu(l); scanu(r); scan(x); l--;
			for (int i = l; i < r; i++) A[i] = (A[i] + x) % Mod;
		}
		else {
			int l, r; scanu(l); scanu(r); l--;
			int cnt = 0;
			for (int i = l; i < r; i++) cnt = (cnt + A[i]) % Mod;
			putnumu(cnt); putnl;
}
#else
		if (cmd == 1) {
			int l, r, x; scanu(l); scanu(r); scan(x); l--, x %= Mod;
			addVal(l, r, x);
		}
		else {
			int l, r; scanu(l); scanu(r); l--;
			int cnt = (r ? Ap[r - 1] : 0) + Mod - (l ? Ap[l - 1] : 0) % Mod;
			cnt = (cnt + getSum(l, r)) % Mod;
			putnumu(cnt); putnl;
		}
#endif
	}
	writeout;
	return 0;
}