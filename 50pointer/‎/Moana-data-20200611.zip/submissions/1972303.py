N = int(input())
while N > 0:
    s = list(input())
    d0 = 0
    for d in range(len(s)):
        if (not((s[d]>='A'and s[d]<='Z')or(s[d]>='a'and s[d]<='z')or(s[d]>='0'and s[d]<='9'))):
            if d - d0 == 4:
                s[d0]=s[d0+1]=s[d0+2]=s[d0+3]='*'
            d0 = d + 1
    if len(s) - d0 == 4:
        s[d0]=s[d0+1]=s[d0+2]=s[d0+3]='*'
    for i in range(len(s)):
        print(s[i],end='')
    print()
    N = N - 1