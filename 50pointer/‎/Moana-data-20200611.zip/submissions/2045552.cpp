#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

#if _DEBUG
std::ifstream fin("stdin.dat");
#define cin fin
#endif

typedef unsigned long long lint;

lint Prime[100000];

bool isPrime0(lint n) {
	if (n < 2) return false;
	if (n <= 3) return true;
	if (n % 2 == 0 || n % 3 == 0) return false;
	for (int i = 4, k = sqrt(n); i <= k; i += 6) {
		if (n % (i + 1) == 0) return false;
		if (n % (i + 3) == 0) return false;
	}
	return true;
}

void init() {
	lint p = 2;
	for (int i = 0; i < 100000; i++) {
		while (!isPrime0(p)) p++;
		Prime[i] = p++;
	}
}

lint pow(lint x, lint e, lint m) {
	lint r = 1;
	x %= m;
	while (e) {
		if (e & 1) r = (r*x) % m;
		e >>= 1;
		x = (x*x) % m;
	}
	return r;
}

bool isPrime(lint p) {
	if (p < 1300000) return isPrime0(p);
	for (int i = 0; i < 100000; i++) {
		if (p == Prime[i]) return true;
		if (p%Prime[i] == 0) return false;
	}
	return true;
	for (int i = 2; i < 100; i++) {
		if (pow(i, p - 1, p) != 1) return false;
	}
	return true;
}


int main() {
	init();
	lint n; cin >> n;
	while (!isPrime(n)) n++;
	cout << n << endl;
	return 0;
}