import math

M = 1000000013

n = int(input())
if n==1: n=2

m = n // 2
r = 0
if n&1:
    r=pow(2,2*m-1,M)
    s=pow(2,m-1,M)
    if ((m+1)%4<2): r+=s
    else: r-=s
else:
    r=pow(2,2*m-2,M)
    if m&1==0:
        s=pow(2,m-1,M)
        if m%4: r-=s
        else: r+=s
r%=M
if r<0: r+=M
print(r)