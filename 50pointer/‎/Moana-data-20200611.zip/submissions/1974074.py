T = int(input())
while T > 0:
    m, x, y = [int(t) for t in input().split()]
    n = pow(5, m-1)
    ept = True
    for i in range(m):
        xr = (x // n) % 5
        yr = (y // n) % 5
        if yr + abs(xr - 2) < 2:
            print("crystal")
            break
        elif not((yr==1 and abs(xr-2)==1) or (yr==2 and xr==2)):
            print("empty")
            break
        elif n==1:
            print("empty")
            break
        n //= 5
    T -= 1