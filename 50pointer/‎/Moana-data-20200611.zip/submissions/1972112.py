import math

while 1:
    n = int(input())
    if n==0:
        break
    a = int(math.sqrt(n))
    while n%a != 0:
        a = a-1
    b = n // a
    print("Minimum perimeter is %d with dimensions %d x %d"%(2*(a+b),a,b))