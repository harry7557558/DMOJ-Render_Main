#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;


int N;
int A[100000];

template<typename T> T gcd(T a, T b) {
	while (b) {
		T t = b;
		b = a % b;
		a = t;
	}
	return a;
}



char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	scanu(N);
	int M; scanu(M);
	for (int i = 0; i < N; i++) scanu(A[i]);
	while (M--) {
		char cmd; do; while ((cmd = getchar()) < 'A');
		if (cmd == 'C') {
			int x, v; scanu(x); scanu(v); x--;
			A[x] = v;
		}
		if (cmd == 'M') {
			int l, r; scanu(l); scanu(r); l--;
			int Min = 0x7FFFFFFF;
			for (int i = l; i < r; i++) {
				if (A[i] < Min) Min = A[i];
			}
			printf("%d\n", Min);
		}
		if (cmd == 'G') {
			int l, r; scanu(l); scanu(r); l--;
			int Gcd = A[l];
			for (int i = l + 1; i < r; i++) {
				Gcd = gcd(Gcd, A[i]);
			}
			printf("%d\n", Gcd);
		}
		if (cmd == 'Q') {
			int l, r; scanu(l); scanu(r); l--;
			int Gcd = A[l];
			for (int i = l + 1; i < r; i++) {
				Gcd = gcd(Gcd, A[i]);
			}
			int Count = 0;
			for (int i = l; i < r; i++) {
				Count += A[i] == Gcd;
			}
			printf("%d\n", Count);
		}
	}
	return 0;
}