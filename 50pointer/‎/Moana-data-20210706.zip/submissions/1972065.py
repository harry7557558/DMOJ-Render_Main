def isr(n):
    s = str(n)
    n = len(s)
    for i in range(n//2+1):
        c = s[i]
        d = s[n-i-1]
        if (not((c=='0' and d=='0') or (c=='1' and d=='1') or (c=='6' and d=='9') or (c=='8' and d=='8') or (c=='9' and d=='6'))):
            return 0
    return 1

m = int(input())
n = int(input())
count = 0
for i in range(m,n+1):
    count += isr(i)
print(count)