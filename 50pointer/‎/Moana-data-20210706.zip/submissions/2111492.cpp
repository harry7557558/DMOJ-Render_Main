#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

typedef long long lint;

#ifndef __DEBUG
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)

struct Friend {
	lint x;  // (x,0)
	int vx, vy;
} F[100000];


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	//freopen("stdout.dat", "w", stdout);
#endif
	int N; scanu(N);
	lint L, R, Y; scan(L); scan(R); scan(Y);
	for (int i = 0; i < N; i++) {
		lint t; scan(t); F[i].x = t;
		scanu(F[i].vy); scanu(F[i].vx);
	}
	R++;

	lint dX = R - L;
	int *V = new int[dX];
	int *S = new int[N + 1];
	for (int i = 0; i < dX; i++) V[i] = -1;
	for (int i = 0; i <= N; i++) S[i] = dX;

	for (int d = 0; d < N; d++) {
		int X = Y * F[d].vx;
		if (X % F[d].vy == 0) X--; X /= F[d].vy;
		for (int i = max(F[d].x - X, L), im = min(F[d].x + X + 1, R); i < im; i++) {
			S[++V[i - L]]--;
		}
	}

	for (int i = 0; i <= N; i++) {
		printf("%d\n", S[i]);
	}
	return 0;
}