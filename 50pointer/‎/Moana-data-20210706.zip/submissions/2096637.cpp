#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

char _;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)

typedef long long lint;
#define Mod 998244353

#define D 2048
lint M[D][D], R[D][D], T[D][D];
lint A[D];


int main() {
#ifdef _DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	int N; lint K;
	scanu(N); scanu(K);
	K -= N - 1;
	for (int i = 0; i < N; i++) scanu(A[i]);
	for (int i = 0; i < N; i++) scanu(M[0][i]);
	for (int i = 1; i < N; i++) M[i][i - 1] = 1;
	for (int i = 0; i < N; i++) R[i][i] = 1;
	while (K) {
		if (K & 1) {
			for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) {
				auto r = R[i], t = T[i];
				t[j] = 0;
				for (int k = 0; k < N; k++) t[j] = (t[j] + r[k] * M[k][j]) % Mod;
			}
			for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) R[i][j] = T[i][j];
		}
		K >>= 1;
		for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) {
			auto m = M[i], t = T[i];
			t[j] = 0;
			for (int k = 0; k < N; k++) t[j] = (t[j] + m[k] * M[k][j]) % Mod;
		}
		for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) M[i][j] = T[i][j];
	}
	lint F = 0;
	for (int i = 0; i < N; i++) F = (F + R[0][i] * A[N - i - 1]) % Mod;
	printf("%llu\n", F);
	return 0;
}