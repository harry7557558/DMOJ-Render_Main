P = [i>1 for i in range(int(raw_input())+2)]
for i in range(2,len(P)-2):
    if P[i]:
        for j in range(i+i,len(P),i): P[j]=False
        print (lambda: str(i)+'*' if P[i-2] or P[i+2] else i)()