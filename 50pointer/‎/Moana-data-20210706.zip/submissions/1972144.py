N = int(input())
while N > 0:
    N -= 1
    y, m, d = input().split()
    v = True
    if 2007 - int(y) < 18:
        v = False
    elif 2007 - int(y) == 18:
        if int(m) < 2:
            v = False
        elif int(m) == 2:
            v = int(d) < 28
    if v: print("Yes")
    else: print("No")