#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

typedef long long lint;

#ifndef __DEBUG
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)

class ivec2 {
public:
	lint x, y;
	ivec2() {}
	ivec2(lint x, lint y) :x(x), y(y) {}
	bool operator == (ivec2 v) const { return x == v.x && y == v.y; }
	ivec2 operator - () const { return ivec2(-x, -y); }
	ivec2 operator + (ivec2 v) const { return ivec2(x + v.x, y + v.y); }
	ivec2 operator - (ivec2 v) const { return ivec2(x - v.x, y - v.y); }
	ivec2 operator * (lint a) const { return ivec2(x*a, y*a); }
	lint sqr() const { return x * x + y * y; }
	friend lint dot(ivec2 u, ivec2 v) { return u.x*v.x + u.y*v.y; }
	friend lint det(ivec2 u, ivec2 v) { return u.x*v.y - u.y*v.x; }
	ivec2 rot() const { return ivec2(-y, x); }  // rotate 90deg counterclockwise
};


struct Friend {
	lint x;  // (x,0)
	ivec2 view;
} F[100000];


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	//freopen("stdout.dat", "w", stdout);
#endif
	int N; scanu(N);
	lint L, R, Y; scan(L); scan(R); scan(Y);
	for (int i = 0; i < N; i++) {
		lint t; scan(t); F[i].x = t;
		scanu(F[i].view.y); scanu(F[i].view.x);
	}
	R++;

	lint dX = R - L;
	int *V = new int[dX];
	int *S = new int[N + 1];
	for (int i = 0; i < dX; i++) V[i] = -1;
	for (int i = 0; i <= N; i++) S[i] = dX;

	for (int d = 0; d < N; d++) {
		int X = Y * F[d].view.x;
		if (X % F[d].view.y == 0) X--; X /= F[d].view.y;
		for (lint i = max(F[d].x - X, L), im = min(F[d].x + X + 1, R); i < im; i++) {
			V[i - L]++;
			S[V[i - L]]--;
		}
	}

	for (int i = 0; i <= N; i++) {
		printf("%d\n", S[i]);
	}
	return 0;
}