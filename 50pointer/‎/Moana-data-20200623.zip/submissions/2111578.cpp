#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

//typedef long long lint;
#define lint int

#ifndef __DEBUG
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

#define INPUT_SIZE 1<<22
#define OUTPUT_SIZE 1<<22
int _i0 = 0, _o0 = 0;
char _, _n, __[20], _i[INPUT_SIZE], _o[OUTPUT_SIZE];
#define scanu(x) do{while((_=_i[_i0++])<48);for(x=_-48;47<(_=_i[_i0++]);x=x*10+_-48);}while(0)
#define scan(x) do{while((_n=_i[_i0++])<45);if(_n-45)x=_n;else x=_i[_i0++];for(x-=48;47<(_=_i[_i0++]);x=x*10+_-48);if(_n<46)x=-x;}while(0)
inline void putnumu(int x) { _ = 0; do __[_++] = x % 10; while (x /= 10); while (_--)_o[_o0++] = __[_] + '0'; }

#define MAXN 100000
struct Friend {
	lint x;  // (x,0)
	int vx, vy;
} F[MAXN];

int V[0x200000];
int S[MAXN + 1];


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	//freopen("stdout.dat", "w", stdout);
#endif
	fread(_i, 1, INPUT_SIZE, stdin);
	int N; scanu(N);
	lint L, R, Y; scan(L); scan(R); scan(Y);
	for (int i = 0; i < N; i++) {
		lint t; scan(t); F[i].x = t;
		scanu(t); F[i].vy = t; scanu(t); F[i].vx = t;
	}
	R++;

	lint dX = R - L;
	//int *V = new int[dX];
	//int *S = new int[N + 1];
	//for (int i = 0; i < dX; i++) V[i] = -1;
	for (int i = 0; i <= N; i++) S[i] = dX;

	for (int d = 0; d < N; d++) {
		Friend Fd = F[d];
		int X = Y * Fd.vx;
		if (X % Fd.vy == 0) X--; X /= Fd.vy;
		lint i0 = max(Fd.x - X, L), i1 = min(Fd.x + X + 1, R);
		int* Vi = &V[i0 - L];
		for (lint i = 0, im = i1 - i0; i < im; i++) {
			S[Vi[i]++]--;
		}
	}

	for (int i = 0; i <= N; i++) {
		putnumu(S[i]); _o[_o0++] = '\n';
	}
	fwrite(_o, 1, _o0, stdout);
	return 0;
}