import math
a = int(input())
b = int(input())
d = b - a + 1
s = math.ceil(math.sqrt(d))//2+1
M = [[0 for i in range(-s,s+1)] for j in range(-s,s+1)]
u = v = s
dr = 'd'
minu = minv = len(M)
maxu = maxv = 0
for i in range(d):
    M[u][v] = a + i
    minu = min(minu,u)
    maxu = max(maxu,u)
    minv = min(minv,v)
    maxv = max(maxv,v)
    if dr == 'd':
        u += 1
        if M[u][v+1]==0: dr='r'
    elif dr=='r':
        v += 1
        if M[u-1][v]==0: dr='u'
    elif dr=='u':
        u -= 1
        if M[u][v-1]==0: dr='l'
    elif dr=='l':
        v -= 1
        if M[u+1][v]==0: dr='d'

for i in range(minu,maxu+1):
    for j in range(minv,maxv+1):
        if M[i][j]!=0: print(M[i][j],end=' ')
    print(end='\n')