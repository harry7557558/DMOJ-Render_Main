T = int(input())
while T > 0:
    n = int(input())
    X = [int(t) for t in input().split()]
    Y = [int(t) for t in input().split()]
    maxd = 0
    for i in range(n):
        for j in range(i,n):
            if Y[j]>=X[i]:
                maxd = max(maxd, j-i)
    print("The maximum distance is %d"%(maxd))
    T -= 1