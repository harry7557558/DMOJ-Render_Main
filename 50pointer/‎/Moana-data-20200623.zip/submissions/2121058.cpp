#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

#pragma region fast_io
#ifndef __DEBUG
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#define fread fread_unlocked
#define fwrite fwrite_unlocked
#endif
#define INPUT_SIZE 1<<22
#define OUTPUT_SIZE 1<<22
int _i0 = 0, _o0 = 0;
char _, _n, __[20], _i[INPUT_SIZE], _o[OUTPUT_SIZE];
#define readin _i[fread(_i, 1, INPUT_SIZE, stdin)]=0
#define writeout fwrite(_o, 1, _o0, stdout)
#define scanu(x) do{while((_=_i[_i0++])<48);for(x=_-48;47<(_=_i[_i0++]);x=x*10+_-48);}while(0)
#define scan(x) do{while((_n=_i[_i0++])<45);if(_n-45)x=_n;else x=_i[_i0++];for(x-=48;47<(_=_i[_i0++]);x=x*10+_-48);if(_n<46)x=-x;}while(0)
inline void putnumu(int x) { _ = 0; do __[_++] = x % 10; while (x /= 10); while (_--)_o[_o0++] = __[_] + '0'; }
#define putnl _o[_o0++]='\n'
#pragma endregion


int N; int Q;
int M[500001];

struct option {
	int opinion = 0;
	int count = 0;
};
typedef vector<option> rangesum;

void increase1(rangesum &r, int op) {
	int d = lower_bound(r.begin(), r.end(), op, [](option x, int d) {return x.opinion < d; }) - r.begin();
#ifdef _DEBUG
	if (r[d].opinion != op || r[d].count == 0) throw("Bug!");
#endif
	if (d + 1 != r.size() && r[d + 1].opinion == op + 1) {
		r[d].count--, r[d + 1].count++;
		if (r[d].count == 0) r.erase(r.begin() + d);
	}
	else {
		if (r[d].count == 1) r[d].opinion++;
		else {
			option t; t.opinion = op + 1, t.count = 1;
			r.insert(r.begin() + d + 1, t);
			r[d].count--;
		}
	}
}
void decrease1(rangesum &r, int op) {
	int d = lower_bound(r.begin(), r.end(), op, [](option x, int d) {return x.opinion < d; }) - r.begin();
#ifdef _DEBUG
	if (r[d].opinion != op || r[d].count == 0) throw("Bug!");
#endif
	if (d != 0 && r[d - 1].opinion == op - 1) {
		r[d].count--, r[d - 1].count++;
		if (r[d].count == 0) r.erase(r.begin() + d);
	}
	else {
		if (r[d].count == 1) r[d].opinion--;
		else {
			r[d].count--;
			option t; t.opinion = op - 1, t.count = 1;
			r.insert(r.begin() + d, t);
		}
	}
}
void merge(rangesum &r, const rangesum &u, const rangesum &v) {
	int un = u.size(), vn = v.size(), ui = 0, vi = 0;
	r.reserve(un + vn);
	while (ui < un && vi < vn) {
		if (u[ui].opinion < v[vi].opinion) r.push_back(u[ui++]);
		else if (u[ui].opinion > v[vi].opinion) r.push_back(v[vi++]);
		else {
			option t; t.opinion = u[ui].opinion, t.count = u[ui].count + v[vi].count;
			r.push_back(t), ui++, vi++;
		}
	}
	while (ui < un) r.push_back(u[ui++]);
	while (vi < vn) r.push_back(v[vi++]);
}

int elementCount(const rangesum &r, int op) {
	int d = lower_bound(r.begin(), r.end(), op, [](option x, int d) {return x.opinion < d; }) - r.begin();
	if (d < r.size() && r[d].opinion == op) return r[d].count;
	else return 0;
}


struct Node {
	rangesum r;
	int size;
	Node *c1, *c2;
} *R;

void initTree(Node* &R, int *beg, int *end) {
	R = new Node;
	R->size = end - beg;
	if (R->size == 1) {
		R->c1 = R->c2 = 0;
		option t; t.opinion = *beg, t.count = 1;
		R->r.push_back(t);
		return;
	}
	int M = R->size / 2;
	initTree(R->c1, beg, beg + M);
	initTree(R->c2, beg + M, end);
	merge(R->r, R->c1->r, R->c2->r);
}
void increase1_tree(Node* &R, int x, int op) {
	increase1(R->r, op);
	if (R->size == 1) return;
	if (x < R->size / 2) increase1_tree(R->c1, x, op);
	else increase1_tree(R->c2, x - R->size / 2, op);
}
void decrease1_tree(Node* &R, int x, int op) {
	decrease1(R->r, op);
	if (R->size == 1) return;
	if (x < R->size / 2) decrease1_tree(R->c1, x, op);
	else decrease1_tree(R->c2, x - R->size / 2, op);
}


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	//freopen("stdout.dat", "w", stdout);
#endif
	readin;
	scanu(N); scanu(Q);
	initTree(R, M, M + N);
	while (Q--) {
		while ((_ = _i[_i0++]) < 48);
		if (_ == '1') {
			int x; scanu(x); x--;
			increase1_tree(R, x, M[x]);
			M[x]++;
		}
		else if (_ == '2') {
			int x; scanu(x); x--;
			decrease1_tree(R, x, M[x]);
			M[x]--;
		}
		else {
			int l, r, c; scanu(l); scanu(r); scan(c); l--, r--;
			int count = elementCount(R->r, c);
			Node* p = R; int x = l;
			while (p->size > 1) {
				if (x < p->size / 2) {
					p = p->c1;
				}
				else {
					x -= p->size / 2;
					count -= elementCount(p->c1->r, c);
					p = p->c2;
				}
			}
			p = R; x = r;
			while (p->size > 1) {
				if (x < p->size / 2) {
					count -= elementCount(p->c2->r, c);
					p = p->c1;
				}
				else {
					x -= p->size / 2;
					p = p->c2;
				}
			}
			putnumu(count); putnl;
		}
	}
	writeout;
	return 0;
}