#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)


int main() {
	int C, D, E;
	scanu(C); scanu(D); scanu(E);
	const int T[8] = { 1, 0, 0, 0, 0, 2, 1, 0 };
	int r = 1;
	for (int i = 0; i < 30 && r; i++) {
		int k = ((C & 1) << 2) | ((D & 1) << 1) | (E & 1);
		r *= T[k];
		C >>= 1, D >>= 1, E >>= 1;
	}
	printf("%d\n", r);
	return 0;
}