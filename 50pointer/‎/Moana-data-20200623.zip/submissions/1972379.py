import math
xf, yf, r = [int(t) for t in input().split()]
xw, yw, l = [int(t) for t in input().split()]
minx = max(xf-r,xw-l)
maxx = min(xf+r,xw+l) + 1
c = 0
for i in range(minx,maxx):
    fr = int(math.sqrt(r*r-(i-xf)*(i-xf)))
    wr = l-abs(i-xw)
    maxy = min(yf+fr,yw+wr)
    miny = max(yf-fr,yw-wr)
    dy = maxy-miny+1
    if dy > 0:
        c += dy
        if i==xf and yf<=maxy and yf>=miny: c-=1
        elif i==xw and yw<=maxy and yw>=miny: c-=1
print(c)