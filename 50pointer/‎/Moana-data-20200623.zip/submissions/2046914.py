import requests
response = requests.get("https://dmoj.ca/~quantum/csprng.txt")
print(response.text)