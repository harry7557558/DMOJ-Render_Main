import math
a = int(input())
b = int(input())
print(int(math.pow(b,1./6)+1e-12)-int(math.pow(a-1,1./6)+1e-12))