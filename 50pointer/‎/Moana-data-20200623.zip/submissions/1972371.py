import random

M = [[],[],[]]
Min = 1000000
Max = -1000000
for i in range(3):
    M[i] = input().split()
    for j in range(3):
        if (M[i][j]!='X'):
            M[i][j] = int(M[i][j])
            if M[i][j]>Max: Max=M[i][j]
            if M[i][j]<Min: Min=M[i][j]

def Print(K):
    for i in range(3):
        for j in range(3):
            print(K[i][j],end='')
            if j==2: print()
            else: print(end=' ')

def fill(K):
    for i in range(3):
        if K[i][0]=='X' and K[i][1]!='X' and K[i][2]!='X': K[i][0] = 2*K[i][1]-K[i][2]
        if K[i][0]!='X' and K[i][1]=='X' and K[i][2]!='X': K[i][1] = (K[i][0]+K[i][2])//2
        if K[i][0]!='X' and K[i][1]=='X' and K[i][2]!='X': K[i][2] = 2*K[i][1]-K[i][0]
        if K[0][i]=='X' and K[1][i]!='X' and K[2][i]!='X': K[0][i] = 2*K[1][i]-K[2][i]
        if K[0][i]!='X' and K[1][i]=='X' and K[2][i]!='X': K[1][i] =(K[0][i]+K[2][i])//2
        if K[0][i]!='X' and K[1][i]=='X' and K[2][i]!='X': K[2][i] = 2*K[1][i]-K[0][i]
fill(M)
m = [M[0].copy(),M[1].copy(),M[2].copy()]

def hasX(K):
    for i in range(3):
        for j in range(3):
            if K[i][j]=='X': return True
    return False

def test(K):
    if hasX(K):
        return False
    for i in range(3):
        if K[i][0]+K[i][2]!=2*K[i][1]: return False
        if K[0][i]+K[2][i]!=2*K[1][i]: return False
    return True

while not(test(m)):
    m = [M[0].copy(),M[1].copy(),M[2].copy()]
    while hasX(m):
        i = random.randint(0,2)
        j = random.randint(0,2)
        while m[i][j]!='X':
            i = random.randint(0,2)
            j = random.randint(0,2)
        m[i][j] = random.randint(Min,Max)
        fill(m)

Print(m)