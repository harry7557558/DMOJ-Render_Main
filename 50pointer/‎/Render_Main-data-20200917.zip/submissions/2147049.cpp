#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)


int N, M, K;
struct block {
	int r, c;
} B[500001];

bool isOpen(int x, int y) {
	if (x < 0 || x >= N || y < 0 || y >= M) return false;
	block *d1 = lower_bound(B, B + K, x, [](block a, int r) { return a.r < r; });
	if (d1->r != x) return true;
	block *d2 = lower_bound(B, B + K + 1, x + 1, [](block a, int r) { return a.r < r; });
	block *d = lower_bound(d1, d2, y, [](block a, int r) { return a.c < r; });
	if (d->c != y) return true;
	return false;
}

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	scanu(N); scanu(M); scanu(K);
	for (int i = 0; i < K; i++) {
		int t; scanu(t); B[i].r = t - 1;
		scanu(t); B[i].c = t - 1;
	}
	sort(B, B + K, [](block a, block b) { return a.r == b.r ? a.c < b.c : a.r < b.r; });
	B[K].r = B[K].c = 0x7FFFFFFF;
	int x = 0, y = 0, dx = 0, dy = 1;
	while (1) {
		/*if (isOpen(x - dy, y + dx))*/ {
			swap(dx, dy); dx *= -1;
		}
		for (int i = 0; ; i++) {
			if (isOpen(x + dx, y + dy)) break;
			else {
				swap(dx, dy); dy *= -1;
			}
			if (i > 4) {
				printf("NO\n");
				return 0;
			}
		}
		x += dx, y += dy;
		//printf("%d %d %d %d\n", x, y, dx, dy);
		if (x == N - 1 && y == M - 1) {
			printf("YES\n");
			return 0;
		}
		if (x == 0 && y == 0) {
			if (isOpen(0, 1) && isOpen(1, 0) && dx == 0);
			else {
				printf("NO\n");
				return 0;
			}
		}
	}
	return 0;
}