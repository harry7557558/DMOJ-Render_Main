#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

typedef long long lint;
typedef unsigned char byte;
#define inf 0x7FFFFFFF
#define INF 0x7FFFFFFFFFFFFFFF


class ivec2 {
public:
	int x, y;
	ivec2() {}
	explicit ivec2(int a) :x(a), y(a) {}
	ivec2(int x, int y) :x(x), y(y) {}
	bool operator == (ivec2 v) const { return x == v.x && y == v.y; }
	ivec2 operator - () const { return ivec2(-x, -y); }
	ivec2 operator + (ivec2 v) const { return ivec2(x + v.x, y + v.y); }
	ivec2 operator - (ivec2 v) const { return ivec2(x - v.x, y - v.y); }
	ivec2 operator * (int a) const { return ivec2(x*a, y*a); }
	int sqr() const { return x * x + y * y; }
	friend int dot(ivec2 u, ivec2 v) { return u.x*v.x + u.y*v.y; }
	friend int det(ivec2 u, ivec2 v) { return u.x*v.y - u.y*v.x; }
	ivec2 rot() const { return ivec2(-y, x); }
};

template<typename T> T pMax(T p, T q) { return ivec2(max(p.x, q.x), max(p.y, q.y)); }
template<typename T> T pMin(T p, T q) { return ivec2(min(p.x, q.x), min(p.y, q.y)); }


#define MAXN 10000
int N;
ivec2 P[MAXN];
int D[MAXN];


int main() {
#ifdef _DEBUG
	freopen("stdin.dat", "r", stdin);
#endif

	cin >> N;
	for (int i = 0; i < N; i++) {
		cin >> P[i].x >> P[i].y >> D[i];
	}

	ivec2 Min = ivec2(inf), Max = -Min;
	for (int i = 0; i < N; i++) {
		Min = pMin(Min, P[i]);
		Max = pMax(Max, P[i] + ivec2(D[i]));
	}
	ivec2 dP = Max - Min; int dX = dP.x, dY = dP.y, A = dX * dY;
	byte *S = new byte[A];
	for (int i = 0; i < A; i++) S[i] = 0;
	for (int i = 0; i < N; i++) {
		ivec2 p = P[i] - Min; int d = D[i];
		for (int x = 0; x < d; x++) {
			for (int y = 0; x + y < d; y++) {
				byte* s = &S[(y + p.y)*dX + (x + p.x)];
				*s = max(*s, (byte)(x + y == d - 1 ? 1 : 2));
			}
		}
	}
	A = 0;
	for (int j = dY - 1; j >= 0; j--) {
		for (int i = 0; i < dX; i++) {
			byte k = S[j*dX + i];
			//cout << (k == 2 ? '#' : k == 1 ? '+' : '.');
			A += k;
		}
		//cout << endl;
	}
	cout << fixed << setprecision(1) << (0.5*A) << endl;

	return 0;
}