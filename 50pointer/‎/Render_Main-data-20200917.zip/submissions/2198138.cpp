#include <bits/stdc++.h>
using namespace std;

#define println(...) printf(##__VA_ARGS__);putchar('\n');
#define printspc for (int i=0;i<spc;i++) putchar(' ');

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	for (int Q = 0; Q < 5; Q++) {
		int N; cin >> N;
		int spc = max((N * N + N) / 2 - 5, 0);
		printspc; println("          |");
		printspc; println("       \\  |  /");
		printspc; println("        \\ | /");
		printspc; println("         \\|/");
		printspc; println("       XXXXXXX");
		printspc; println("      X       X");
		printspc; println("     X  O   O  X");
		printspc; println("    X     V     X");
		printspc; println("W   X  X     X  X");
		printspc; println(" \\   X  XXXXX  X");
		printspc; println("  \\   X       X");
		printspc; println("   \\   XXXXXXX");
		printspc; println("    \\ X       X---");
		printspc; println("     X    O    X  \\");
		printspc; println("    X           X  \\");
		printspc; println("     XXXXXXXXXXX    \\");
		int spb = spc + 2;
		for (int T = 2; T <= N; T++) {
			int csp = T * T - T + 7;
			int s0 = T + 1;
			for (int u = -2; u < T; u++) {
				for (int i = 0; i < spb; i++) putchar(' ');
				for (int i = 0; i < s0; i++) putchar(' ');
				putchar('X');
				if (u == -2 || u == T - 1) {
					for (int i = 0; i < csp; i++) putchar(' ');
				}
				else {
					for (int i = 0; i < csp / 2; i++) putchar(' ');
					putchar('O');
					for (int i = 0; i < csp / 2; i++) putchar(' ');
				}
				putchar('X');
				if (T == 2 && u == -2) printf("     M");
				putchar('\n');
				csp += 2;
				s0--;
			}
			for (int i = -1; i < spb; i++) putchar(' ');
			for (int i = 2; i < csp; i++) putchar('X');
			putchar('\n');
			spb -= T + 1;
		}
		printspc; printf("      OOOO OOOO"); if (N == 1) printf("      M"); putchar('\n');
		printspc; println("      OOOO OOOO");
		if (Q != 4) putchar('\n');
	}
}