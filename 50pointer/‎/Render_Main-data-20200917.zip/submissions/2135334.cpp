#include <bits/stdc++.h>
using namespace std;

string f() {
	return "All Kill";
}