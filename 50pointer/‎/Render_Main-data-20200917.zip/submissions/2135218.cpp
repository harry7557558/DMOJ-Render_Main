#include <iostream>
using namespace std;

int main() {
	int N; cin >> N;
	while (N--) {
		int a, b; cin >> a >> b;
		if (a < 1) a = 1;
		if (b < 1) b = 1;
		if (a > 10) a = 10;
		if (b > 10) b = 10;
		int c = a + b;
		cout << c << endl;
	}
}