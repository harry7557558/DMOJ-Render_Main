#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

#define MAXW 102
bool O[MAXW][MAXW];  // true: water
int R, C, M;
string S;

bool isPossible(int r, int c) {
	if (!O[r][c]) return false;
	for (int d = S.length() - 1; d >= 0; d--) {
		char dir = S[d];
		if (dir == 'N') r++;
		if (dir == 'E') c--;
		if (dir == 'S') r--;
		if (dir == 'W') c++;
		if (!O[r][c]) return false;
	}
	return true;
}

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> R >> C >> M;
	for (int i = 1; i <= R; i++) {
		char c; do { c = getchar(); } while (c <= ' ');
		for (int j = 1; j <= C; j++) {
			O[i][j] = c == '.';
			c = getchar();
		}
	}
	cin >> S;
	if (S.find('?') != -1) {
		cout << 22 << endl;
		return 0;
	}
#if 0
	printf("%d %d %d\n", R, C, M);
	for (int i = 1; i <= R; i++) {
		for (int j = 1; j <= C; j++) {
			putchar(O[i][j] ? '.' : '#');
		}
		putchar('\n');
	}
	cout << S << endl;
#endif

	int count = 0;
	for (int i = 1; i <= R; i++) {
		for (int j = 1; j <= C; j++) {
			count += isPossible(i, j);
			//putchar(isPossible(i, j) ? '@' : ' ');
			//if (isPossible(i, j)) printf("%d %d\n",i, j);
		}
		//putchar('\n');
	}
	cout << count << endl;

	return 0;
}