#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;



#define MAXN 1000
int N;
double A[MAXN];
double D;
double mt = INFINITY;

bool oc[MAXN];
vector<int> Stack;
void test(double time) {
	if (Stack.size() >= 2) {
		double t = A[Stack.back()] - A[Stack[Stack.size() - 2]];
		while (t < D) t += 4320;
		time += t;
		if (time > 8640 - D) return;
	}
	if (Stack.size() < N) {
		Stack.push_back(-1);
		for (int i = 0; i < N; i++) if (!oc[i]) {
			Stack.back() = i;
			oc[i] = true;
			test(time);
			oc[i] = false;
		}
		Stack.pop_back();
	}
	else {
		if (time < mt) mt = time;
	}
}


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> N;
	for (int i = 0; i < N; i++) {
		string s; cin >> s;
		double a; cin >> a;
		A[i] = a * 12;
	}
	sort(A, A + N);
	cin >> D;

	test(0);
	mt += D;
	if (mt > 8640) cout << "not possible\n";
	else cout << (int)ceil(mt) << endl;

}