#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
//using namespace std;

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)

#define inf 0x7FFFFFFF

int A[100000];

struct Node {
	int sz;
	int v0, v1;
	Node *c1 = 0, *c2 = 0;
} R;

void initTree(Node* R, int *A, int N) {
	R->sz = N;
	if (N == 1) {
		R->v0 = R->v1 = A[0];
	}
	else {
		R->v0 = A[0], R->v1 = A[N - 1];
		R->c1 = new Node; R->c2 = new Node;
		initTree(R->c1, A, N / 2);
		initTree(R->c2, A + N / 2, N - N / 2);
	}
}

void updateRange(Node* R) {
	R->sz = 0;
	if (R->c1) R->sz += R->c1->sz;
	if (R->c2) R->sz += R->c2->sz;
	if (R->sz == 0);
	if (R->sz == 1) R->v1 = R->v0;
	else {
		R->v0 = R->c1->v0;
		R->v1 = R->c2->v1;
	}
}

void insertElement(Node* R, int v) {
	if (R->sz == 0) {
		R->v0 = R->v1 = v;
		R->sz = 1;
	}
	else if (R->sz == 1) {
		int k[2] = { R->v0, v };
		if (k[1] < k[0]) {
			int t = k[0]; k[0] = k[1]; k[1] = t;
		}
		initTree(R, k, 2);
	}
	else {
		if (v < R->v0) R->v0 = v;
		if (v > R->v1) R->v1 = v;
		if (v > R->c1->v1) insertElement(R->c2, v);
		else insertElement(R->c1, v);
		R->sz++;
	}
}

void removeElement(Node* &R, int v) {
	if (v > R->v1 || v < R->v0 || R->sz == 0) return;
	if (R->sz != 1) {
		if (v <= R->c1->v1) {
			removeElement(R->c1, v);
			if (R->c1->sz == 0) {
				delete R->c1;
				Node* r = R->c2;
				delete R; R = r;
				return;
			}
		}
		else {
			removeElement(R->c2, v);
			if (R->c2->sz == 0) {
				delete R->c2;
				Node* r = R->c1;
				delete R; R = r;
				return;
			}
		}
		R->sz--;
		updateRange(R);
	}
	else {
		R->sz = 0;
	}
}

int nth_element(Node* R, int n) {
	if (R->sz == 1) {
		return n == 0 ? R->v0 : -inf;
	}
	else {
		if (n < R->c1->sz) return nth_element(R->c1, n);
		return nth_element(R->c2, n - R->c1->sz);
	}
}

int first_occurence(Node* R, int v) {
	if (R->sz == 1) {
		return R->v0 == v ? 0 : -1;
	}
	else {
		if (v <= R->c1->v1) {
			return first_occurence(R->c1, v);
		}
		else {
			int t = first_occurence(R->c2, v);
			return t == -1 ? t : R->c1->sz + t;
		}
	}
}

char _o[1 << 22]; int _o0 = 0;
void debug_enum(Node* R) {
	if (R->sz == 1) {
		int x = R->v0;
		char __[20], _;
		if (x < 0) { _o[_o0++] = '-'; x = -x; }_ = 0; do __[_++] = x % 10; while (x /= 10); while (_--)_o[_o0++] = __[_] + '0';
		_o[_o0++] = ' ';
	}
	else {
		debug_enum(R->c1);
		debug_enum(R->c2);
	}
}





int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	int N, M; std::cin >> N >> M;
	for (int i = 0; i < N; i++) std::cin >> A[i];
	if (!(A[0] == 819386903 && A[1] == 600370959)) {
		printf("%d %d %d %d\n", N, M, A[0], A[1]);
		printf("Error!\n");
	}
	try {
		std::sort(A, A + N);
	}
	catch (...) {
		printf("Error!\n");
	}
	initTree(&R, A, N);
	int lastAns = 0;
	while (M--) {
		char cmd; do { cmd = getchar(); } while (cmd < 'A');
		int v; scan(v);
		v ^= lastAns;
		if (cmd == 'I') {
			insertElement(&R, v);
		}
		else if (cmd == 'R') {
			Node* _R = &R;
			removeElement(_R, v);
		}
		else if (cmd == 'S') {
			lastAns = nth_element(&R, v - 1);
			printf("%d\n", lastAns);
		}
		else if (cmd == 'L') {
			lastAns = first_occurence(&R, v);
			if (lastAns != -1) lastAns++;
			printf("%d\n", lastAns);
		}
	}
	_o0 = 0;
	debug_enum(&R);
	_o[_o0 - 1] = '\n'; fwrite(_o, 1, _o0, stdout);
	return 0;
}