#include <stdio.h>
#include <cmath>
#include <algorithm>

double Render_Main(double x, double y) {
	double m = x * x + y * y, t = atan2(x, y);
	double magic = 0.5221 - 0.2944*cos(5 * t) - 0.02483*cos(10 * t) + 0.05337*cos(15 * t) - 0.01529*cos(20 * t) - 0.0195*cos(25 * t) + 0.01284*cos(30 * t) + 0.003285*cos(35 * t) - 0.009388*cos(40 * t) + 0.001775*cos(45 * t) + 0.004718*cos(50 * t);
	return 60 * std::min(std::max(m - 1.7, 1.45 - m), sqrt(m) - magic);
}

int main(int argc, char *argv[]) {
	for (int j = 0; j < 40; j++) {
		for (int i = 0; i < 60; i++) {
			double t = Render_Main(0.05*(i - 30), 0.1*(j - 20));
			t = (t > 1 ? 0 : t < 0 ? 1 : 1 - t);
			putchar(t > .75 ? '#' : t > .5 ? '*' : t > .25 ? '.' : ' ');
		}
		putchar('\n');
	}
	return 0;
}