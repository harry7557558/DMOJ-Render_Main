#include <bits/stdc++.h>
using namespace std;


typedef unsigned long long lint;
#define inf 0x7FFFFFFF
#define INF 0x7FFFFFFFFFFFFFFF

lint Mod = INF;


lint pow(lint x, lint e, lint m) {
	lint r = 1;
	x %= m;
	while (e) {
		if (e & 1) r = (r*x) % m;
		if (e >>= 1) x = (x*x) % m;
	}
	return r;
}




// bruteforce
lint catsum(lint a, lint b, lint m) {
	lint e = 1, ans = 0;
	for (lint u = b; u >= a; u--) {
		ans = (ans + u * e) % Mod;
		e = e * m % Mod;
	}
	return ans;
}

lint concat(lint N) {
	vector<pair<lint, lint>> v;
	lint m = 1;
	while (m <= N) {
		v.push_back(pair<lint, lint>(m, min(10 * m - 1, N)));
		m *= 10;
	}
	//for (int i = 0; i < v.size(); i++) cout << v[i].first << " " << v[i].second << endl;
	lint e = 0, ans = 0;
	for (int i = v.size() - 1; i >= 0; i--) {
		lint m = pow(10, i + 1, Mod);
		lint cat = catsum(v[i].first, v[i].second, m);
		m = pow(10, e, Mod);
		ans = (ans + cat * m) % Mod;
		e += (i + 1)*(v[i].second - v[i].first + 1);
	}
	return ans;
}



int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	lint N;
	cin >> N >> Mod;
	cout << concat(N) << endl;
	return 0;
}