#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

typedef long long int lint;

lint modInverse(lint a, lint m) {
	lint m0 = m;
	lint y = 0, x = 1;
	if (m == 1) return 0;
	while (a > 1) {
		lint q = a / m;
		lint t = m;
		m = a % m, a = t;
		t = y;
		y = x - q * y;
		x = t;
	}
	return x > 0 ? x : x + m0;
}

lint pow(lint x, lint e, lint m) {
	lint r = 1;
	x %= m;
	while (e) {
		if (e & 1) r = (r*x) % m;
		if (e >>= 1) x = (x*x) % m;
	}
	return r;
}


int main() {
	lint N, M; cin >> N >> M;
	N++;
	lint val = 1;
	for (int k = 0; k < N; k++) {
		cout << val << endl;
		if (k + 1 == N) break;
		lint m = ((N - k - 1) * pow(k + 1, M - 2, M)) % M;
		val = val * m % M;
	}
	return 0;
}