#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long lint;

lint pow(lint x, lint e, lint m) {
	lint r = 1;
	x %= m;
	while (e) {
		if (e & 1) r = (r*x) % m;
		if (e >>= 1) x = (x*x) % m;
	}
	return r;
}


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	lint N, P; cin >> N >> P;
	if (N >= P) {
		cout << "0\n";
		return 0;
	}
	if (N < 2) {
		cout << "1\n";
		return 0;
	}
	if (N == P - 1) {
		cout << N << endl;
		return 0;
	}
	if (P < 65536 || N < 0x100000) {
		lint r = 1;
		for (lint i = 2; i <= N; i++) {
			r = (r*i) % P;
		}
		cout << r << endl;
		return 0;
	}
	if (P - N < 0x100000) {
		lint r = 1;
		for (lint i = P - 2; i > N; i--) {
			r = (r*i) % P;
		}
		r = (P - 1)*pow(r, P - 2, P);
		cout << r << endl;
		return 0;
	}
	if (N < 0x10000000) {
		bool *k = new bool[N];
		for (lint i = 0; i < N; i++) k[i] = true;
		for (lint i = 3; i * i < N; i += 2) if (k[i]) {
			for (lint j = i * i; j < N; j += i) k[j] = false;
		}
		int count = 0;
		for (int i = 3; i < N; i += 2) count += k[i];
		cout << count << endl;
	}
	return 0;
}