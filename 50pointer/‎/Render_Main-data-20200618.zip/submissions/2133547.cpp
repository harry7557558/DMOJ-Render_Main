#pragma GCC optimize "Os"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>


typedef long long lint;
typedef unsigned char byte;

#define DIR 0x800000000000


#pragma pack(push,1)
struct int48 {
	byte val[6];
};
struct node :int48 {
	byte X[3];
};

#define setVal(p, x) { (x) += DIR; for (int i = 0; i < 6; i++) (p)[i] = ((byte*)&(x))[i]; }
#define readVal(p, x) { *(x) = 0; for (int i = 0; i < 6; i++) ((byte*)(x))[i] = (p)[i]; *(x) -= DIR; }
inline void setX(struct node *p, unsigned n) {
	for (int i = 0; i < 3; i++) p->X[i] = ((byte*)&n)[i];
}
inline unsigned readX(struct node* p) {
	unsigned x = 0;
	for (int i = 0; i < 3; i++) ((byte*)&x)[i] = p->X[i];
	return x;
}
#define XOR(p,q) ((p)^(q))


int main() {
#ifdef _DEBUG
	freopen("stdin.dat", "r", stdin);
	printf("%d\n", sizeof(struct int48));
	printf("%d\n", sizeof(struct node));
#endif
	printf("%d\n", sizeof(struct int48));
	printf("%d\n", sizeof(struct node));
	char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)

#define newNode (struct node*)malloc(sizeof(struct node))

	struct node* p0 = newNode;
#define tou(p) (unsigned)((unsigned long long)(p)^(unsigned long long)(p0))
#define top(p) (struct node*)((unsigned long long)(p)^(unsigned long long)(p0))

	struct node *p = 0;
	struct node *lst = 0, *nxt = 0;

#define getLast(p,nxt) XOR(readX(p), tou(nxt))
#define getNext(p,lst) XOR(readX(p), tou(lst))

	int M; scanu(M);
	while (M--) {
		char c; do { c = getchar(); } while (c < ' ');
		if (c == '+') {
			lint x; scan(x);
			if (p) {
				struct node *q = p;
				p = newNode;
				setX(p, XOR(tou(lst), tou(q)));
				setX(q, XOR(tou(p), tou(nxt)));
				setX(lst, XOR(XOR(readX(lst), tou(q)), tou(p)));
				nxt = q;
			}
			else {
				p = newNode;
				lst = nxt = p;
				setX(p, 0);
			}
			setVal(p->val, x);
		}
		if (c == '-') {
			setX(lst, XOR(XOR(readX(lst), tou(p)), tou(nxt)));
			setX(nxt, XOR(XOR(readX(nxt), tou(p)), tou(lst)));
			free(p); p = nxt;
			nxt = top(getNext(p, lst));
		}
		if (c == '<') {
			struct node* lst0 = lst;
			lst = top(getLast(lst, p));
			nxt = p, p = lst0;
		}
		if (c == '>') {
			struct node* nxt0 = nxt;
			nxt = top(getNext(nxt, p));
			lst = p, p = nxt0;
		}
		if (c == '=') {
			lint x; scan(x);
			setVal(p->val, x);
		}
		if (c == '!') {
			lint x; readVal(p->val, &x);
			printf("%lld\n", x);
		}
	}

	return 0;
}