#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;


//====================== Primes ==============================

int Primes[1000000], PrimeN = 0;

void initPrimes(int N = 16777216) {
	bool *p = new bool[N];
	for (int i = 0; i < N; i++) p[i] = true;
	int k = sqrt(N) + 1;
	for (int i = 2; i < N; i++) {
		if (p[i]) {
			if (i < k) for (int j = i * i; j < N; j += i) p[j] = false;
			Primes[PrimeN++] = i;
		}
	}
	delete p;
}

//====================== Factors ==============================

int *Factors[16777216], NFactor[16777216];
void initFactor(int N) {
	if (NFactor[N]) return;
	int N0 = N;
	int PFs[20], PFRep[20], PFn = 0;
	for (int t = 0; N > 1; t++) {
		int p = Primes[t];
		if (p*p > N) break;
		if (N%p == 0) {
			PFs[PFn] = p;
			PFRep[PFn] = 1;
			N /= p;
			while (N%p == 0) PFRep[PFn]++, N /= p;
			PFn++;
		}
	}
	if (N > 1) {
		PFs[PFn] = N;
		PFRep[PFn] = 1;
		PFn++;
	}
	int Fn = 1;
	for (int i = 0; i < PFn; i++) Fn *= PFRep[i] + 1;
	NFactor[N0] = Fn;
	int *F = Factors[N0] = new int[Fn];
	F[0] = 1; int tp = 1;
	for (int i = 0; i < PFn; i++) {
		int pd = PFs[i], *k = &F[tp];
		for (int r = 1; r <= PFRep[i]; r++) {
			for (int t = 0; t < tp; t++) *k = pd * F[t], k++;
			pd *= PFs[i];
		}
		tp *= PFRep[i] + 1;
	}
	sort(F, F + Fn);
}


//====================== Global Vars ==============================

#define INF 0x7FFFFFFF

int G[4096][4096];
int S[4096][4096];

int aR[16777216], aC[16777216], aN = 0;
int a0R[16777216], a0C[16777216], a0N = 0;


//====================== Main ==============================

bool can_escape(int M, int N, vector<vector<int>> v) {
	for (int i = 1; i <= M; i++) for (int j = 1; j <= N; j++) {
		G[i][j] = v[i][j];
		S[i][j] = INF;
	}
	S[1][1] = 0;
	a0R[0] = a0C[0] = 1, a0N = 1;
	initPrimes();

	bool opr; int d = 1;
	do {
		opr = false;
		aN = 0;
		for (int u = 0; u < a0N; u++) {
			int i = a0R[u], j = a0C[u];
			int P = G[i][j];
			initFactor(P);
			int *F = Factors[P], Fn = NFactor[P];
			for (int t = 0, tm = (Fn >> 1) + (Fn & 1); t < tm; t++) {
				int r = F[t], c = F[Fn - t - 1];
				if (r <= M && c <= N) if (S[r][c] > d) {
					S[r][c] = d, opr = true;
					aR[aN] = r, aC[aN] = c, aN++;
				}
				swap(r, c);
				if (r <= M && c <= N) if (S[r][c] > d) {
					S[r][c] = d, opr = true;
					aR[aN] = r, aC[aN] = c, aN++;
				}
			}
			if (S[M][N] != INF) return true;
		}
		d++;
		a0N = aN;
		for (int u = 0; u < aN; u++) a0C[u] = aC[u], a0R[u] = aR[u];
	} while (opr);

	return false;
}

int main() {
	cout << can_escape(2, 2, {
		{ 0, 0, 0 },
		{ 0, 1, 2 },
		{ 0, 0, 3 } }) << endl;
}