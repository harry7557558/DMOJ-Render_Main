#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

#define INPUT_SIZE 1<<24
int _i0 = 0, _o0 = 0;
char _, _i[INPUT_SIZE];


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	_i[fread_unlocked(_i, 1, INPUT_SIZE, stdin)] = 0;
	bool iv = true;
	while (_ = _i[_i0++]) {
		iv ^= (_ == 'n' || _ == 'F');
	}
	if (iv) fwrite_unlocked("True\n", 1, 5, stdout);
	else fwrite_unlocked("False\n", 1, 6, stdout);
	return 0;
}