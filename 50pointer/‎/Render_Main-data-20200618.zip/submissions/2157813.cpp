#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;


#define MAXN 100
int G0[MAXN][MAXN], G[MAXN][MAXN];
char s[MAXN];
int N, M;

int sX[MAXN*MAXN], sY[MAXN*MAXN], sN = 0;
int cX[MAXN*MAXN], cY[MAXN*MAXN], cN = 0;
int PosX, PosY;

#define INF 99999
#define W -1
#define C -2
#define Cw -3

#define L -5
#define R -6
#define U -7
#define D -8

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	freopen("stdout.dat", "w", stdout);
#endif
	cin >> N >> M;
	for (int i = 0; i < N; i++) {
		cin >> s;
		for (int j = 0; j < M; j++) {
			G0[i][j] = s[j] == 'W' ? W : s[j] == 'C' ? C : s[j] == 'L' ? L : s[j] == 'R' ? R : s[j] == 'U' ? U : s[j] == 'D' ? D : s[j] == 'S' ? 0 : INF;
			if (s[j] == '.') sX[sN] = j, sY[sN] = i, sN++;
			if (s[j] == 'C') cX[cN] = j, cY[cN] = i, cN++;
			if (s[j] == 'S') PosX = j, PosY = i;
		}
	}

	for (int i = 0; i < N; i++) for (int j = 0; j < M; j++) G[i][j] = G0[i][j] > -4 ? G0[i][j] : INF;
	for (int c = 0; c < cN; c++) {
		int i = cY[c], j = cX[c];
		for (int d = j + 1; G[i][d] != W; d++) if (G0[i][d] > -4) if (G[i][d] == INF || G[i][d] == 0) G[i][d] = Cw;
		for (int d = j - 1; G[i][d] != W; d--) if (G0[i][d] > -4) if (G[i][d] == INF || G[i][d] == 0) G[i][d] = Cw;
		for (int d = i + 1; G[d][j] != W; d++) if (G0[d][j] > -4) if (G[d][j] == INF || G[d][j] == 0) G[d][j] = Cw;
		for (int d = i - 1; G[d][j] != W; d--) if (G0[d][j] > -4) if (G[d][j] == INF || G[d][j] == 0) G[d][j] = Cw;
	}
	if (G[PosY][PosX] == C) {
		for (int i = 0; i < sN; i++) printf("-1\n");
		return 0;
	}

	bool opr; int d = 0;
	do {
		opr = false;
		for (int i = 0; i < N; i++) for (int j = 0; j < M; j++) if (G[i][j] == d && G0[i][j] > -4) {
			if (G[i - 1][j] != W) if (G[i - 1][j] > d + 1) G[i - 1][j] = d + 1, opr = true;
			if (G[i + 1][j] != W) if (G[i + 1][j] > d + 1) G[i + 1][j] = d + 1, opr = true;
			if (G[i][j - 1] != W) if (G[i][j - 1] > d + 1) G[i][j - 1] = d + 1, opr = true;
			if (G[i][j + 1] != W) if (G[i][j + 1] > d + 1) G[i][j + 1] = d + 1, opr = true;
		}
		d++;
		bool opr1;
		do {
			opr1 = false;
			for (int i = 0; i < N; i++) for (int j = 0; j < M; j++) if (G[i][j] == d && G0[i][j] < -4) {
				if (G0[i][j] == L && G[i][j - 1] > d) G[i][j - 1] = d, opr1 = true;
				if (G0[i][j] == R && G[i][j + 1] > d) G[i][j + 1] = d, opr1 = true;
				if (G0[i][j] == U && G[i - 1][j] > d) G[i - 1][j] = d, opr1 = true;
				if (G0[i][j] == D && G[i + 1][j] > d) G[i + 1][j] = d, opr1 = true;
			}
			opr |= opr1;
		} while (opr1);
	} while (opr);

#if 0
	printf("%d %d\n", N, M);
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			if (G[i][j] >= 0 && G[i][j] < INF) cout << setw(4) << G[i][j];
			else cout << setw(4) << (G[i][j] == W ? 'W' : G[i][j] == C ? 'C' : G[i][j] == Cw ? 'c' : G[i][j] == INF ? '.' : char(G[i][j] + '0'));
			putchar(G0[i][j] == L ? 'L' : G0[i][j] == R ? 'R' : G0[i][j] == U ? 'U' : G0[i][j] == D ? 'D' : ' ');
		}
		cout << endl;
	}
#endif

	for (int i = 0; i < sN; i++) {
		int r = G[sY[i]][sX[i]];
		if (r == INF || r < 0) r = -1;
		cout << r << endl;
	}

	return 0;
}