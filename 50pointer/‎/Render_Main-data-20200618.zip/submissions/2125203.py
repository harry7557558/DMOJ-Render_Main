import sys
raw_input = sys.stdin.readline

N = int(raw_input())
for i in range(N):
    x = int(raw_input())
    print 'F' if (x&(x-1)) else 'T'