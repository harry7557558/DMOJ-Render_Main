#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long lint;

int N, T;
struct Window {
	int x0, x1, y0, y1, t;
} W[1000];

int main() {
#ifdef _DEBUG
	freopen("stdin.dat", "r", stdin);
#endif

	scanf("%d", &N);
	scanf("%d", &T);
	vector<int> Ys; Ys.reserve(2 * N);
	for (int i = 0; i < N; i++) {
		Window w;
		scanf("%d%d%d%d%d", &w.x0, &w.y0, &w.x1, &w.y1, &w.t);
		Ys.push_back(w.y0); Ys.push_back(w.y1);
		W[i] = w;
	}
	std::sort(Ys.begin(), Ys.end());
	Ys.erase(std::unique(Ys.begin(), Ys.end()), Ys.end());

	lint tot = 0;
	struct ad {
		int x; int dt;
	};
	vector<ad> As; As.reserve(2 * N);
	for (int i = 0; i < Ys.size(); i++) {
		int y = Ys[i];
		As.clear();
		for (int i = 0; i < N; i++) {
			Window w = W[i];
			if (y >= w.y0 && y < w.y1) {
				ad t; t.x = w.x0, t.dt = w.t;
				As.push_back(t);
				t.x = w.x1, t.dt = -w.t;
				As.push_back(t);
			}
		}
		std::sort(As.begin(), As.end(), [](ad a, ad b) { return a.x < b.x; });
		lint sm = 0, sm1;
		for (int j = 0; j < As.size(); j++) {
			sm1 = sm + As[j].dt;
			if (sm >= T) {
				tot += lint(As[j].x - As[j - 1].x) * lint(Ys[i + 1] - Ys[i]);
			}
			sm = sm1;
		}
	}
	printf("%lld\n", tot);

	return 0;
}