import sys
N = int(sys.stdin.readline())
M = [int(t) for t in sys.stdin.read().split()]
_ = 1000000007
d = 1
for i in range(N):
    d=(M[i*N+i]*d)%_
    v = -pow(M[i*N+i],_-2,_)
    for j in range(i+1,N):
        if M[j*N+i]:
            m=M[j*N+i]*v%_
            for k in range(i,N):
                M[j*N+k]=(M[j*N+k]+M[i*N+k]*m)%_
print((d+_)%_)