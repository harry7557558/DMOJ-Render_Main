#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#include <bits/stdc++.h>
using namespace std;

#if _DEBUG
std::ifstream fin("stdin.dat");
#define cin fin
#endif

typedef long long lint;

lint Prime[100000];

bool isPrime0(lint n) {
	if (n < 2) return false;
	if (n <= 3) return true;
	if (n % 2 == 0 || n % 3 == 0) return false;
	for (int i = 4, k = sqrt(n); i <= k; i += 6) {
		if (n % (i + 1) == 0) return false;
		if (n % (i + 3) == 0) return false;
	}
	return true;
}

void init() {
	lint p = 2;
	for (int i = 0; i < 100000; i++) {
		while (!isPrime0(p)) p++;
		Prime[i] = p++;
	}
}

lint mul(lint a, lint b, lint m) {
	a %= m, b %= m;
	if (a <= 0xFFFFFFF && b <= 0xFFFFFFF) return (a * b) % m;
	if (b > a) swap(a, b);
	lint r = 0;
	while (a > 0 && b > 0) {
		if (b & 1) {
			r += a;
			if (r >= m) r -= m;
		}
		a <<= 1;
		if (a >= m) a -= m;
		b >>= 1;
	}
	return r;
}
lint pow(lint x, lint e, lint m) {
	lint r = 1;
	x %= m;
	while (e) {
		if (e & 1) r = mul(r, x, m);
		e >>= 1;
		x = mul(x, x, m);
	}
	return r;
}

bool isPrime(lint p) {
	if (p < 1300000) return isPrime0(p);
	for (int i = 0; i < 100000; i++) {
		if (p == Prime[i]) return true;
		if (p%Prime[i] == 0) return false;
	}
	for (int i = 2; i < 100; i++) {
		if (pow(i, p - 1, p) != 1) return false;
	}
	return true;
}

lint phi(lint x, lint a, int sgn = 1) {
	if (a == 0) return sgn * x;
	if (a == 1) return sgn * (x - x / 2);
	if (a == 2) return sgn * (x - x / 2 - x / 3 + x / 6);
	lint result = 0;
	while (a > 3) {
		if (a < 100000 && x < Prime[a]) return result + sgn;
		a--;
		result += phi(x / Prime[a], a, -sgn);
	}
	return result + sgn * (x - x / 2 - x / 3 + x / 6 - x / 5 + x / 10 + x / 15 - x / 30);
}

lint Pi(lint x) {
	if (x < Prime[99999]) return distance(Prime, upper_bound(Prime, Prime + 100000, x));
	lint a = Pi(pow(x, 0.25));
	lint b = Pi(sqrt(x));
	lint c = Pi(cbrt(x));
	lint r = phi(x, a) + (b + a - 2) * (b - a + 1) / 2;
	for (lint i = a; i < b; i++) {
		lint k = x / Prime[i];
		r -= Pi(k);
		if (i < c) {
			lint bi = Pi(sqrt(k));
			for (lint j = i; j < bi; j++) r -= Pi(k / Prime[j]) - j;
		}
	}
	return r;
}


int main() {
	init();
	lint a, b; cin >> a >> b;
	cout << (Pi(b - 1) - Pi(a - 1)) << endl;
	return 0;
}