import sys
P = [i>1 for i in range(int(input())+2)]
[sys.stdout.write((str(i)+'*\n' if P[i-2]|P[i+2] else str(i)+'\n') if P[i] and len([P.__setitem__(j,0) for j in range(i+i,len(P),i)])+1 else "") for i in range(2,len(P)-2)]