N = int(input())
H = [int(t) for t in input().split()]
Q = int(input())
while Q:
    c = [int(t) for t in input().split()]
    if c[0] == 1:
        i = c[1]
        j = c[2] + 1
        a = c[3]
        b = c[4]
        count = 0
        for k in range(i,j):
            if H[k]>=a and H[k]<=b:
                count += 1
        print(count)
    else:
        H[c[1]] = c[2]
    Q -= 1