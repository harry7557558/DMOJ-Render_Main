#include <stdio.h>
#include <thread>
#include <chrono>
int main(){
    printf("%d\n",std::thread::hardware_concurrency());
    //std::thread T([](const char* s){printf("%s\n",s);},"Hello, World!");
    std::this_thread::sleep_for(std::chrono::microseconds(1));
}