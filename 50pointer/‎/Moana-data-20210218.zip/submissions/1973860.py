R, C = [int(t) for t in raw_input().split()]
i0, j0 = [int(t) for t in raw_input().split()]
i1, j1 = [int(t) for t in raw_input().split()]
S = s = []
INF = float('inf')
for i in range(R):
    S.append([c for c in raw_input()])
    for j in range(C):
        if S[i][j]=='O': S[i][j]=INF
T = [[False for i in range(C)] for j in range(R)]
Tn = int(input())
for t in range(Tn):
    i, j = raw_input().split()
    T[int(i)][int(j)] = True

def dbgPrint(k):
    for i in range(R):
        for j in range(C):
            print(str(k[i][j])[0],)
        print()
    print()

def Spread(i,j,d):
    if i>0 and S[i-1][j]!='X' and S[i-1][j]>d:
        S[i-1][j]=d
    if j>0 and S[i][j-1]!='X' and S[i][j-1]>d:
        S[i][j-1]=d
    if i+1<R and S[i+1][j]!='X' and S[i+1][j]>d:
        S[i+1][j]=d
    if j+1<C and S[i][j+1]!='X' and S[i][j+1]>d:
        S[i][j+1]=d

S[i0][j0] = 0
D0 = 0
while S[i1][j1]==INF:
    for i in range(R):
        for j in range(C):
            if S[i][j]==D0:
                Spread(i,j,D0+1)
    D0 = D0 + 1
    #dbgPrint(S)
D0 = S[i1][j1]

for i in range(R):
    for j in range(C):
        if S[i][j]!='X':
            S[i][j]=INF
S[i0][j0] = 0
D1 = 0
while S[i1][j1]==INF:
    for i in range(R):
        for j in range(C):
            if S[i][j]==D1:
                if T[i][j] and S[i1][j1]>D1:
                    S[i1][j1] = D1
                Spread(i,j,D1+1)
    D1 = D1 + 1
    #dbgPrint(S)
D1 = S[i1][j1]
print(D0-D1)