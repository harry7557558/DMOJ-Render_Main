P = [[i,i>1] for i in range(int(raw_input())+2)]
for U in P:
    for j in range(U[0]*2,len(P),U[0]if U[0]else len(P)): P[j][1]&=not U[1]
    if U[1]:print (lambda: str(U[0])+'*' if P[U[0]-2][1] or P[U[0]+2][1] else U[0])()