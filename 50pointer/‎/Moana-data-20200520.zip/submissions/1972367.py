M = [[],[],[]]
for i in range(3):
    M[i] = input().split()
    for j in range(3):
        if (M[i][j]!='X'):
            M[i][j] = int(M[i][j])

def fill(K):
    for i in range(3):
        if K[i][0]=='X' and K[i][1]!='X' and K[i][2]!='X': K[i][0] = 2*K[i][1]-K[i][2]
        if K[i][0]!='X' and K[i][1]=='X' and K[i][2]!='X': K[i][1] = (K[i][0]+K[i][2])//2
        if K[i][0]!='X' and K[i][1]=='X' and K[i][2]!='X': K[i][2] = 2*K[i][1]-K[i][0]
        if K[0][i]=='X' and K[1][i]!='X' and K[2][i]!='X': K[0][i] = 2*K[1][i]-K[2][i]
        if K[0][i]!='X' and K[1][i]=='X' and K[2][i]!='X': K[1][i] =(K[0][i]+K[2][i])//2
        if K[0][i]!='X' and K[1][i]=='X' and K[2][i]!='X': K[2][i] = 2*K[1][i]-K[0][i]

fill(M)

for i in range(3):
    for j in range(3):
        print(M[i][j],end='')
        if j==2: print()
        else: print(end=' ')