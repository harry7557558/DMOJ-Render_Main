#pragma GCC optimize "Os"
#include <bits/stdc++.h>
using namespace std;

#define MAX_I 1800000
char _i[MAX_I], _, __; int i0 = 0;
#define scanu(x) do{while((x=_i[i0++])<'0');for(x-='0';'0'<=(_=_i[i0++]);x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=_i[i0++])<45);if(__-45)x=__;else x=_i[i0++];for(x-=48;47<(_=_i[i0++]);x=x*10+_-48);if(__<46)x=-x;}while(0)


int S[100000];

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	_i[fread(_i, 1, MAX_I, stdin)] = 0;
#else
	_i[fread_unlocked(_i, 1, MAX_I, stdin)] = 0;
#endif
	int I; scanu(I);
	int N; scanu(N);
	int J; scanu(J);
	while (J--) {
		int xi, xf, k; scanu(xi); scanu(xf); scanu(k);
		S[xi - 1] += k, S[xf] -= k;
	}
	int count = S[0] < N;
	for (int i = 1; i < I; i++) {
		count += (S[i] += S[i - 1]) < N;
	}
	printf("%d\n", count);
	return 0;
}