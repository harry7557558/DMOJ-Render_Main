#include <bits/stdc++.h>
using namespace std;

#define X 0x3FFFFFFF

int main() {

	// readin
	int A[3][3];
	char s[12];
	for (int i = 0; i < 9; i++) {
		scanf("%s", &s);
		(&A[0][0])[i] = s[0] == 'X' ? X : stoi(s);
	}

	// reducing terms
#define sgX(a, b, c) (a==X && b!=X && c!=X)
#define to0(_0, _1, _2) _0 = 2*_1 - _2
#define to1(_0, _1, _2) _1 = (_0 + _2) / 2
#define to2(_0, _1, _2) _2 = 2*_1 - _0
	bool opr;
	do {
		opr = false;
		for (int i = 0; i < 3; i++) {
			if (opr |= sgX(A[i][0], A[i][1], A[i][2])) to0(A[i][0], A[i][1], A[i][2]);
			if (opr |= sgX(A[i][1], A[i][0], A[i][2])) to1(A[i][0], A[i][1], A[i][2]);
			if (opr |= sgX(A[i][2], A[i][0], A[i][1])) to2(A[i][0], A[i][1], A[i][2]);
			if (opr |= sgX(A[0][i], A[1][i], A[2][i])) to0(A[0][i], A[1][i], A[2][i]);
			if (opr |= sgX(A[1][i], A[0][i], A[2][i])) to1(A[0][i], A[1][i], A[2][i]);
			if (opr |= sgX(A[2][i], A[0][i], A[1][i])) to2(A[0][i], A[1][i], A[2][i]);
		}
	} while (opr);

	for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
		printf("%d%c", A[i][j], j == 2 ? '\n' : ' ');
	}
	return 0;
}