#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

string P, S;
int Pf[128], Ps[128];
int N, M;
int Count = 0;

vector<string> k;

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> P >> S;
	N = P.size(), M = S.size();
	if (M < N) { printf("0\n"); return 0; }
	sort(&P[0], &P[N]);
	for (int i = 0; i < N; i++) Pf[P[i]]++;
	for (int i = N; i <= M; i++) {
		for (char c = 'a'; c <= 'z'; c++) Ps[c] = 0;
		for (int j = i - N; j < i; j++) Ps[S[j]]++;
		bool equal = true;
		for (char c = 'a'; c <= 'z'; c++) {
			if (Ps[c] != Pf[c]) { equal = false; break; }
		}
		if (equal) {
			string t = S.substr(i - N, N);
			bool ok = true;
			for (int d = 0; d < k.size(); d++) {
				if (k[d] == t) { ok = false; break; }
			}
			if (ok) k.push_back(t);
		}
	}
	Count = k.size();
	printf("%d\n", Count);
	return 0;
}