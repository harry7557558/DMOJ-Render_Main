#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	int N; cin >> N;
	double *A = new double[N];
	for (int i = 0; i < N; i++) {
		string s; cin >> s;
		cin >> A[i];
	}
	sort(A, A + N);
	double dA = A[0] + 360. - A[N - 1];
	for (int i = 1; i < N; i++) {
		dA = max(dA, A[i] - A[i - 1]);
	}
	double u = (360. - dA)*12.;
	cout << (int)ceil(u) << endl;
}