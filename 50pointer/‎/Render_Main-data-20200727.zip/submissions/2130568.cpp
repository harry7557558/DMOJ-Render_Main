#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)



// 2D vector template
class ivec2 {
public:
	int x, y;
	ivec2() {}
	ivec2(int a) :x(a), y(a) {}
	ivec2(int x, int y) :x(x), y(y) {}
	bool operator == (ivec2 v) const { return x == v.x && y == v.y; }
	ivec2 operator - () const { return ivec2(-x, -y); }
	ivec2 operator + (ivec2 v) const { return ivec2(x + v.x, y + v.y); }
	ivec2 operator - (ivec2 v) const { return ivec2(x - v.x, y - v.y); }
	ivec2 operator * (int a) const { return ivec2(x*a, y*a); }
	int sqr() const { return x * x + y * y; }
	friend int dot(ivec2 u, ivec2 v) { return u.x*v.x + u.y*v.y; }
	friend int det(ivec2 u, ivec2 v) { return u.x*v.y - u.y*v.x; }
	ivec2 rot() const { return ivec2(-y, x); }  // rotate 90deg counterclockwise
};

#define clamp(x,a,b) ((x)<(a)?(a):(x)>(b)?(b):(x))


void convexHull(ivec2 *P, int Pn, ivec2 *C, int &Cn) {
	sort(P, P + Pn, [](ivec2 p, ivec2 q) { return p.x == q.x ? p.y < q.y : p.x < q.x; });
	C[Cn++] = P[0];
	for (int i = 1; i < Pn;) {
		if (Cn == 1) C[Cn++] = P[i];
		else {
			if (det(C[Cn - 1] - C[Cn - 2], P[i] - C[Cn - 2]) <= 0) {
				C[Cn - 1] = P[i];
				while (Cn > 2 && det(C[Cn - 2] - C[Cn - 3], C[Cn - 1] - C[Cn - 3]) <= 0) Cn--, C[Cn - 1] = P[i];
			}
			else C[Cn++] = P[i];
		}
		do { i++; } while (i < Pn && P[i].x == P[i - 1].x);
	}
	for (int i = Pn - 1; i >= 0;) {
		if (i == Pn - 1) {
			if (!(C[Cn - 1] == P[i])) C[Cn++] = P[i];
		}
		else {
			if (det(C[Cn - 1] - C[Cn - 2], P[i] - C[Cn - 2]) < 0) {
				C[Cn - 1] = P[i];
				while (det(C[Cn - 2] - C[Cn - 3], C[Cn - 1] - C[Cn - 3]) < 0) Cn--, C[Cn - 1] = P[i];
			}
			else C[Cn++] = P[i];
		}
		do { i--; } while (i >= 0 && P[i].x == P[i + 1].x);
	}
	if (C[Cn - 1] == C[0]) Cn--;

}




#define MAXN 4000
ivec2 P[MAXN]; int N;
ivec2 C[MAXN]; int Cn = 0;


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	scanu(N);
	for (int i = 0; i < N; i++) {
		int x, y;
		scan(x); scan(y);
		P[i] = ivec2(x, y);
	}
	convexHull(P, N, C, Cn);

	int MaxA = 0;
	for (int i = 0; i < Cn; i++) {
		for (int j = 0; j < i; j++) {
			ivec2 ij = C[j] - C[i];
			for (int k = 0; k < j; k++) {
				int A = abs(det(ij, C[k] - C[i]));
				if (A > MaxA) MaxA = A;
			}
		}
	}

	printf("%d", MaxA / 2);
	if (MaxA & 1) printf(".005\n");
	else printf(".000\n");

	return 0;
}