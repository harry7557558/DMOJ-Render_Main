#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;


typedef long long lint;
#define INF 2000000000000000000

class ivec2 {
public:
	lint x, y;
	ivec2() {}
	explicit ivec2(lint a) :x(a), y(a) {}
	ivec2(lint x, lint y) :x(x), y(y) {}
	bool operator == (ivec2 v) const { return x == v.x && y == v.y; }
	ivec2 operator - () const { return ivec2(-x, -y); }
	ivec2 operator + (ivec2 v) const { return ivec2(x + v.x, y + v.y); }
	ivec2 operator - (ivec2 v) const { return ivec2(x - v.x, y - v.y); }
	ivec2 operator * (lint a) const { return ivec2(x*a, y*a); }
	lint sqr() const { return x * x + y * y; }
	friend lint dot(ivec2 u, ivec2 v) { return u.x*v.x + u.y*v.y; }
	friend lint det(ivec2 u, ivec2 v) { return u.x*v.y - u.y*v.x; }
	ivec2 rot() const { return ivec2(-y, x); }
};

class Point :public ivec2 {
public:
	int id;
};

void convexHull(Point *P, int Pn, Point *C, int &Cn) {
	std::sort(P, P + Pn, [](Point p, Point q) { return p.x == q.x ? p.y < q.y : p.x < q.x; });
	Cn = 0; C[Cn++] = P[0];
	for (int i = 1; i < Pn;) {
		if (Cn == 1) C[Cn++] = P[i];
		else {
			if (det(C[Cn - 1] - C[Cn - 2], P[i] - C[Cn - 2]) <= 0) {
				C[Cn - 1] = P[i];
				while (Cn > 2 && det(C[Cn - 2] - C[Cn - 3], C[Cn - 1] - C[Cn - 3]) < 0) Cn--, C[Cn - 1] = P[i];
			}
			else C[Cn++] = P[i];
		}
		do { i++; } while (i < Pn && P[i].x == P[i - 1].x);
	}
	for (int i = Pn - 1; i >= 0;) {
		if (i == Pn - 1) {
			if (!(C[Cn - 1] == P[i])) C[Cn++] = P[i];
		}
		else {
			if (det(C[Cn - 1] - C[Cn - 2], P[i] - C[Cn - 2]) < 0) {
				C[Cn - 1] = P[i];
				while (det(C[Cn - 2] - C[Cn - 3], C[Cn - 1] - C[Cn - 3]) < 0) Cn--, C[Cn - 1] = P[i];
			}
			else C[Cn++] = P[i];
		}
		do { i--; } while (i >= 0 && P[i].x == P[i + 1].x);
	}
	if (C[Cn - 1] == C[0]) Cn--;
}



#define MAXN 800
Point P[MAXN], C[MAXN];
int N; lint KM;

lint maxTrigA[800][800], maxTrigId[800][800];

#include <chrono>

int main() {
	auto t0 = chrono::high_resolution_clock::now();
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
	cin >> N >> KM; KM *= 2;
	for (int i = 0; i < N; i++) {
		cin >> P[i].x >> P[i].y;
		P[i].id = i + 1;
	}
	lint mS = INF; int mv[4];
	if (KM == 2000000000000000000) {
		int Cn;
		convexHull(P, N, C, Cn);
		N = Cn;
		for (int i = 0; i < Cn; i++) P[i] = C[i];
		mS = 0;
		for (int i = 0; i < N; i++) {
			ivec2 I = P[i];
			for (int j = i + 1; j < N; j++) {
				ivec2 J = P[j], IJ = J - I;
				lint MS = 0; int mid = 0;
				for (int k = j + 1; k < N; k++) {
					ivec2 K = P[k], IK = K - I;
					lint S = det(IJ, IK);
					if (S > MS) MS = S, mid = P[k].id;
				}
				maxTrigA[i][j] = MS, maxTrigId[i][j] = mid;
			}
		}
		for (int i = 0; i < N; i++) {
			ivec2 I = P[i];
			for (int j = i + 1; j < N; j++) {
				ivec2 J = P[j], IJ = J - I;
				for (int k = j + 1; k < N; k++) {
					ivec2 K = P[k], IK = K - I;
					lint S = det(IJ, IK) + maxTrigA[i][k];
					if (S > mS) {
						mS = S;
						mv[0] = P[i].id, mv[1] = P[j].id, mv[2] = P[k].id, mv[3] = maxTrigId[i][k];
					}
				}
			}
		}
		goto Finish;
	}
	for (int i = 0; i < N; i++) {
		ivec2 I = P[i];
		for (int j = 0; j < N; j++) if (j != i) {
			ivec2 J = P[j];
			for (int k = 0; k < N; k++) if (k != i && k != j) {
				ivec2 K = P[k];
				lint S0 = det(I - K, J - K);
				for (int t = 0; t < N; t++) if (t != i && t != j && t != k) {
					ivec2 T = P[t];
					lint S1 = -det(I - T, J - T);
					if ((S0 > 0) == (S1 > 0)) {
						lint S = abs(S0 + S1);
						S = abs(S - KM);
						if (S < mS) {
							mS = S;
							mv[0] = P[i].id, mv[1] = P[k].id, mv[2] = P[j].id, mv[3] = P[t].id;
						}
					}
				}
			}
#ifndef __DEBUG
			if (chrono::duration<double>(chrono::high_resolution_clock::now() - t0).count() > 1.995) goto Finish;
#endif
		}
	}
Finish:;
	cout << mv[0] << " " << mv[1] << " " << mv[2] << " " << mv[3] << endl;
	return 0;
}