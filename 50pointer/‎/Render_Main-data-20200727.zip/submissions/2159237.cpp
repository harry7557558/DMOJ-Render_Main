#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

struct sofake {
	int a[6];
	int x = 0;
};

bool alike(sofake a, sofake b) {
	for (int i = 0; i < 6; i++) {
		bool ok = true;
		for (int j = 0; j < 6; j++) {
			if (a.a[(i + j) % 6] != b.a[j]) {
				ok = false;
				break;
			}
		}
		if (ok) return true;
		ok = true;
		for (int j = 0; j < 6; j++) {
			if (a.a[(i + j) % 6] != b.a[5 - j]) {
				ok = false;
				break;
			}
		}
		if (ok) return true;
	}
	return false;
}


int N;
sofake S[100001];

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> N;
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < 6; j++) {
			int t; cin >> t;
			S[i].a[j] = t, S[i].x ^= t;
		}
	}
	std::sort(S, S + N, [](sofake a, sofake b) {return a.x < b.x; });
	for (int i = 0; i < N; i++) {
		if (S[i + 1].x == S[i].x) {
			int j = i + 2; while (S[j].x == S[i].x) j++;
			for (int u = i; u < j; u++) for (int v = i; v < u; v++) {
				if (alike(S[u], S[v])) {
					printf("Twin snowflakes found.\n");
					return 0;
				}
			}
			i = j - 1;
		}
	}
	printf("No two snowflakes are alike.\n");
	return 0;
}