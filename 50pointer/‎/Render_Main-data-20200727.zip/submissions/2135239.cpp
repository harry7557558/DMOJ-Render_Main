#include <bits/stdc++.h>
using namespace std;

int main() {
	int N; cin >> N;
	while (N--) {
		//string A, B; cin >> A >> B;
		
		int a, b; cin >> a >> b;
		int c = a + b;
		if (c < 2) c = 2;
		if (c > 20) c = 20;
		cout << c << endl;
	}
}