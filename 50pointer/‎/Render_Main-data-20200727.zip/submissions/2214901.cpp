#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

string P, S;
int N;
int c[200000];
int Count = 0;

vector<string> k;

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> P >> S;
	N = P.size();
	for (int i = 0; i < N; i++) c[i] = 0;
	k.push_back(P);
	if (S.find(P, 0) != -1) Count++;
	int i = 0; while (i < N) {
		if (c[i] < i) {
			if (i & 1) swap(P[c[i]], P[i]);
			else swap(P[0], P[i]);
			c[i]++; i = 0;
			if (S.find(P, 0) != -1) {
				bool ok = true;
				for (int i = 0; i < k.size(); i++) {
					if (P == k[i]) { ok = false; break; }
				}
				if (ok) k.push_back(P), Count++;
			}
		}
		else {
			c[i] = 0; i++;
		}
	}
	cout << Count << endl;
	return 0;
}