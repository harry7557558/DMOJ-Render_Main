#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)


//====================== Primes ==============================

int Primes[100000], PrimeN = 0;

void initPrimes(int N = 1000000) {
	//Primes[0] = 1; PrimeN++;
	bool *p = new bool[N];
	for (int i = 0; i < N; i++) p[i] = true;
	int k = sqrt(N) + 1;
	for (int i = 2; i < N; i++) {
		if (p[i]) {
			if (i < k) for (int j = i * i; j < N; j += i) p[j] = false;
			Primes[PrimeN++] = i;
		}
	}
	delete p;
}

//====================== Factors ==============================

int *Factors[1000001], NFactor[1000001];
void initFactor(int N) {
	if (NFactor[N]) return;
	int N0 = N;
	int PFs[20], PFRep[20], PFn = 0;
	for (int t = 0; N > 1; t++) {
		int p = Primes[t];
		if (p*p > N) break;
		if (N%p == 0) {
			PFs[PFn] = p;
			PFRep[PFn] = 1;
			N /= p;
			while (N%p == 0) PFRep[PFn]++, N /= p;
			PFn++;
		}
	}
	if (N > 1) {
		PFs[PFn] = N;
		PFRep[PFn] = 1;
		PFn++;
	}
	int Fn = 1;
	for (int i = 0; i < PFn; i++) Fn *= PFRep[i] + 1;
	NFactor[N0] = Fn;
	int *F = Factors[N0] = new int[Fn];
	F[0] = 1; int tp = 1;
	for (int i = 0; i < PFn; i++) {
		int pd = PFs[i], *k = &F[tp];
		for (int r = 1; r <= PFRep[i]; r++) {
			for (int t = 0; t < tp; t++) *k = pd * F[t], k++;
			pd *= PFs[i];
		}
		tp *= PFRep[i] + 1;
	}
	sort(F, F + Fn);
	Fn = Fn / 2 + (Fn & 1);
}


//====================== Global Vars ==============================

#define INF 0x7FFFFFFF

int G[1001][1001];
int S[1001][1001];
int M, N;

int aR[1000000], aC[1000000], aN = 0;
int a0R[1000000], a0C[1000000], a0N = 0;


//====================== Main ==============================

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	scanu(M); scanu(N);
	for (int i = 1; i <= M; i++) for (int j = 1; j <= N; j++) {
		int t; scanu(t);
		G[i][j] = t;
		S[i][j] = INF;
	}
	S[1][1] = 0;
	a0R[0] = a0C[0] = 1, a0N = 1;
	initPrimes();

	bool opr; int d = 1;
	do {
		opr = false;
		aN = 0;
		for (int u = 0; u < a0N; u++) {
			int i = a0R[u], j = a0C[u];
			int P = G[i][j];
			initFactor(P);
			int *F = Factors[P], Fn = NFactor[P];
			for (int t = 0; t < Fn; t++) {
				int r = F[t], c = P / F[t];
				if (r <= M && c <= N) if (S[r][c] > d) {
					S[r][c] = d, opr = true;
					aR[aN] = r, aC[aN] = c, aN++;
				}
				swap(r, c);
				if (r <= M && c <= N) if (S[r][c] > d) {
					S[r][c] = d, opr = true;
					aR[aN] = r, aC[aN] = c, aN++;
				}
			}
			if (S[M][N] != INF) {
				printf("yes\n");
				return 0;
			}
		}
		d++;
		a0N = aN;
		for (int u = 0; u < aN; u++) a0C[u] = aC[u], a0R[u] = aR[u];
	} while (opr);

	printf("no\n");
	return 0;
}