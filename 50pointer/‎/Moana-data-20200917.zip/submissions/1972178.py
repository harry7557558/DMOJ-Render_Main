def k(x, y):
    while x!=0 and y!=0:
        if x%3==1 and y%3==1:
            return ' '
        x//=3
        y//=3
    return '*'

d = int(input())
while d:
    n = int(input())
    b = int(input())
    t = int(input())
    l = int(input())
    r = int(input())
    for i in range(t-1,b-2,-1):
        for j in range(l-1,r):
            print(k(i,j),end='')
            if (j==r-1): print()
            else: print(end=' ')
    d = d - 1