x = int(input())
m = int(input())
for i in range(m):
    if i*x%m==1:
        print(i)
        exit()
print("No such integer exists.")