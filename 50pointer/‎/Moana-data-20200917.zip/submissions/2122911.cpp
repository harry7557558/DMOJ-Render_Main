#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long lint;
#define Mod 1000000007

int N;
#define MAXN 2048
lint A[MAXN], R[MAXN], T[MAXN];
lint X[MAXN];

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> N;
	for (int i = 0; i < N; i++) cin >> X[i];
	int M; cin >> M;
	for (int i = 0; i < N; i++) A[i] = 1;
	R[N - 1] = 1;
	while (M) {
		if (M & 1) {
			for (int i = 0; i < N; i++) {
				T[i] = 0;
				for (int u = i, v = N - 1; u < N; u++, v--) {
					T[i] = (T[i] + R[u] * A[v]) % Mod;
				}
			}
			for (int i = 0; i < N; i++) R[i] = T[i];
		}
		M >>= 1;
		for (int i = 0; i < N; i++) {
			T[i] = 0;
			for (int u = i, v = N - 1; u < N; u++, v--) {
				T[i] = (T[i] + A[u] * A[v]) % Mod;
			}
		}
		for (int i = 0; i < N; i++) A[i] = T[i];
	}
	for (int i = 0; i < N; i++) {
		T[i] = 0;
		for (int u = N - i - 1, v = 0; u < N; u++, v++) {
			T[i] = (T[i] + R[u] * X[v]) % Mod;
		}
		cout << T[i] << (i == N - 1 ? '\n' : ' ');
	}
	return 0;
}