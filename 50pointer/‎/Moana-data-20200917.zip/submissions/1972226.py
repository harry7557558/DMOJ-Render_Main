import math
N = int(input())
while N > 0:
    n = int(input())
    if n >= 4294967291:
        print(0)
    else:
        print(math.factorial(n)%4294967291)
    N -= 1