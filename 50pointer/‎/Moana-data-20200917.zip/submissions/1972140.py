T = int(input())
q = (T//5)*14
r = T%5
if r==0: q+=1
elif r==1: q+=3
elif r==2: q+=7
elif r==3: q+=9
else: q+=11
print(q)