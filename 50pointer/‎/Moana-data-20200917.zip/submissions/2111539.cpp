#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

//typedef long long lint;
#define lint int

#ifndef __DEBUG
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

char _, __, _o[20];
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)
#define print(x) do{_=0;do _o[_++]=x%10;while(x/=10);while(_--)putchar(_o[_]+'0');}while(0)

#define MAXN 100000
struct Friend {
	lint x;  // (x,0)
	int vx, vy;
} F[MAXN];


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	//freopen("stdout.dat", "w", stdout);
#endif
	int N; scanu(N);
	lint L, R, Y; scan(L); scan(R); scan(Y);
	for (int i = 0; i < N; i++) {
		lint t; scan(t); F[i].x = t;
		scanu(t); F[i].vy = t; scanu(t); F[i].vx = t;
	}
	R++;

	lint dX = R - L;
	int *V = new int[dX];
	int *S = new int[N + 1];
	for (int i = 0; i < dX; i++) V[i] = -1;
	for (int i = 0; i <= N; i++) S[i] = dX;

	for (int d = 0; d < N; d++) {
		Friend Fd = F[d];
		int X = Y * Fd.vx;
		if (X % Fd.vy == 0) X--; X /= Fd.vy;
		lint i0 = max(Fd.x - X, L), i1 = min(Fd.x + X + 1, R);
		int* Vi = &V[i0 - L];
		for (lint i = 0, im = i1 - i0; i < im; i++) {
			S[++Vi[i]]--;
		}
	}

	for (int i = 0; i <= N; i++) {
		print(S[i]); putchar('\n');
		//printf("%d\n", S[i]);
	}
	return 0;
}