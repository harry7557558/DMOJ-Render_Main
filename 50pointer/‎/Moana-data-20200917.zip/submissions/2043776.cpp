#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

int h[2 << 13];

int main() {
	int N; scanf("%d", &N);
	for (int i = 0; i < N; i++) cin >> h[i];
	int Q; scanf("%d", &Q);
	while (Q--) {
		int cmd; scanf("%d", &cmd);
		if (cmd == 1) {
			int i, j, a, b; scanf("%d%d%d%d", &i, &j, &a, &b);
			int c = 0;
			for (int k = i; k <= j; k++) c += h[k] >= a && h[k] <= b;
			printf("%d\n", c);
		}
		else {
			int i, w; scanf("%d%d", &i, &w);
			h[i] = w;
		}
	}
	return 0;
}