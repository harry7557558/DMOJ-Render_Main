import math
def isprime(N):
    if N<2: return False
    if N==2 or N==3: return True
    if N%2==0 or N%3==0: return False
    k = int(math.sqrt(N))
    for i in range(4,k,6):
        if N%(i+1)==0 or N%(i+3)==0: return False
    return True

N = int(input())
a0 = 0
b0 = 0
c0 = 0
while N > 0:
    a, b = [int(t) for t in input().split()]
    if a==a0 and b==b0:
        print(c0)
    else:
        c = 0
        for i in range(a,b):
            if isprime(i): c += 1
        print(c)
    a0, b0, c0 = [a, b, c]
    N -= 1