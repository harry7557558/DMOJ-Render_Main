#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

//typedef long long lint;
#define lint int

#ifndef __DEBUG
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#define fread fread_unlocked
#define fwrite fwrite_unlocked
#endif

#define INPUT_SIZE 1<<22
#define OUTPUT_SIZE 1<<22
int _i0 = 0, _o0 = 0;
char _, _n, __[20], _i[INPUT_SIZE], _o[OUTPUT_SIZE];
#define scanu(x) do{while((_=_i[_i0++])<48);for(x=_-48;47<(_=_i[_i0++]);x=x*10+_-48);}while(0)
#define scan(x) do{while((_n=_i[_i0++])<45);if(_n-45)x=_n;else x=_i[_i0++];for(x-=48;47<(_=_i[_i0++]);x=x*10+_-48);if(_n<46)x=-x;}while(0)
inline void putnumu(int x) { _ = 0; do __[_++] = x % 10; while (x /= 10); while (_--)_o[_o0++] = __[_] + '0'; }

#define MAXN 100000
struct Friend {
	lint x;  // (x,0)
	int vx, vy;
} F[MAXN];

struct node {
	lint x;
	int val;
	node *last = 0, *next = 0;
};


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	//freopen("stdout.dat", "w", stdout);
#endif
	fread(_i, 1, INPUT_SIZE, stdin);
	int N; scanu(N);
	lint L, R, Y; scan(L); scan(R); scan(Y);
	for (int i = 0; i < N; i++) {
		lint t; scan(t); F[i].x = t;
		scanu(t); F[i].vy = t; scanu(t); F[i].vx = t;
	}
	R++;

	lint dX = R - L;
	node Key{ L,0 }, KeyEnd{ R,0 };
	Key.next = &KeyEnd, KeyEnd.last = &Key;

	auto insertNode = [&](lint d)->node* {
		node* u = &Key;
		while (u->x < d) u = u->next;
		if (u->x == d) {
			return u;
		}
		else {
			node* v = u->last;
			u->last = v->next = new node{ d, v->val };
			u->last->last = v, u->last->next = u;
			return u->last;
		}
	};
	auto insertInterval = [&](lint i0, lint i1) {
		node* d0 = insertNode(i0);
		node* d1 = insertNode(i1);
		while (d0 != d1) {
			d0->val++;
			d0 = d0->next;
		}
	};

	for (int d = 0; d < N; d++) {
		Friend Fd = F[d];
		int X = Y * Fd.vx;
		if (X % Fd.vy == 0) X--; X /= Fd.vy;
		lint i0 = max(Fd.x - X, L), i1 = min(Fd.x + X + 1, R);
		insertInterval(i0, i1);
	}

	for (int T = 0; T <= N; T++) {
		int Count = 0;
		node *u = &Key;
		while (u->next) {
			if (u->val <= T) Count += u->next->x - u->x;
			u = u->next;
		}
		putnumu(Count); _o[_o0++] = '\n';
	}
	fwrite(_o, 1, _o0, stdout);
	return 0;
}