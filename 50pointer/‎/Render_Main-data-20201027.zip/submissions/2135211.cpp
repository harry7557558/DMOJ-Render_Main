#include <iostream>
using namespace std;

int main() {
	int N; cin >> N;
	while (N--) {
		int a, b; cin >> a >> b;
		if (a < 1) a = 1;
		if (b < 1) b = 1;
		int c = a + b;
		if (c > 10) c = 10;
		cout << c << endl;
	}
}