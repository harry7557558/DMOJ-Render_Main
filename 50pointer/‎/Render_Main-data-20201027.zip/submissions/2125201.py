N = input()
for i in range(N):
    x = input()
    print 'F' if (x&(x-1)) else 'T'