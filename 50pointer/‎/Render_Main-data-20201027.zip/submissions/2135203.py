N = input()
for i in range(N):
    a, b = [int(t) for t in raw_input().split()]
    print(a+b)