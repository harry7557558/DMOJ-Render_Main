#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;


#define MAXN 100
int G0[MAXN][MAXN], G[MAXN][MAXN];
char s[MAXN];
int N, M;

int sX[MAXN*MAXN], sY[MAXN*MAXN], sN = 0;
int PosX, PosY;

#define INF 99999
#define W -1

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> N >> M;
	for (int i = 0; i < N; i++) {
		cin >> s;
		for (int j = 0; j < M; j++) {
			G0[i][j] = s[j] == 'W' ? W : s[j] == 'S' ? 0 : INF;
			if (s[j] == '.') sX[sN] = j, sY[sN] = i, sN++;
			if (s[j] == 'S') PosX = j, PosY = i;
		}
	}

	for (int i = 0; i < N; i++) for (int j = 0; j < M; j++) G[i][j] = G0[i][j];
	bool opr; int d = 0;
	do {
		opr = false;
		for (int i = 0; i < N; i++) for (int j = 0; j < M; j++) if (G[i][j] == d) {
			if (G[i - 1][j] != W) if (G[i - 1][j] > d + 1) G[i - 1][j] = d + 1, opr = true;
			if (G[i + 1][j] != W) if (G[i + 1][j] > d + 1) G[i + 1][j] = d + 1, opr = true;
			if (G[i][j - 1] != W) if (G[i][j - 1] > d + 1) G[i][j - 1] = d + 1, opr = true;
			if (G[i][j + 1] != W) if (G[i][j + 1] > d + 1) G[i][j + 1] = d + 1, opr = true;
		}
		d++;
	} while (opr);

	for (int i = 0; i < sN; i++) {
		int r = G[sY[i]][sX[i]];
		if (r == INF) r = -1;
		cout << r << endl;
	}

	return 0;
}