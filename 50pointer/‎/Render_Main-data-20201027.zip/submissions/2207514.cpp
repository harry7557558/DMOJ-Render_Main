#pragma GCC optimize "Ofast"

void multiply_matrices(double a[16][2304], double b[2304][256], double c[16][256]) {
	for (int i = 0; i < 16; i++) for (int j = 0; j < 256; j++) {
		c[i][j] = 0;
		for (int k = 0; k < 2304; k++) c[i][j] += a[i][k] * b[k][j];
	}
}