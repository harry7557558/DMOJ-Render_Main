#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
#include <chrono>
using namespace std;

typedef long long lint;
typedef unsigned char byte;
#define inf 0x7FFFFFFF
#define INF 0x7FFFFFFFFFFFFFFF

#define INPUT_SIZE 1<<24
int _i0 = 0;
char _, _n, __[20], _i[INPUT_SIZE];
#define readin _i[fread(_i, 1, INPUT_SIZE, stdin)]=0
#define scanu(x) do{while((_=_i[_i0++])<48);for(x=_-48;47<(_=_i[_i0++]);x=x*10+_-48);}while(0)
#define scan(x) do{while((_n=_i[_i0++])<45);if(_n-45)x=_n;else x=_i[_i0++];for(x-=48;47<(_=_i[_i0++]);x=x*10+_-48);if(_n<46)x=-x;}while(0)




#ifdef __DEBUG
#define Rand() (rand()*RAND_MAX+rand())
void randCase(int N) {
	freopen("stdout.dat", "w", stdout);
	printf("%d\n", N);
	for (int i = 0; i < N; i++) {
		printf("%d %d %d\n", Rand() % 1000000, Rand() % 1000000, Rand() % 1000000);
	}
	exit(0);
}
#endif



#define MAXN 10000
int N;
struct Triangle {
	int x, y, d;
} T[MAXN];

struct Add {
	int x; int val;
};
Add S[2 * MAXN]; int Sn = 0;

bool Ys[1048576];




struct Node {
	int b0, b1;
	Triangle T;
	Node *c1, *c2;
} R, Rx;

void createTree(Node* R, Triangle* T, int N) {
	if (N == 1) {
		R->b0 = T->y, R->b1 = T->y + T->d;
		R->T = T[0];
		R->c1 = R->c2 = 0;
	}
	else {
		R->c1 = new Node; createTree(R->c1, T, N / 2);
		R->c2 = new Node; createTree(R->c2, T + N / 2, N - N / 2);
		R->b0 = min(R->c1->b0, R->c2->b0);
		R->b1 = max(R->c1->b1, R->c2->b1);
	}
}

void searchTree(Node* R, int y) {
	if (!(R->c1 || R->c2)) {
		Triangle T = R->T;
		if (T.d && y >= T.y && y < T.y + T.d) {
			Add t; t.x = T.x, t.val = 1;
			S[Sn++] = t;
			t.x = T.x + T.d - (y - T.y), t.val = -1;
			S[Sn++] = t;
		}
	}
	else {
		if (y >= R->c1->b0 && y < R->c1->b1) searchTree(R->c1, y);
		if (y >= R->c2->b0 && y < R->c2->b1) searchTree(R->c2, y);
	}
}

void createTreeX(Node* R, Triangle* T, int N) {
	if (N == 1) {
		R->b0 = T->x, R->b1 = T->x + T->d;
		R->T = T[0];
		R->c1 = R->c2 = 0;
	}
	else {
		R->c1 = new Node; createTree(R->c1, T, N / 2);
		R->c2 = new Node; createTree(R->c2, T + N / 2, N - N / 2);
		R->b0 = min(R->c1->b0, R->c2->b0);
		R->b1 = max(R->c1->b1, R->c2->b1);
	}
}

void searchTreeX(Node* R, const Triangle &T) {
	if (!(R->c1 || R->c2)) {
		if (T.x == R->T.x && T.y == R->T.y && T.d == R->T.d) return;
		int y = R->T.d + R->T.x + R->T.y - T.x;
		if (y > T.y && y < T.y + T.d) Ys[y] = true;
	}
	else {
		if (T.x > R->c1->b0 && T.x < R->c1->b1) searchTreeX(R->c1, T);
		if (T.x > R->c2->b0 && T.x < R->c2->b1) searchTreeX(R->c2, T);
	}
}



int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	//srand(1); randCase(5436);
#endif
	auto t0 = chrono::high_resolution_clock::now();
	readin;
	scanu(N);
	for (int i = 0; i < N; i++) {
		int x, y, d;
		scanu(x); scanu(y); scanu(d);
		T[i].x = x, T[i].y = y, T[i].d = d;
	}
	//sort(T, T + N, [](Triangle a, Triangle b) {return a.y < b.y; });
	sort(T, T + N, [](Triangle a, Triangle b) {return a.y * 2 + a.d < b.y * 2 + b.d; });
	createTree(&R, T, N);
	lint Area = 0;

	/*for (int i = 0; i < N; i++) {
		printf("max(%d-x,%d-y,x+y%+d)=0\n", T[i].x, T[i].y, -(T[i].x + T[i].y + T[i].d));
	}*/

	int minY = inf, maxY = -inf;
	for (int i = 0; i < N; i++) {
		Ys[T[i].y] = true;
		Ys[T[i].y + T[i].d] = true;
		minY = min(minY, T[i].y);
		maxY = max(maxY, T[i].y + T[i].d);
	}
	//sort(T, T + N, [](Triangle a, Triangle b) {return a.x < b.x; });
	sort(T, T + N, [](Triangle a, Triangle b) {return a.x * 2 + a.d < b.x * 2 + b.d; });
	createTreeX(&Rx, T, N);
	for (int i = 0; i < N; i++) {
		searchTreeX(&Rx, T[i]);
	}
	if (N > 3000) printf("%lfsecs elapsed.\n", chrono::duration<double>(chrono::high_resolution_clock::now() - t0).count());
	vector<int> YS; YS.reserve(1000000);
	for (int i = minY; i <= maxY; i++) if (Ys[i]) YS.push_back(i);

	for (int i = 0; i < YS.size() - 1; i++) {
		int y = YS[i];
		Sn = 0;
		searchTree(&R, y);
		sort(S, S + Sn, [](Add a, Add b) { return a.x == b.x ? a.val < b.val : a.x < b.x; });
		int Sa = 0, A = 0;
		int i0, i1;
		for (int d = 0; d < Sn; d++) {
			if (!Sa) i0 = S[d].x;
			Sa += S[d].val;
			if (!Sa) {
				i1 = S[d].x;
				int h = YS[i + 1] - y;
				int b1 = i1 - i0, b0 = b1 - h;
				A += (b1 + b0)*h;
			}
		}
		Area += A;
	}

	printf("%lld", Area / 2);
	if (Area & 1) printf(".5\n");
	else printf(".0\n");

#ifdef __DEBUG
	printf("\n%lfsecs elapsed.\n", chrono::duration<double>(chrono::high_resolution_clock::now() - t0).count());
#endif

	return 0;
}