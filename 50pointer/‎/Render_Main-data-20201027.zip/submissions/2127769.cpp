// A copy-paste of my alt's solution

// add this three lines
#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"

#include <bits/stdc++.h>
using namespace std;

#define X 0x7FFFFFFF

int main() {
	int M[3][3];
	string s;
	for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
		cin >> s;
		M[i][j] = s == "X" ? X : stoi(s);
	}

	auto Transpose = [&]() {
		swap(M[0][1], M[1][0]);
		swap(M[0][2], M[2][0]);
		swap(M[1][2], M[2][1]);
	};

	auto isOK = [&]()->bool {
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) if (M[i][j] == X) return false;
			if (M[i][0] - 2 * M[i][1] + M[i][2]) return false;
			if (M[0][i] - 2 * M[1][i] + M[2][i]) return false;
		}
		return true;
	};

	auto E3 = [&]()->bool {
		bool oopr = false;
		auto E3Row = [&]() {
			bool opr;
			do {
				opr = false;
				for (int i = 0; i < 3; i++) {
					if (M[i][0] == X && M[i][1] != X && M[i][2] != X) M[i][0] = 2 * M[i][1] - M[i][2], opr = true;
					if (M[i][0] != X && M[i][1] == X && M[i][2] != X) M[i][1] = (M[i][0] + M[i][2]) / 2, opr = true;
					if (M[i][0] != X && M[i][1] != X && M[i][2] == X) M[i][2] = 2 * M[i][1] - M[i][0], opr = true;
				}
				if (opr) oopr = true;
			} while (opr);
		};
		E3Row(); Transpose(); E3Row(); Transpose();
		return oopr;
	};

	auto DL = [&]() {
		auto rowcpy = [&](int i, int j, int d) {
			for (int k = 0; k < 3; k++) {
				if (M[i][k] == X && M[j][k] != X) M[i][k] = M[j][k] - d;
				if (M[i][k] != X && M[j][k] == X) M[j][k] = M[i][k] + d;
			}
		};
		for (int t = 0; t < 2; t++) {
			for (int j = 0; j < 3; j++) {
				if (M[0][j] != X && M[1][j] != X) rowcpy(0, 1, M[1][j] - M[0][j]);
				if (M[1][j] != X && M[2][j] != X) rowcpy(1, 2, M[2][j] - M[1][j]);
			}
		}
	};

	int Max = -X, Min = X;

	do {} while (E3());

#define Try \
	while (E3()); \
	if (isOK()) goto Finish; \
	DL(); Transpose(); DL(); Transpose(); \
	while (E3()); \
	if (isOK()) goto Finish; \

	Try;

	for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) if (M[i][j] != X) Max = max(Max, M[i][j]), Min = min(Min, M[i][j]);
	if (Min == X) Max = Min = 0;

	while (1) {
		int N[3][3]; for (int i = 0; i < 9; i++) (&N[0][0])[i] = (&M[0][0])[i];
#define TTry \
		int d; do { d = rand() % 9; } while ((&M[0][0])[d] != X); \
		(&M[0][0])[d] = rand() % (Max - Min + 1) + Min; \
		Try;
		bool hX = false;
		do {
			TTry;
			hX = false;
			for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) if (M[i][j] == X) hX = true;
		} while (hX);
		for (int i = 0; i < 9; i++) (&M[0][0])[i] = (&N[0][0])[i];
	}

Finish:;
	for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) cout << M[i][j] << (j == 2 ? '\n' : ' ');
	return 0;
}