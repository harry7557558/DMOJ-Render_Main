def isprime(N):
    if N%2==0 or N%3==0: return False
    for i in range(4,int(N**.5),6):
        if N%(i+1)==0 or N%(i+3)==0: return False
    return True

print("2\n3*")
for i in range(5,int(raw_input())):
    if isprime(i): print str(i)+'*' if isprime(i-2) or isprime(i+2) else i