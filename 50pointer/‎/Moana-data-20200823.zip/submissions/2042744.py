import sys
N = int(sys.stdin.readline())
M = [int(t) for t in sys.stdin.read().split()]
_ = 1000000007
d = 1
for i in range(N):
    v = -pow(M[i*N+i],_-2,_)
    for j in range(i+1,N):
        m=M[j*N+i]
        if m:
            m=m*v%_
            for k in range(i,N):
                M[j*N+k]+=M[i*N+k]*m%_
    d=(M[i*N+i]*d)%_
print((d+_)%_)