N = int(input()); P = [i>1 for i in range(N+2)]
for i in range(2,N):
    if P[i]:
        for j in range(i+i,N+2,i): P[j]=False
        print(str(i)+'*' if P[i-2] or P[i+2] else i)