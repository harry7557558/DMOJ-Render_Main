#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

int h[2 << 13];

char _;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)

int main() {
	int N; scanu(N);
	for (int i = 0; i < N; i++) scanu(h[i]);
	int Q; scanu(Q);
	while (Q--) {
		int cmd; scanu(cmd);
		if (cmd == 1) {
			int i, j, a, b; scanu(i); scanu(j); scanu(a); scanu(b);
			int c = 0; j++, b = b - a + 1;
			while (i < j) c += (unsigned)(h[i++] - a) < b;
			printf("%d\n", c);
		}
		else {
			int i, w; scanu(i); scanu(w);
			h[i] = w;
		}
	}
	return 0;
}