#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

int h[2 << 13];

int main() {
	int N; cin >> N;
	for (int i = 0; i < N; i++) cin >> h[i];
	int Q; cin >> Q;
	while (Q--) {
		int cmd; cin >> cmd;
		if (cmd == 1) {
			int i, j, a, b; cin >> i >> j >> a >> b;
			int c = 0;
			for (int k = i; k <= j; k++) c += h[k] >= a && h[k] <= b;
			cout << c << endl;
		}
		else {
			int i, w; cin >> i >> w;
			h[i] = w;
		}
	}
	return 0;
}