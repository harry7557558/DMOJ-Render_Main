// a copy-paste solution after my primary account getting cloudflared

#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
//using namespace std;

#define PI 3.1415926535897932384626

struct complex { double re, im; };
inline complex expi(double x) { return complex{ cos(x), sin(x) }; }
inline complex operator + (complex a, complex b) { return complex{ a.re + b.re, a.im + b.im }; }
inline complex operator - (complex a, complex b) { return complex{ a.re - b.re, a.im - b.im }; }
inline complex operator * (double a, complex b) { return complex{ a*b.re, a*b.im }; }
inline complex operator * (complex a, complex b) { return complex{ a.re*b.re - a.im*b.im, a.re*b.im + a.im*b.re }; }

void FFT(complex* x, int n) {
	if (n == 1) return;
	int m = n / 2;
	complex *a0 = new complex[m], *a1 = new complex[m];
	for (int i = 0; i < m; i++) a0[i] = x[2 * i], a1[i] = x[2 * i + 1];
	FFT(a0, m); FFT(a1, m);
	complex wn = expi(-2.0*PI / n), w = complex{ 1,0 };
	for (int i = 0; i < m; i++) {
		complex t = a1[i] * w;
		x[i] = a0[i] + t;
		x[m + i] = a0[i] - t;
		w = w * wn;
	}
	delete a0;
	delete a1;
}

void invFFT(complex* x, int n) {
	if (n == 1) return;
	int m = n / 2;
	complex *a0 = new complex[m], *a1 = new complex[m];
	for (int i = 0; i < m; i++) a0[i] = x[2 * i], a1[i] = x[2 * i + 1];
	invFFT(a0, m); invFFT(a1, m);
	complex wn = expi(2.0*PI / n), w = complex{ 1,0 };
	for (int i = 0; i < m; i++) {
		complex t = a1[i] * w;
		x[i] = a0[i] + t;
		x[m + i] = a0[i] - t;
		w = w * wn;
	}
	delete a0;
	delete a1;
}

#define Max 0x200000
complex a[Max], b[Max];
int r[Max];

int main() {
	std::string as, bs;
	std::cin >> as >> bs;
	int m = 1 << ((int)ceil(log2(std::max(as.size(), bs.size()))) + 1);
	for (int i = 0, n = as.size(); i < n; i++) a[n - i - 1].re = as[i] - '0';
	for (int i = 0, n = bs.size(); i < n; i++) b[n - i - 1].re = bs[i] - '0';
	FFT(a, m);
	FFT(b, m);
	for (int i = 0; i < m; i++) a[i] = a[i] * b[i];
	invFFT(a, m);
	for (int i = 0; i < m; i++) r[i] = int(a[i].re / m + 0.5);
	int rem = 0;
	for (int i = 0; i < m; i++) {
		rem += r[i];
		r[i] = rem % 10, rem /= 10;
	}
	int u = m - 1;
	while (u > 0 && r[u] == 0) u--;
	while (u >= 0) putchar(r[u--] + '0');
	putchar('\n');
	return 0;
}