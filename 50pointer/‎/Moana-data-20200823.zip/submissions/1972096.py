while 1:
    s = input()
    if (s=='quit!'):
        break
    n = len(s)
    if n>4 and s[n-3] not in "aeiouy" and s[n-2]=='o' and s[n-1]=='r':
        s = s[:n-1] + 'ur'
    print(s)