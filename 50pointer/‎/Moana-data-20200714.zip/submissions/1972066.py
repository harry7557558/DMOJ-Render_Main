H = int(input())
for i in range(H):
    j = H - 2*abs(H//2-i)
    for u in range(0,j):
        print('*',end='')
    for u in range(j,H):
        print(' ',end='')
    for u in range(j,H):
        print(' ',end='')
    for u in range(0,j):
        print('*',end='')
    print()