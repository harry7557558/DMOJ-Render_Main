#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

typedef long long lint;

class ivec2 {
public:
	lint x, y;
	ivec2() {}
	ivec2(lint x, lint y) :x(x), y(y) {}
	bool operator == (ivec2 v) const { return x == v.x && y == v.y; }
	ivec2 operator - () const { return ivec2(-x, -y); }
	ivec2 operator + (ivec2 v) const { return ivec2(x + v.x, y + v.y); }
	ivec2 operator - (ivec2 v) const { return ivec2(x - v.x, y - v.y); }
	ivec2 operator * (lint a) const { return ivec2(x*a, y*a); }
	lint sqr() const { return x * x + y * y; }
	friend lint dot(ivec2 u, ivec2 v) { return u.x*v.x + u.y*v.y; }
	friend lint det(ivec2 u, ivec2 v) { return u.x*v.y - u.y*v.x; }
	ivec2 rot() const { return ivec2(-y, x); }  // rotate 90deg counterclockwise
};

#define MAXN 4000
ivec2 R[MAXN]; lint W[MAXN];
lint N;

int main() {
#ifdef _DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> N;
	lint totW = 0;
	for (lint i = 0; i < N; i++) {
		cin >> R[i].x >> R[i].y >> W[i];
		totW += W[i];
	}
	lint maxW = -0x7FFFFFFFFFFFFFFF;
	for (lint i = 0; i < N; i++) {
		for (lint j = 0; j < i; j++) {
			ivec2 n = (R[j] - R[i]).rot();
			lint d = dot(n, R[j]);
			lint W0 = 0, W1 = 0, E = 0;
			for (lint k = 0; k < N; k++) {
				lint w = dot(R[k], n) - d;
				if (w > 0) W0 += W[k];
				if (w < 0) W1 += W[k];
				if (w == 0) if (W[k] > 0) E += W[k];
			}
			maxW = max(maxW, max(W0, W1) + E);
		}
	}
	cout << maxW << endl;
	return 0;
}