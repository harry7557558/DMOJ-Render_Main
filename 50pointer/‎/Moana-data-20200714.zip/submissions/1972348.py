import math
H, V = [int(t) for t in input().split()]
count = H*(H-1)*V*(V-1)//4
for m in range(1,H-1):
    for n in range(1,V-m):
        if math.gcd(m,n)==1:
            km = min((H-n)//m,(V-m)//n) + 1
            for k in range(1,km):
                lm = min((H-k*m)//n,(V-k*n)//m) + 1
                for l in range(1,lm):
                    u = H-(k*m+l*n)
                    v = V-(l*m+k*n)
                    if u>0 and v>0:
                        count += u*v
print(count)