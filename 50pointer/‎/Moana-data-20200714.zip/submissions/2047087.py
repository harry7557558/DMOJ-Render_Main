P = [i>1 for i in range(int(raw_input())+2)]
for i in range(2,len(P)-2):
    if P[i] and len([P.__setitem__(j,0) for j in range(i+i,len(P),i)])+1: print str(i)+'*' if P[i-2]|P[i+2] else i