N = int(input())
while N>0:
    s = input().split()
    for i in range(len(s)):
        if len(s[i])==4:
            print("****",end='')
        else:
            print(s[i],end='')
        if i==len(s)-1: print()
        else: print(end=' ')
    N = N - 1