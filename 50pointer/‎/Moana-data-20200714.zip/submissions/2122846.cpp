#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

unsigned bin2gray(unsigned x) {
	return x ^ (x >> 1);
}
int main() {
	unsigned N, M; cin >> N >> M;
	for (unsigned i = 0; i < N; i++) {
		unsigned q = 1024 * i;
		for (unsigned j = 0; j < M; j++) {
			cout << (q | bin2gray(j)) << (j == M - 1 ? '\n' : ' ');
		}
	}
	return 0;
}