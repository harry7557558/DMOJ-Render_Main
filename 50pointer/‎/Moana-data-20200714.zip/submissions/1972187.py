import math
T = int(input())
while T > 0:
    x, y, z, rx, ry, rz, theta = [float(t) for t in input().split()]
    m = math.sqrt(rx*rx+ry*ry+rz*rz)
    rx/=m
    ry/=m
    rz/=m
    ct = math.cos(theta)
    st = math.sin(theta)
    print((ct+rx*rx*(1-ct))*x+(rx*ry*(1-ct)-rz*st)*y+(rx*rz*(1-ct)+ry*st)*z,end=' ')
    print((ry*rx*(1-ct)+rz*st)*x+(ct+ry*ry*(1-ct))*y+(ry*rz*(1-ct)-rx*st)*z,end=' ')
    print((rz*rx*(1-ct)-ry*st)*x+(rz*ry*(1-ct)+rx*st)*y+(ct+rz*rz*(1-ct))*z)
    T = T - 1