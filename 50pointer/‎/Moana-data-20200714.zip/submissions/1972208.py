import math
def isprime(N):
    if N<2: return False
    if N==2 or N==3: return True
    if N%2==0 or N%3==0: return False
    k = int(math.sqrt(N))
    for i in range(4,k,6):
        if N%(i+1)==0 or N%(i+3)==0: return False
    return True

a = int(input())
b = int(input())
c = 0
for i in range(a,b):
    if isprime(i): c += 1
print(c)