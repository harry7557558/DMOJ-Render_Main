#pragma GCC optimize "Os"
#include <bits/stdc++.h>
using namespace std;

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	FILE* fp = tmpfile();
	cout << fp << endl;
	cout << fprintf(fp, "Test if I can open file in this problem.\n");
	return 0;
}