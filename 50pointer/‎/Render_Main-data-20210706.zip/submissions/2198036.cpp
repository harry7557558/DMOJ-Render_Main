#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long lint;

int digitsum(lint x) {
	int s = 0;
	while (x) s += x % 10, x /= 10;
	return s;
}

int maxDigitSum_BF(lint N, lint M) {
	int ms = 0;
	for (lint i = N; i <= M; i++) {
		ms = max(digitsum(i), ms);
	}
	return ms;
}


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	int Q; cin >> Q;
	while (Q--) {
		lint N, M; cin >> N >> M;
		cout << maxDigitSum_BF(N, M) << endl;
	}
}