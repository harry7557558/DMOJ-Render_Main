#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;


#define inf 0x7FFFFFFF
int M[8][8];

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) M[i][j] = inf;
	int x, y; cin >> x >> y; M[x - 1][y - 1] = 0;
	cin >> x >> y; x--, y--;

#define setval(i,j,val) if (min(i,j)>=0&&max(i,j)<8) M[i][j]=min(M[i][j],val)
	for (int d = 0;; d++) {
		if (M[x][y] != inf) {
			cout << d << endl;
			return 0;
		}
		for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) if (M[i][j] == d) {
			setval(i + 2, j + 1, d + 1);
			setval(i + 2, j - 1, d + 1);
			setval(i + 1, j + 2, d + 1);
			setval(i + 1, j - 2, d + 1);
			setval(i - 1, j + 2, d + 1);
			setval(i - 1, j - 2, d + 1);
			setval(i - 2, j + 1, d + 1);
			setval(i - 2, j - 1, d + 1);
		}
	}
	return 0;
}