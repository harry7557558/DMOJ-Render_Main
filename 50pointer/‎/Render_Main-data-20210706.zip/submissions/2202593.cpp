#include <bits/stdc++.h>
using namespace std;

int main() {
	int x0 = 1, x1 = 2000000000, x;
	string s;
	do {
		x = (x0 + x1) / 2;
		cout << x << endl; fflush(stdout);
		cin >> s;
		if (s[0] == 'F') {
			x1 = x;
		}
		else if (s[0] == 'S') {
			x0 = x;
		}
		else break;
		if (x0 + 1 == x1) {
			cout << x1 << endl; fflush(stdout);
			break;
		}
	} while (s != "OK");
}