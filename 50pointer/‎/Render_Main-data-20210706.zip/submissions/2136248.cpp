#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

template<typename T> T gcd(T a, T b) {
	while (b) {
		T t = b;
		b = a % b;
		a = t;
	}
	return a;
}


int bruteforce(int a, int b, int d) {
	int count = 0;
	for (int x = 1; x <= a; x++)
		for (int y = 1; y <= b; y++)
			count += gcd(x, y) == d;
	return count;
}
int bruteforce_improved(int a, int b, int d) {
	int count = 0;
	for (int x = d; x <= a; x += d)
		for (int y = d; y <= b; y += d)
			count += gcd(x, y) == d;
	return count;
}


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	int n; cin >> n;
	while (n--) {
		int a, b, d; cin >> a >> b >> d;
		int c = bruteforce_improved(a, b, d);
		cout << c << endl;
	}
	return 0;
}