#include <bits/stdc++.h>
using namespace std;

#define printspc for (int i=0;i<spc;i++) putchar(' ');

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	for (int Q = 0; Q < 5; Q++) {
		int N; cin >> N;
		int spc = max((N * N + N) / 2 - 5, 0);
		printspc; printf("          |\n");
		printspc; printf("       \\  |  /\n");
		printspc; printf("        \\ | /\n");
		printspc; printf("         \\|/\n");
		printspc; printf("       XXXXXXX\n");
		printspc; printf("      X       X\n");
		printspc; printf("     X  O   O  X\n");
		printspc; printf("    X     V     X\n");
		printspc; printf("W   X  X     X  X\n");
		printspc; printf(" \\   X  XXXXX  X\n");
		printspc; printf("  \\   X       X\n");
		printspc; printf("   \\   XXXXXXX\n");
		printspc; printf("    \\ X       X---\n");
		printspc; printf("     X    O    X  \\\n");
		printspc; printf("    X           X  \\\n");
		printspc; printf("     XXXXXXXXXXX    \\\n");
		int spb = spc + 2;
		for (int T = 2; T <= N; T++) {
			int csp = T * T - T + 7;
			int s0 = T + 1;
			for (int u = -2; u < T; u++) {
				for (int i = 0; i < spb; i++) putchar(' ');
				for (int i = 0; i < s0; i++) putchar(' ');
				putchar('X');
				if (u == -2 || u == T - 1) {
					for (int i = 0; i < csp; i++) putchar(' ');
				}
				else {
					for (int i = 0; i < csp / 2; i++) putchar(' ');
					putchar('O');
					for (int i = 0; i < csp / 2; i++) putchar(' ');
				}
				putchar('X');
				if (T == 2 && u == -2) printf("     M");
				putchar('\n');
				csp += 2;
				s0--;
			}
			for (int i = -1; i < spb; i++) putchar(' ');
			for (int i = 2; i < csp; i++) putchar('X');
			putchar('\n');
			spb -= T + 1;
		}
		printspc; printf("      OOOO OOOO"); if (N == 1) printf("      M"); putchar('\n');
		printspc; printf("      OOOO OOOO\n");
		if (Q != 4) putchar('\n');
	}
}