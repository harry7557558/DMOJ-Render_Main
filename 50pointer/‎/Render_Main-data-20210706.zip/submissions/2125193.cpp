#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	int N; scanu(N);
	while (N--) {
		unsigned long long x;
		scanu(x);
		putchar((x&(x - 1)) ? 'F' : 'T');
		putchar('\n');
	}
}