#include <bits/stdc++.h>
using namespace std;

typedef long double ldouble;

ldouble c[1024];
int N;

ldouble eval(ldouble x) {
	ldouble r = 0;
	for (int i = 0; i <= N; i++) {
		r = r * x + c[i];
	}
	return r;
}
ldouble evald(ldouble x) {
	ldouble r = 0;
	for (int i = 0; i < N; i++) {
		r = r * x + (N - i) * c[i];
	}
	return r;
}

ldouble findroot(ldouble x) {
	for (int i = 0; i < 1024; i++) {
		ldouble y = eval(x), dy = evald(x);
		//if (y*y < 1e-20) return x;
		ldouble dx = y / dy;
		x -= dx;
		if (dx*dx < 1e-20) return x;
		if (isnan(0.0*x)) return NAN;
	}
	return NAN;
}

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> N;
	for (int i = 0; i <= N; i++) {
		scanf("%lf", &c[i]);
	}
	for (int i = 1; i <= N; i++) c[i] /= c[0];
	c[0] = 1;
	ldouble x;
	do {
		x = findroot(rand() / (double)RAND_MAX - 0.5);
		//cout << x << endl;
	} while (isnan(x));
	cout << fixed << setprecision(6) << x << endl;
	return 0;
}