#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)


//====================== Primes ==============================

int Primes[100000], PrimeN = 0;

void initPrimes(int N = 1000000) {
	Primes[0] = 1; PrimeN++;  // ...
	bool *p = new bool[N];
	for (int i = 0; i < N; i++) p[i] = true;
	int k = sqrt(N) + 1;
	for (int i = 2; i < N; i++) {
		if (p[i]) {
			if (i < k) for (int j = i * i; j < N; j += i) p[j] = false;
			Primes[PrimeN++] = i;
		}
	}
	delete p;
}

//====================== Factors ==============================

int *Factors[1000001]; int NFactor[1000001];
void initFactor(int N) {
	if (Factors[N]) return;
	int F[200], Fn = 0;
	for (int i = 1; i*i <= N; i++) if (N%i == 0) {
		F[Fn++] = i;
	}
	Factors[N] = new int[Fn];
	for (int i = 0; i < Fn; i++) Factors[N][i] = F[i];
	NFactor[N] = Fn;
}


//====================== Global Vars ==============================

#define INF 0x7FFFFFFF

int G[1000][1000];
int S[1000][1000];
int M, N;

int aR[1000000], aC[1000000], aN = 0;
int a0R[1000000], a0C[1000000], a0N = 0;


//====================== Main ==============================

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	scanu(M); scanu(N);
	for (int i = 0; i < M; i++) for (int j = 0; j < N; j++) {
		int t; scanu(t);
		G[i][j] = t;
		S[i][j] = INF;
	}
	S[0][0] = 0;
	a0R[0] = a0C[0] = 0, a0N = 1;
	//initPrimes();

	bool opr; int d = 1;
	do {
		opr = false;
		aN = 0;
		for (int u = 0; u < a0N; u++) {
			int i = a0R[u], j = a0C[u];
			int P = G[i][j];
			initFactor(P);
			int *F = Factors[P], Fn = NFactor[P];
			for (int t = 0; t < Fn; t++) {
				int p = F[t];
				if (P % p == 0) {
					int r = p - 1, c = P / p - 1;
					if (r < M && c < N) if (S[r][c] > d) {
						S[r][c] = d, opr = true;
						aR[aN] = r, aC[aN] = c, aN++;
					}
					if (r < N && c < M) if (S[c][r] > d) {
						S[c][r] = d, opr = true;
						aR[aN] = c, aC[aN] = r, aN++;
					}
				}
			}
		}
		d++;
		if (S[M - 1][N - 1] != INF) {
			printf("yes\n");
			return 0;
		}
		a0N = aN;
		for (int u = 0; u < aN; u++) a0C[u] = aC[u], a0R[u] = aR[u];
	} while (opr);
	printf("no\n");
	return 0;
}