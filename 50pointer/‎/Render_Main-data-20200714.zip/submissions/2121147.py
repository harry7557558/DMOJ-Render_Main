s = raw_input()
iv = True
for i in s:
    if i=='n' or i=='F':
        iv ^= True
print(iv)