#include <bits/stdc++.h>
using namespace std;
int main() { printf("AK"); return 0; }