// my alt already solved this problem in linear time and memory
// just want to practice elimination

#include <bits/stdc++.h>
using namespace std;


int main() {
#ifdef _DEBUG
	freopen("stdin.dat", "r", stdin);
#endif

	int N; cin >> N;

	// setup matrix
	int **M = new int*[N];
	for (int i = 0; i < N; i++) {
		M[i] = new int[N];
		for (int j = 0; j < N; j++) M[i][j] = 0;
		M[i][i] = M[i][(i + 1) % N] = M[i][(i + N - 1) % N] = 1;
	}
	int *B = new int[N];
	for (int i = 0; i < N; i++) cin >> B[i];
#ifdef __DEBUG
#define printMatrix \
	for (int i = 0; i < N; i++) { \
		for (int j = 0; j < N; j++) cout << setw(2) << M[i][j] << " "; \
		cout << setw(3) << B[i] << endl; \
	} cout << endl
#else
#define printMatrix
#endif
	printMatrix;

	// elimination
	for (int i = 0, d = 0; d < N; i++, d++) {
		if (M[i][d] == 0) {
			for (int j = i + 1; j < N; j++) {
				if (M[j][d] != 0) {
					for (int k = d; k < N; k++) swap(M[i][k], M[j][k]);
					swap(B[i], B[j]);
					break;
				}
			}
			if (M[i][d] == 0) {
				d++, i--; continue;
			}
			printMatrix;
		}
		for (int j = 0; j < N; j++) if (j != i) {
			int u = M[i][d], v = M[j][d];
			for (int k = 0; k < N; k++) M[j][k] = M[j][k] * u - M[i][k] * v;
			B[j] = B[j] * u - B[i] * v;
		}
		printMatrix;
	}

	if (N % 3) { // R(M)=N
		for (int i = 0; i < N; i++) cout << (B[i] / M[i][i]) << endl;
		return 0;
	}
	else if (N == 3) { // R(M)=1
		cout << B[0] << "\n0\n0\n";
		return 0;
	}
	else { // R(M)=N-2
		int m1 = 0, m2 = 0;
		for (int i = 1; i < N; i += 3) m1 = min(m1, B[i]);
		for (int i = 2; i < N; i += 3) m2 = min(m2, B[i]);
		for (int i = 0; i < N - 2; i++) {
			B[i] += m1 * M[i][N - 2] + m2 * M[i][N - 1];
			cout << B[i] << endl;
		}
		cout << -m1 << endl << -m2 << endl;
		return 0;
	}

	return 0;
}