#include <bits/stdc++.h>
using namespace std;

int S[100000];

int main() {
	int I; cin >> I;
	int N; cin >> N;
	int J; cin >> J;
	while (J--) {
		int xi, xf, k; cin >> xi >> xf >> k;
		for (int x = xi; x <= xf; x++) S[x] += k;
	}
	int count = 0;
	for (int i = 0; i < I; i++) count += S[i] < N;
	cout << count << endl;
	return 0;
}