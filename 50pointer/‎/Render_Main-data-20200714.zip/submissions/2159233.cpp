#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

struct sofake {
	int a[6];
};

bool alike(sofake a, sofake b) {
	for (int i = 0; i < 6; i++) {
		bool ok = true;
		for (int j = 0; j < 6; j++) {
			if (a.a[(i + j) % 6] != b.a[j]) {
				ok = false;
				break;
			}
		}
		if (ok) return true;
		ok = true;
		for (int j = 0; j < 6; j++) {
			if (a.a[(i + j) % 6] != b.a[5 - j]) {
				ok = false;
				break;
			}
		}
		if (ok) return true;
	}
	return false;
}


int N;
sofake S[100000];

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> N;
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < 6; j++) cin >> S[i].a[j];
	}
	for (int i = 0; i < N; i++) for (int j = 0; j < i; j++) {
		if (alike(S[i], S[j])) {
			printf("Twin snowflakes found.\n");
			return 0;
		}
	}
	printf("No two snowflakes are alike.\n");
	return 0;
}