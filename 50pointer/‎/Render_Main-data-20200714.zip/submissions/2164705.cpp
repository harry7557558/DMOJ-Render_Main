#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;


double c[1024];
int N;

double eval(double x) {
	double r = 0;
	for (int i = 0; i <= N; i++) {
		r = r * x + c[i];
	}
	return r;
}
double evald(double x) {
	double r = 0;
	for (int i = 0; i < N; i++) {
		r = r * x + (N - i) * c[i];
	}
	return r;
}

double findroot(double x) {
	for (int i = 0; i < 64; i++) {
		double y = eval(x), dy = evald(x);
		double dx = y / dy;
		x -= dx;
		if (dx*dx < 1e-16) return x;
		if (isnan(0.0*x)) return NAN;
	}
	return NAN;
}

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> N;
	if (N == 2) {
		cout << N << endl;
		for (int i = 0; i <= N; i++) {
			string s; cin >> s;
			if (i == 2) cout << s << " ";
		}
		return 0;
	}
	for (int i = 0; i <= N; i++) {
		cin >> c[i];
	}
	double x;
	do {
		x = findroot(rand() / RAND_MAX - 0.5);
	} while (isnan(x));
	printf("%.6lf\n", x);
	return 0;
}