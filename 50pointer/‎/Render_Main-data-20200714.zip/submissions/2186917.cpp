#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

#pragma region fast_io
#ifndef __DEBUG
#define getchar getchar_unlocked
#endif
char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#pragma endregion


int N;
vector<int> Mi[20000];

struct ms {
	vector<int>* p;
	int m;
};

#include <chrono>

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	scanu(N);
	if (N > 20000) {
		printf("OK %d %d\n", __LINE__, N);
		fflush(stdout);
	}
	int mm = 0;
	for (int i = 0; i < N; i++) {
		int m; scanu(m);
		Mi[m].push_back(i);
		if (m > mm) mm = m;
	}
	mm++;
	vector<ms> Ms;
	for (int i = 0; i < mm; i++) {
		if (!Mi[i].empty()) {
			ms t; t.p = &Mi[i], t.m = i;
			Ms.push_back(t);
		}
	}
	if (N > 20000) {
		printf("OK %d %d\n", __LINE__, Ms.size());
		printf("%lfs\n", chrono::duration<double>(chrono::high_resolution_clock::now() - t0).count());
		fflush(stdout);
	}
	
	int Q; scanu(Q);
	while (Q--) {
		int a, b, m; scanu(a); scanu(b); scanu(m);
		int count = 0;
		int m0 = lower_bound(Ms.begin(), Ms.end(), m, [](ms a, int m) {return a.m < m; }) - Ms.begin(), m1 = Ms.size();
		for (int i = m0; i < m1; i++) {
			auto p = Ms[i].p;
			auto d1 = lower_bound(p->begin(), p->end(), a);
			auto d2 = upper_bound(d1, p->end(), b);
			count += Ms[i].m * (d2 - d1);
		}
		printf("%d\n", count);
	}
	return 0;
}