P = [i>1 for i in range(int(raw_input())+2)]
for i in range(2,len(P)-2):
    for j in range(i+i,len(P),i): P[j]&=not P[i]
    if P[i]:print (lambda: str(i)+'*' if P[i-2] or P[i+2] else i)()