#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

#if _DEBUG
std::ifstream fin("stdin.dat");
#define cin fin
#endif


class vec2 {
public:
	double x, y;
	vec2() {}
	vec2(double a) :x(a), y(a) {}
	vec2(double x, double y) :x(x), y(y) {}
	vec2 operator - () const { return vec2(-x, -y); }
	vec2 operator + (vec2 v) const { return vec2(x + v.x, y + v.y); }
	vec2 operator - (vec2 v) const { return vec2(x - v.x, y - v.y); }
	vec2 operator * (vec2 v) const { return vec2(x * v.x, y * v.y); } 	// non-standard
	vec2 operator * (double a) const { return vec2(x*a, y*a); }
	double sqr() const { return x * x + y * y; } 	// non-standard
	friend double length(vec2 v) { return sqrt(v.x*v.x + v.y*v.y); }
	friend vec2 normalize(vec2 v) { return v * (1. / sqrt(v.x*v.x + v.y*v.y)); }
	friend double dot(vec2 u, vec2 v) { return u.x*v.x + u.y*v.y; }
	friend double det(vec2 u, vec2 v) { return u.x*v.y - u.y*v.x; } 	// non-standard
	vec2 rot() const { return vec2(-y, x); }  // rotate 90deg counterclockwise
};

void printVec2(vec2 p, const char* end = "") { printf("(%lg,%lg)%s", p.x, p.y, end); }
void printBox(vec2 Min, vec2 Max, const char* end = "=0\n") { printf("max(abs(x%+lg)%+lg,abs(y%+lg)%+lg)%s", -0.5*(Max.x + Min.x), -0.5*(Max.x - Min.x), -0.5*(Max.y + Min.y), -0.5*(Max.y - Min.y), end); }


int N;
vec2 P[1000], B[1000];
bool Des[1000];

double sdf(vec2 p, int &id) {
	id = -1;
	double d, md = 1e+12;
	for (int i = 0; i < N; i++) if (!Des[i]) {
		d = max(abs(p.x - P[i].x) - B[i].x, abs(p.y - P[i].y) - B[i].y);
		if (d < md) md = d, id = i;
	}
	return md;
}
vec2 grad(vec2 p, int id) {  // .....
	vec2 r = B[id]; p = p - P[id];
	return vec2(abs(abs(p.x) - r.x) < 1e-6, abs(abs(p.y) - r.y) < 1e-6);
}

int main() {
	cin >> N;
	vec2 d; cin >> d.x >> d.y;
	d = normalize(d);
	for (int i = 0; i < N; i++) {
		vec2 p, w; cin >> p.x >> p.y >> w.x >> w.y;
		//printBox(p, p + w);
		P[i] = p + w * 0.5, B[i] = w * 0.5;
	}
	vec2 p(0.0);
	while (1) {
		double t = 0, dt;
		int id;
		for (int i = 0; i < 0x400; i++) {
			dt = sdf(p + d * t, id);
			t += dt;
			if (dt > 1e+6) return 0;
			if (dt < 1e-12) break;
		}
		cout << (id + 1) << endl;
		Des[id] = true;
		p = p + d * t;
		vec2 n = grad(p, id);
		d = d * (vec2(1.0) - n * 2.0);
		//printVec2(p); printVec2(d);
	}
	return 0;
}