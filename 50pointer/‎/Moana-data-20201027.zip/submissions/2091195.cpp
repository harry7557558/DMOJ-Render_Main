#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

typedef long long lint;
lint pow(lint x, lint e, lint m) {
	lint r = 1;
	x %= m;
	while (e) {
		if (e & 1) r = (r*x) % m;
		e >>= 1;
		x = (x*x) % m;
	}
	return r;
}
#define Mod 1000000007
#define ModInv(x) pow(x,Mod-2,Mod)

#define MN 2100
lint X[MN], Y[MN];
lint W[MN + 1];
lint C[MN];

char _;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)

int main() {
	int N; scanu(N);
	N++; for (int i = 0; i < N; i++) {
		X[i] = i;
		printf("? %lld\n", X[i]);
		scanu(Y[i]);
	}
	W[0] = 1;
	for (int d = 0; d < N; d++) {
		for (int k = d + 1; k > 0; k--) {
			W[k] = (W[k - 1] - X[d] * W[k]) % Mod;
		}
		W[0] = -(W[0] * X[d]) % Mod;
	}
	for (int i = 0; i < N; i++) {
		lint m = 1;
		for (int k = 0; k < N; k++) if (k != i) {
			m = m * (X[k] - X[i]) % Mod;
		}
		m = Y[i] * ModInv(m) % Mod;
		lint c = 1;
		for (int k = N; k > 0; k--) {
			C[k - 1] = (C[k - 1] + m * c) % Mod;
			c = W[k - 1] + c * X[i] % Mod;
		}
	}
	if (!(N & 1)) for (int i = 0; i < N; i++) C[i] = -C[i];
	for (int i = 0; i < N; i++) C[i] = (C[i] + Mod) % Mod;
	printf("! ");
	for (int i = N - 1; i >= 0; i--) printf("%lld%c", C[i], i ? ' ' : '\n');
	return 0;
}