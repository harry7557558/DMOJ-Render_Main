var request = new XMLHttpRequest();
request.open("GET", "https://dmoj.ca/~quantum/csprng.txt", false);
request.send();
print(request.responseText);