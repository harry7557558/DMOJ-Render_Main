N = int(raw_input())
M = [[int(t) for t in raw_input().split()] for i in range(N)]
_ = 1000000007
d = 1
for i in range(N):
    if M[i][i]==0:
        for j in range(i+1,N):
            if M[j][i]!=0:
                for k in range(i,N):
                    t = M[i][k]
                    M[i][k]=M[j][k]
                    M[j][k]=t
                d=-d
                break
    v = -pow(M[i][i],_-2,_)
    for j in range(i+1,N):
        if M[j][i]!=0:
            m=(M[j][i]*v)%_
            for k in range(i,N):
                M[j][k]=(M[i][k]*m+M[j][k])%_
    d=(M[i][i]*d)%_
print((d+_)%_)