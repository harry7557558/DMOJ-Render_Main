#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)
int _t;
#define Scanf(x) {scan(_t);x=_t;}

class vec2 {
public:
	double x, y;
	vec2() {}
	vec2(double a) :x(a), y(a) {}
	vec2(double x, double y) :x(x), y(y) {}
	vec2 operator - () const { return vec2(-x, -y); }
	vec2 operator + (vec2 v) const { return vec2(x + v.x, y + v.y); }
	vec2 operator - (vec2 v) const { return vec2(x - v.x, y - v.y); }
	vec2 operator * (vec2 v) const { return vec2(x * v.x, y * v.y); } 	// non-standard
	vec2 operator * (double a) const { return vec2(x*a, y*a); }
	double sqr() const { return x * x + y * y; } 	// non-standard
	friend double length(vec2 v) { return sqrt(v.x*v.x + v.y*v.y); }
	friend vec2 normalize(vec2 v) { return v * (1. / sqrt(v.x*v.x + v.y*v.y)); }
	friend double dot(vec2 u, vec2 v) { return u.x*v.x + u.y*v.y; }
	friend double det(vec2 u, vec2 v) { return u.x*v.y - u.y*v.x; } 	// non-standard
	vec2 rot() const { return vec2(-y, x); }  // rotate 90deg counterclockwise
};


int N;
vec2 P[1000], B[1000];  // center, x and y radius
bool Des[1000];	// is destroyed?

// need to handle degenerated case: 0.*x!=0.
double intBox(vec2 C, vec2 R, vec2 ro, vec2 inv_rd) {  // inv_rd = vec3(1.0)/rd
	vec2 p = -inv_rd * (ro - C);
	vec2 k = vec2(abs(inv_rd.x), abs(inv_rd.y))*R;
	vec2 t1 = p - k, t2 = p + k;
	double tN = max(t1.x, t1.y);
	double tF = min(t2.x, t2.y);
	if (tN > tF + 1e-6 || tF < 0.0) return NAN;
	return tN;
	//return tN > 0. ? tN : tF;
}

vec2 grad(vec2 p, int id) {  // .....
	vec2 r = B[id]; p = p - P[id];
	return vec2(abs(abs(p.x) - r.x) < 1e-6, abs(abs(p.y) - r.y) < 1e-6);
}

int main() {
#ifdef _DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	scanu(N);
	vec2 d; Scanf(d.x); Scanf(d.y);
	d = normalize(d);
	for (int i = 0; i < N; i++) {
		vec2 p, w; Scanf(p.x); Scanf(p.y); Scanf(w.x); Scanf(w.y);
		P[i] = p + w * 0.5, B[i] = w * 0.5;
	}
	vec2 p(0.0), inv_d(1. / d.x, 1. / d.y);
	while (1) {
		double t, mt = INFINITY; int id = -1;
		for (int i = 0; i < N; i++) if (!Des[i]) {
			t = intBox(P[i], B[i], p, inv_d);
			if (t < mt) mt = t, id = i;
		}
		if (id == -1) break;
		printf("%d\n", id + 1);
		Des[id] = true;
		p = p + d * mt;
		vec2 n = grad(p, id);
		d = d * (vec2(1.0) - n * 2.0);
		inv_d = vec2(1. / d.x, 1. / d.y);
	}
	return 0;
}