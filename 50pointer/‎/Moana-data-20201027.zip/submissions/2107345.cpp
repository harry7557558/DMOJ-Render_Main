#pragma GCC optimize "Ofast"
#include <stdio.h>

char _, __;
#define gcu getchar_unlocked
#define scanu(x) do{while((x=gcu())<'0');for(x-='0';'0'<=(_=gcu());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=gcu())<45);if(__-45)x=__;else x=gcu();for(x-=48;47<(_=gcu());x=x*10+_-48);if(__<46)x=-x;}while(0)


typedef long long lint;

lint pow(lint x, lint e, lint m) {
	lint r = 1;
	while (e) {
		if (e & 1) r = (r*x) % m;
		e >>= 1;
		x = (x*x) % m;
	}
	return r;
}

#define Mod 1000000007
#define modInv(a) pow(a,Mod-2,Mod)

lint M[500][500];
int N;

int main() {
	scan(N);
	for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) scan(M[i][j]);
	lint det = 1;
	for (int i = 0; i < N; i++) {
		if (M[i][i] == 0) {
			for (int j = i + 1; j < N; j++) {
				if (M[j][i] != 0) {
					for (int k = i; k < N; k++) {
						lint t = M[i][k]; M[i][k] = M[j][k]; M[j][k] = t;
					}
					det = -det; break;
				}
			}
		}
		lint Inv = -modInv(M[i][i]);
		for (int j = i + 1; j < N; j++) if (M[j][i] != 0) {
			lint m = (M[j][i] * Inv) % Mod;
			for (int k = i; k < N; k++) M[j][k] = (M[i][k] * m + M[j][k]) % Mod;
		}
		det = (M[i][i] * det) % Mod;
	}
	det = (det + Mod) % Mod;
	printf("%lld\n", det);
	return 0;
}