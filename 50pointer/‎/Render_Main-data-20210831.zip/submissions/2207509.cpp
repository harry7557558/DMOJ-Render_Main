#pragma GCC optimize "Ofast"

void multiply_matrices(double a[1024][147], double b[147][64], double c[1024][64]) {
	for (int i = 0; i < 1024; i++) for (int j = 0; j < 64; j++) {
		for (int k = 0; k < 147; k++) c[i][j] += a[i][k] * b[k][j];
	}
}