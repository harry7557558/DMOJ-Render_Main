import sys
raw_input = sys.stdin.readline

def isPower2(x):
    count = 0
    while x:
        count += x&1
        if count>1: return False
        x>>=1
    return count==1

N = int(raw_input())
for i in range(N):
    x = int(raw_input())
    print 'T' if isPower2(x) else 'F'