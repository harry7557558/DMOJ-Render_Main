#pragma GCC optimize "Ofast"

void multiply_matrices(double a[64][576], double b[576][256], double c[64][256]) {
	for (int i = 0; i < 64; i++) for (int j = 0; j < 256; j++) {
		c[i][j] = 0;
		for (int k = 0; k < 576; k++) c[i][j] += a[i][k] * b[k][j];
	}
}