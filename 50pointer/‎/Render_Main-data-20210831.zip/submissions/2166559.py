N = int(input())
for i in range(N):
    s = input()
    for c in s:
        if c=='a' or c=='A': print('Hi!',end=' ')
        if c=='e' or c=='E': print('Bye!',end=' ')
        if c=='i' or c=='I': print('How are you?',end=' ')
        if c=='o' or c=='O': print('Follow me!', end=' ')
        if c=='u' or c=='U': print('Help!',end=' ')
        if c>='0'and c<='9': print('Yes!',end=' ')
    print(end='\n')