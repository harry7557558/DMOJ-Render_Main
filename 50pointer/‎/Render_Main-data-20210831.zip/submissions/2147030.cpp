#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

int N, M, K;
struct block {
	int r, c;
} B[500001];

bool isOpen(int x, int y) {
	if (x < 0 || x >= N || y < 0 || y >= M) return false;
	block *d = lower_bound(B, B + K, x, [](block a, int r) { return a.r < r; });
	if (d->r != x) return false;
	while (d->r == x) {
		if (d->c == y) return false;
		d++;
	}
	return true;
}

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	scanf("%d%d%d", &N, &M, &K);
	for (int i = 0; i < K; i++) {
		scanf("%d%d", &B[i].r, &B[i].c);
		B[i].r--, B[i].c--;
	}
	sort(B, B + K, [](block a, block b) {return a.r == b.r ? a.c < b.c : a.r < b.r; });
	B[K].r = B[K].c = 0x7FFFFFFF;
	int x = 0, y = 0, dx = 0, dy = 1;
	while (1) {
		if (isOpen(x - dy, y + dx)) {
			swap(dx, dy); dx *= -1;
		}
		for (int i = 0; ; i++) {
			if (isOpen(x + dx, y + dy)) break;
			else {
				swap(dx, dy); dy *= -1;
			}
			if (i > 4) {
				printf("NO\n");
				return 0;
			}
		}
		x += dx, y += dy;
		//printf("%d %d %d %d\n", x, y, dx, dy);
		if (x == N - 1 && y == M - 1) {
			printf("YES\n");
			return 0;
		}
		if (x == 0 && y == 0) {
			printf("NO\n");
			return 0;
		}
	}
	return 0;
}