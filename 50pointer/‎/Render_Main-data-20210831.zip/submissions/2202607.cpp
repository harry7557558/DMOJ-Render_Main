#include <bits/stdc++.h>
using namespace std;

int main() {
	unsigned x0 = 1, x1 = 2000000000, x;
	string s;
	do {
		x = (x0 + x1) / 2;
		cout << x << endl; fflush(stdout);
		cin >> s;
		if (s[0] == 'F') {
			x1 = x;
			if (x1 - x0 < 2) {
				cout << x0 << endl; fflush(stdout); break;
			}
		}
		else if (s[0] == 'S') {
			x0 = x;
			if (x1 - x0 < 2) {
				cout << x1 << endl; fflush(stdout); break;
			}
		}
		else break;
	} while (s != "OK");
}