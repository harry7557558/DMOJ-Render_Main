#include <bits/stdc++.h>
using namespace std;

string f() {
	return "AK";
}