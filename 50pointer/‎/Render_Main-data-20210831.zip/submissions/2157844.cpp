#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)

typedef long long int lint;

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	int N; scanu(N);
	lint M; scanu(M);
	lint mx = 0, my = 0;
	for (int i = 0; i < N; i++) {
		int t; scan(t); mx += t;
		scan(t); my += t;
	}
	mx = max(mx - N, N*M - mx);
	my = max(my - N, N*M - my);
	printf("%lld\n", mx + my);
	return 0;
}