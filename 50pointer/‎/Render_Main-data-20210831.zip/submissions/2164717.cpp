#include <bits/stdc++.h>
using namespace std;

int main() {
	int N; double c0, c1;
	scanf("%d%lf%lf", &N, &c0, &c1);
	printf("%lf\n", -c1 / c0 / N);
	return 0;
}