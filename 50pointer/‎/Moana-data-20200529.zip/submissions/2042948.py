import sys
N = int(raw_input())
M = [[int(t) for t in raw_input().split()] for i in range(N)]
sys.exit()
_ = 1000000007
d = 1
for i in range(N):
    P=M[i]
    if P[i]==0:
        for j in range(i+1,N):
            if M[j][i]!=0:
                for k in range(i,N):
                    t = P[k]
                    P[k]=M[j][k]
                    M[j][k]=t
                d=-d
                break
    v = -pow(P[i],_-2,_)
    for j in range(i+1,N):
        Q=M[j]
        m=(Q[i]*v)%_
        for k in range(i+1,N):
            Q[k]=(P[k]*m+Q[k])%_
    d=(P[i]*d)%_
print((d+_)%_)