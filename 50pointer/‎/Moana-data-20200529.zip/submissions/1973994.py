R, C = [int(t) for t in input().split()]
i0, j0 = [int(t) for t in input().split()]
i1, j1 = [int(t) for t in input().split()]
S = s = []
INF = float('inf')
for i in range(R):
    S.append([c for c in input()])
    for j in range(C):
        if S[i][j]=='O': S[i][j]=INF
T = [[False for i in range(C)] for j in range(R)]
Tn = int(input())
for t in range(Tn):
    i, j = input().split()
    T[int(i)][int(j)] = True

K = [[i0,j0]]
k = []

S[i0][j0] = 0
D0 = 0
D1 = INF
while S[i1][j1]==INF:
    for p in K:
        i = p[0]
        j = p[1]
        if S[i][j]==D0:
            d = D0 + 1
            if i>0 and S[i-1][j]!='X' and S[i-1][j]>d:
                S[i-1][j]=d
                k.append([i-1,j])
            if j>0 and S[i][j-1]!='X' and S[i][j-1]>d:
                S[i][j-1]=d
                k.append([i,j-1])
            if i+1<R and S[i+1][j]!='X' and S[i+1][j]>d:
                S[i+1][j]=d
                k.append([i+1,j])
            if j+1<C and S[i][j+1]!='X' and S[i][j+1]>d:
                S[i][j+1]=d
                k.append([i,j+1])
            if T[i][j] and D1 == INF:
                D1 = D0
    D0 = D0 + 1
    K = k
    k = []
D0 = S[i1][j1]
if D1==INF:
    D1 = D0

print(D0-D1)