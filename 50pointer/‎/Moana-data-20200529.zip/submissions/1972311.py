N = int(input())
t = 0
s = 0
while N > 0:
    c = input()
    for i in c:
        if i=='t' or i=='T':
            t += 1
        if i=='s' or i=='S':
            s += 1
    N = N - 1
if t > s:
    print("English")
else:
    print("French")