#include <stdio.h>
#include <thread>
int main(){
    printf("%d\n",std::thread::hardware_concurrency());
}