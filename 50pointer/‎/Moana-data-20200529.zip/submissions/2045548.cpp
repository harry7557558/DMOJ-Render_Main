#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

#if _DEBUG
std::ifstream fin("stdin.dat");
#define cin fin
#endif

string add(string a, string b) {
	while (a.length() < b.length()) a = "0" + a;
	while (b.length() < a.length()) b = "0" + b;
	if (a[0] + b[0] - '0' >= '9') a = "0" + a, b = "0" + b;
	for (int i = a.length() - 1; i >= 0; i--) {
		a[i] += b[i] - '0';
		if (a[i] > '9') a[i] -= 10, a[i - 1]++;
	}
	while (a[0] && a[0] == '0') a.erase(0, 1);
	if (a.empty()) return "0";
	return a;
}

string sub(string a, string b) {
	while (a[0] && a[0] == '0') a.erase(0, 1);
	while (b[0] && b[0] == '0') b.erase(0, 1);
	bool sgn = a.size() < b.size();
	if (a.size() == b.size()) {
		int i; for (i = 0; i < a.size(); i++) {
			if (a[i] > b[i]) break;
			else if (a[i] < b[i]) { sgn = true; break; }
		}
		if (i == a.size()) return "0";
	}
	if (sgn) swap(a, b);
	while (b.size() < a.size()) b = "0" + b;
	for (int i = a.length() - 1; i >= 0; i--) {
		a[i] -= b[i] - '0';
		if (a[i] < '0') a[i] += 10, a[i - 1]--;
	}
	while (a[0] && a[0] == '0') a.erase(0, 1);
	if (sgn) a = "-" + a;
	return a;
}

int main() {
	int N; cin >> N;
	string a, b;
	while (N--) {
		cin >> a >> b;
		if (a[0] == '-' && b[0] == '-') {
			a.erase(0, 1); b.erase(0, 1);
			cout << "-" << add(a, b) << endl;
		}
		else if (a[0] == '-' && b[0] != '-') {
			a.erase(0, 1);
			string s = sub(b, a);
			cout << s << endl;
		}
		else if (a[0] != '-' && b[0] == '-') {
			b.erase(0, 1);
			string s = sub(a, b);
			cout << s << endl;
		}
		else if (a[0] != '-' && b[0] != '-') {
			cout << add(a, b) << endl;
		}
	}
	return 0;
}