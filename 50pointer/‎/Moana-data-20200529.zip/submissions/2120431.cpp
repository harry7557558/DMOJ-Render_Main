#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

#pragma region fast_io
#ifndef __DEBUG
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#define fread fread_unlocked
#define fwrite fwrite_unlocked
#endif
#define INPUT_SIZE 1<<22
#define OUTPUT_SIZE 1<<22
int _i0 = 0, _o0 = 0;
char _, _n, __[20], _i[INPUT_SIZE], _o[OUTPUT_SIZE];
#define readin fread(_i, 1, INPUT_SIZE, stdin)
#define writeout fwrite(_o, 1, _o0, stdout)
#define scanu(x) do{while((_=_i[_i0++])<48);for(x=_-48;47<(_=_i[_i0++]);x=x*10+_-48);}while(0)
inline void putnumu(int x) { _ = 0; do __[_++] = x % 10; while (x /= 10); while (_--)_o[_o0++] = __[_] + '0'; }
#define putnl _o[_o0++]='\n'
#pragma endregion


int N;
int M[100000];

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	//freopen("stdout.dat", "w", stdout);
#endif
	readin;
	scanu(N);
	for (int i = 0; i < N; i++) { int t; scanu(t); M[i] = t; }
	int Q; scanu(Q);
	while (Q--) {
		int a, b, q; scanu(a); scanu(b); scanu(q); b++, q--;
		int count = 0;
		for (int i = a; i < b; i++) count += M[i] * (M[i] > q);
		putnumu(count); putnl;
	}
	writeout;
	return 0;
}