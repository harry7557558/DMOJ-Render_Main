def isFix(a,b):
    if len(a)>len(b):
        c=a
        a=b
        b=c
    return a==b[:len(a)] or a==b[len(b)-len(a):]

N = int(input())
while N > 0:
    a = input()
    b = input()
    c = input()
    if isFix(a,b) or isFix(a,c) or isFix(b,c):
        print("No")
    else:
        print("Yes")
    N -= 1