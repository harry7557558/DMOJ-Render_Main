import math
N = int(input())
while N > 0:
    n = int(input())
    if n >= 34:
        print(0)
    else:
        print(math.factorial(n)%(1<<32))
    N -= 1