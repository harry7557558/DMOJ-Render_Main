c, r = input().split()
c = int(c)
r = int(r)
x = 0
y = 0
while 1:
    dx, dy = input().split()
    dx = int(dx)
    dy = int(dy)
    if dx == 0 and dy == 0:
        break
    x += dx
    y += dy
    if x < 0: x = 0
    if y < 0: y = 0
    if x > c: x = c
    if y > r: y = r
    print(x, y)