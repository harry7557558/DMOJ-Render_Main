#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

int main() {
	unsigned C, D, E;
	cin >> C >> D >> E;
	const int T[8] = { 1, 0, 0, 0, 0, 2, 1, 0 };
	int r = 1;
	for (int i = 0; i < 30; i++) {
		int k = ((C & 1) << 2) | ((D & 1) << 1) | (E & 1);
		r *= T[k];
		C >>= 1, D >>= 1, E >>= 1;
	}
	cout << r << endl;
	return 0;
}