x = int(input())
m = int(input())
r = -1
for i in range(m):
    if i*x%m==1:
        print(i)
        r = i
        break
if r==-1:
    print("No such integer exists.")