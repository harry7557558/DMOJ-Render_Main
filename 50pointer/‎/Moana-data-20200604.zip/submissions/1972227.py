import math
def isprime(N):
    if N%2==0 or N%3==0: return False
    k = int(math.sqrt(N))
    for i in range(4,k,6):
        if N%(i+1)==0 or N%(i+3)==0: return False
    return True

N = int(input())
print("2")
print("3*")
for i in range(5,N):
    if isprime(i):
        print(i,end='')
        if isprime(i-2) or isprime(i+2):
            print('*',end='')
        print()