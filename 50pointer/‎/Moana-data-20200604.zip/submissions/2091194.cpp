#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

typedef long long lint;
lint pow(lint x, lint e, lint m) {
	lint r = 1;
	x %= m;
	while (e) {
		if (e & 1) r = (r*x) % m;
		e >>= 1;
		x = (x*x) % m;
	}
	return r;
}
#define Mod 1000000007
#define _Mod % Mod
#define ModInv(x) pow(x,Mod-2,Mod)

//#define lint double
//#define _Mod
//#define ModInv(x) (1./(x))

// mostly use for debug
lint eval(lint* C, int N, lint x) {
	lint r = 0;
	for (int i = N; i >= 0; i--) {
		r = (r*x + C[i]) _Mod;
	}
	return r;
}

#define MN 2100
lint X[MN], Y[MN];
lint W[MN + 1];  // coes of Π(x-xi)
lint C[MN];  // result

int main() {
#if _DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	int N; cin >> N;
	N++; for (int i = 0; i < N; i++) {
		X[i] = i;
		cout << "? " << X[i] << endl;
		cin >> Y[i];
	}
	//for (int i = 0; i < N; i++) cin >> X[i];
	//for (int i = 0; i < N; i++) cin >> Y[i];
	W[0] = 1;
	for (int d = 0; d < N; d++) {
		for (int k = d + 1; k > 0; k--) {
			W[k] = (W[k - 1] - X[d] * W[k]) _Mod;
		}
		W[0] = -(W[0] * X[d]) _Mod;
	}
#if _DEBUG
	for (int i = 0; i < N; i++) {
		if (eval(W, N, X[i]) != 0) {
			throw __LINE__;
		}
	}
#endif
	for (int i = 0; i < N; i++) {
		lint m = 1;
		for (int k = 0; k < N; k++) if (k != i) {
			m = m * (X[k] - X[i]) _Mod;
		}
		m = Y[i] * ModInv(m) _Mod;
		lint c = 1;
		for (int k = N; k > 0; k--) {
			C[k - 1] = (C[k - 1] + m * c) _Mod;
			c = W[k - 1] + c * X[i] _Mod;
		}
	}
	if (!(N & 1)) for (int i = 0; i < N; i++) C[i] = -C[i];
	for (int i = 0; i < N; i++) C[i] = (C[i] + Mod) % Mod;
#if _DEBUG
	for (int i = 0; i < N; i++) {
		if ((eval(C, N - 1, X[i]) - Y[i]) _Mod != 0) {
			throw __LINE__;
		}
	}
#endif
	cout << "! ";
	for (int i = N - 1; i >= 0; i--) cout << C[i] << (i ? ' ' : '\n');
	return 0;
}