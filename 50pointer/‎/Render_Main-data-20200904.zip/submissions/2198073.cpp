#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long lint;

int digitsum(lint x) {
	int s = 0;
	while (x) s += x % 10, x /= 10;
	return s;
}

int maxDigitSum_BF(lint N, lint M) {
	int ms = 0;
	for (lint i = N; i <= M; i++) {
		ms = max(digitsum(i), ms);
	}
	return ms;
}

int digitcount(lint N) {
	int n = 0;
	while (N) n++, N /= 10;
	return n;
}
lint exp10i(int n) {
	lint r = 1;
	while (n--) r *= 10;
	return r;
}
int maxDigitSum(lint N, lint M, int dc = 0) {
	if (dc == 1) return M;
	if (dc == 0) {
		int n = digitcount(N), m = digitcount(M);
		if (n != m) {
			int ms = 9 * (m - 1);
			ms = max(ms, maxDigitSum(N, exp10i(n) - 1, n));
			ms = max(ms, maxDigitSum(exp10i(m - 1), M, m));
			return ms;
		}
		dc = n;
	}
	lint md = exp10i(dc - 1); int qr = M / md;
	if (qr == N / md) return qr + maxDigitSum(N - qr * md, M - qr * md, dc - 1);
	int ms = 9 * (dc - 1) + qr - 1;
	return max(ms, qr + maxDigitSum(md / 10, M - md * qr, dc - 1));
}


int main() {
#if 0
	for (int i = 0; i < 1000; i++) {
		lint N = rand(), M = rand();
		if (N > M) swap(N, M);
		int a = maxDigitSum_BF(N, M), b = maxDigitSum(N, M);
		if (a != b) {
			cout << N << " " << M << endl;
		}
	}
	return 0;
#endif
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	int Q; cin >> Q;
	while (Q--) {
		lint N, M; cin >> N >> M;
		cout << maxDigitSum(N, M) << endl;
	}
}