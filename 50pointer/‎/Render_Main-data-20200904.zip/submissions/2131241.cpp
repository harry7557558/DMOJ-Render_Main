#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
#include <chrono>
using namespace std;

typedef long long lint;
typedef unsigned char byte;
#define inf 0x7FFFFFFF
#define INF 0x7FFFFFFFFFFFFFFF

#define INPUT_SIZE 1<<24
int _i0 = 0;
char _, _n, __[20], _i[INPUT_SIZE];
#define readin _i[fread(_i, 1, INPUT_SIZE, stdin)]=0
#define scanu(x) do{while((_=_i[_i0++])<48);for(x=_-48;47<(_=_i[_i0++]);x=x*10+_-48);}while(0)
#define scan(x) do{while((_n=_i[_i0++])<45);if(_n-45)x=_n;else x=_i[_i0++];for(x-=48;47<(_=_i[_i0++]);x=x*10+_-48);if(_n<46)x=-x;}while(0)




#ifdef __DEBUG
#define Rand() (rand()*RAND_MAX+rand())
void randCase(int N) {
	freopen("stdout.dat", "w", stdout);
	printf("%d\n", N);
	for (int i = 0; i < N; i++) {
		//printf("%d %d %d\n", Rand() % 1000000, Rand() % 1000000, Rand() % 1000000);
		printf("%d %d %d\n", Rand() % 10, Rand() % 10, Rand() % 10);
	}
	exit(0);
}
#endif



#define MAXN 10001
int N;
struct Triangle {
	int x, y, d;
} T[MAXN];

struct Add {
	int x; int val;
};
Add S[2 * MAXN]; int Sn = 0;

bool Ys[1048576];




struct Node {
	int b0, b1;
	Triangle T;
	Node *c1 = 0, *c2 = 0;
} R, Rx;

void createTree(Node* R, Triangle* T, int N) {
	if (N == 1) {
		R->b0 = T->y, R->b1 = T->y + T->d;
		R->T = T[0];
		R->c1 = R->c2 = 0;
	}
	else {
		R->c1 = new Node; createTree(R->c1, T, N / 2);
		R->c2 = new Node; createTree(R->c2, T + N / 2, N - N / 2);
		R->b0 = min(R->c1->b0, R->c2->b0);
		R->b1 = max(R->c1->b1, R->c2->b1);
	}
}

void searchTree(Node* R, int y) {
	if (!(R->c1 || R->c2)) {
		Triangle T = R->T;
		if (T.d && y >= T.y && y < T.y + T.d) {
			Add t; t.x = T.x, t.val = 1;
			S[Sn++] = t;
			t.x = T.x + T.d - (y - T.y), t.val = -1;
			S[Sn++] = t;
		}
	}
	else {
		if (y >= R->c1->b0 && y < R->c1->b1) searchTree(R->c1, y);
		if (y >= R->c2->b0 && y < R->c2->b1) searchTree(R->c2, y);
	}
}

void createTreeX(Node* R, Triangle* T, int N) {
	if (N == 1) {
		R->b0 = T->x, R->b1 = T->x + T->d;
		R->T = T[0];
		R->c1 = R->c2 = 0;
	}
	else {
		R->c1 = new Node; createTreeX(R->c1, T, N / 2);
		R->c2 = new Node; createTreeX(R->c2, T + N / 2, N - N / 2);
		R->b0 = min(R->c1->b0, R->c2->b0);
		R->b1 = max(R->c1->b1, R->c2->b1);
	}
}

void searchTreeX(Node* R, const Triangle &T) {
	if (!(R->c1 || R->c2)) {
		if (T.x == R->T.x && T.y == R->T.y && T.d == R->T.d) return;
		int y = R->T.d + R->T.x + R->T.y - T.x;
		if (y > T.y && y < T.y + T.d) Ys[y] = true;
	}
	else {
		if (T.x > R->c1->b0 && T.x < R->c1->b1) searchTreeX(R->c1, T);
		if (T.x > R->c2->b0 && T.x < R->c2->b1) searchTreeX(R->c2, T);
	}
}



struct RNode {
	int x0, x1, y0, y1;
	Triangle T;
	RNode *c1 = 0, *c2 = 0;
} RR;

void createTreeR(RNode *R, Triangle* T, int N) {
	if (N == 1) {
		R->x0 = T->x, R->y0 = T->y, R->x1 = T->x + T->d, R->y1 = T->y + T->d;
		R->T = T[0];
		R->c1 = R->c2 = 0;
	}
	else {
		R->x0 = R->y0 = inf, R->x1 = R->y1 = -inf;
		for (int i = 0; i < N; i++) {
			R->x0 = min(R->x0, T[i].x), R->y0 = min(R->y0, T[i].y);
			R->x1 = max(R->x1, T[i].x + T[i].d), R->y1 = max(R->y1, T[i].y + T[i].d);
		}
		int dx = R->x1 - R->x0, dy = R->y1 - R->y0;
		if (dx > dy) {
			std::sort(T, T + N, [](Triangle a, Triangle b) {return 2 * a.x + a.d < 2 * b.x + b.d; });
		}
		else {
			std::sort(T, T + N, [](Triangle a, Triangle b) {return 2 * a.y + a.d < 2 * b.y + b.d; });
		}
		R->c1 = new RNode; R->c2 = new RNode;
		createTreeR(R->c1, T, N / 2);
		createTreeR(R->c2, T + N / 2, N - N / 2);
	}
}

void searchTreeR(RNode *R, const Triangle &T) {
	if (T.x >= R->x1 || T.y >= R->y1 || T.x + T.d <= R->x0 || T.y + T.d <= R->y0) return;
	if (!(R->c1 || R->c2)) {
		if (T.x == R->T.x && T.y == R->T.y && T.d == R->T.d) return;
		int y = R->T.d + R->T.x + R->T.y - T.x;
		if (y > T.y && y < T.y + T.d) Ys[y] = true;
	}
	else {
		searchTreeR(R->c1, T);
		searchTreeR(R->c2, T);
	}
}



int main() {
#ifdef __DEBUG
	freopen("stdout.dat", "r", stdin);
	//srand(2); randCase(10);
#endif
	auto t0 = chrono::high_resolution_clock::now();
	readin;
	scanu(N);
	for (int i = 0; i < N; i++) {
		int x, y, d;
		scanu(x); scanu(y); scanu(d);
		T[i].x = x, T[i].y = y, T[i].d = d;
	}

#ifdef _DEBUG_
	for (int i = 0; i < N; i++) {
		printf("max(%d-x,%d-y,x+y%+d)=0\n", T[i].x, T[i].y, -(T[i].x + T[i].y + T[i].d));
	}

	// rasterization solution for reference
	{
		int x0 = inf, x1 = -inf, y0 = inf, y1 = -inf;
		for (int i = 0; i < N; i++) {
			x0 = min(x0, T[i].x), y0 = min(y0, T[i].y);
			x1 = max(x1, T[i].x + T[i].d), y1 = max(y1, T[i].y + T[i].d);
		}
		int dX = x1 - x0, dY = y1 - y0, A = dX * dY;
		byte *S = new byte[A];
		for (int i = 0; i < A; i++) S[i] = 0;
		for (int i = 0; i < N; i++) {
			int px = T[i].x - x0, py = T[i].y - y0, d = T[i].d;
			for (int x = 0; x < d; x++) {
				for (int y = 0; x + y < d; y++) {
					byte* s = &S[(y + py)*dX + (x + px)];
					*s = max(*s, (byte)(x + y == d - 1 ? 1 : 2));
				}
			}
		}
		lint Area = 0;
		for (int j = 0; j < dY; j++) {
			A = 0;
			for (int i = 0; i < dX; i++) {
				byte k = S[j*dX + i];
				A += k;
			}
			Area += A;
		}
		cout << fixed << setprecision(1) << (0.5*Area) << endl;
		delete S;
	}
#endif


	int minY = inf, maxY = -inf;
	for (int i = 0; i < N; i++) {
		Ys[T[i].y] = true;
		Ys[T[i].y + T[i].d] = true;
		minY = min(minY, T[i].y);
		maxY = max(maxY, T[i].y + T[i].d);
	}
	createTreeR(&RR, T, N);
	if (N > 3000) printf("%lfsecs elapsed.\n", chrono::duration<double>(chrono::high_resolution_clock::now() - t0).count());
	for (int i = 0; i < N; i++) {
		searchTreeR(&RR, T[i]);
	}
	if (N > 3000) printf("%lfsecs elapsed.\n", chrono::duration<double>(chrono::high_resolution_clock::now() - t0).count());
	vector<int> YS; YS.reserve(1000000);
	for (int i = minY; i <= maxY; i++) if (Ys[i]) YS.push_back(i);
	//sort(T, T + N, [](Triangle a, Triangle b) {return a.y < b.y; });
	sort(T, T + N, [](Triangle a, Triangle b) {return a.y * 2 + a.d < b.y * 2 + b.d; });
	createTree(&R, T, N);
	lint Area = 0;

	for (int i = 0; i < YS.size() - 1; i++) {
		int y = YS[i];
		Sn = 0;
		searchTree(&R, y);
		sort(S, S + Sn, [](Add a, Add b) { return a.x == b.x ? a.val < b.val : a.x < b.x; });
		int Sa = 0, A = 0;
		int i0, i1;
		for (int d = 0; d < Sn; d++) {
			if (!Sa) i0 = S[d].x;
			Sa += S[d].val;
			if (!Sa) {
				i1 = S[d].x;
				int h = YS[i + 1] - y;
				int b1 = i1 - i0, b0 = b1 - h;
				A += (b1 + b0)*h;
			}
		}
		Area += A;
	}

	printf("%lld", Area / 2);
	if (Area & 1) printf(".5\n");
	else printf(".0\n");

#ifdef __DEBUG
	printf("\n%lfsecs elapsed.\n", chrono::duration<double>(chrono::high_resolution_clock::now() - t0).count());
#endif

	return 0;
}