#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

#define MAXW 502
#define MAXW2 MAXW*MAXW
bool O[MAXW][MAXW];  // true: water
int K[MAXW][MAXW], K1[MAXW][MAXW];
int Ar[MAXW2], Ac[MAXW2], Ar0[MAXW2], Ac0[MAXW2], AN, AN0;
int R, C, M;


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	cin >> R >> C >> M;
	for (int i = 1; i <= R; i++) {
		char c; do { c = getchar(); } while (c <= ' ');
		for (int j = 1; j <= C; j++) {
			O[i][j] = c == '.';
			c = getchar();
		}
	}
	string S; cin >> S;
#if 0
	printf("%d %d %d\n", R, C, M);
	for (int i = 1; i <= R; i++) {
		for (int j = 1; j <= C; j++) {
			putchar(O[i][j] ? '.' : '#');
		}
		putchar('\n');
	}
	cout << S << endl << endl;
#endif

	for (int i = 1; i <= R; i++) for (int j = 1; j <= C; j++) {
		if (O[i][j]) {
			Ar0[AN0] = i, Ac0[AN0] = j;
			AN0++;
		}
	}

#define addElement(i,j) Ar[AN]=(i), Ac[AN]=(j), AN++;
	for (int d = 0; d < S.size(); d++) {
		char dir = S[d];
		AN = 0;
		for (int t = 0; t < AN0; t++) {
			int i = Ar0[t], j = Ac0[t];
			if (dir == '?' || dir == 'N') {
				if (O[i - 1][j]) K1[i - 1][j] = d + 1, addElement(i - 1, j);
			}
			if (dir == '?' || dir == 'S') {
				if (O[i + 1][j]) K1[i + 1][j] = d + 1, addElement(i + 1, j);
			}
			if (dir == '?' || dir == 'E') {
				if (O[i][j + 1]) K1[i][j + 1] = d + 1, addElement(i, j + 1);
			}
			if (dir == '?' || dir == 'W') {
				if (O[i][j - 1]) K1[i][j - 1] = d + 1, addElement(i, j - 1);
			}
		}
		for (int i = 1; i <= R; i++) for (int j = 1; j <= C; j++) K[i][j] = K1[i][j];
		AN0 = AN; for (int i = 0; i < AN; i++) Ar0[i] = Ar[i], Ac0[i] = Ac[i];
#if 0
		for (int i = 1; i <= R; i++) {
			for (int j = 1; j <= C; j++) {
				putchar(K[i][j] + '0');
			}
			putchar('\n');
		}
		putchar('\n');
#endif
	}

	int count = 0;
	int d = S.size();
	for (int i = 1; i <= R; i++) {
		for (int j = 1; j <= C; j++) {
			count += K[i][j] == d;
		}
	}
	cout << count << endl;

	return 0;
}