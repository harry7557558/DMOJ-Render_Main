#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)

#define INF 0x7FFFFFFF

int G[1000][1000];
int S[1000][1000];
int M, N;

int aR[1000000], aC[1000000], aN = 0;
int a0R[1000000], a0C[1000000], a0N = 0;

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	scanu(M); scanu(N);
	for (int i = 0; i < M; i++) for (int j = 0; j < N; j++) {
		int t; scanu(t);
		G[i][j] = t;
		S[i][j] = INF;
	}
	S[0][0] = 0;
	a0R[0] = a0C[0] = 0, a0N = 1;

	bool opr; int d = 1;
	do {
		opr = false;
		aN = 0;
		for (int u = 0; u < a0N; u++) {
			int i = a0R[u], j = a0C[u];
			int p = G[i][j];
			for (int t = 1, k = sqrt(p) + 1; t < k; t++) {
				if (p%t == 0) {
					int r = t - 1, c = p / t - 1;
					if (r < M && c < N) if (S[r][c] > d) {
						S[r][c] = d, opr = true;
						aR[aN] = r, aC[aN] = c, aN++;
					}
					if (r < N && c < M) if (S[c][r] > d) {
						S[c][r] = d, opr = true;
						aR[aN] = c, aC[aN] = r, aN++;
					}
				}
			}
		}
		d++;
		if (S[M - 1][N - 1] != INF) {
			printf("yes\n");
			return 0;
		}
		a0N = aN;
		for (int u = 0; u < aN; u++) a0C[u] = aC[u], a0R[u] = aR[u];
	} while (opr);
	printf("no\n");
	return 0;
}