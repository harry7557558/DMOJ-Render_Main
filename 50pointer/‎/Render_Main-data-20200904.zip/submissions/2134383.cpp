#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;


#ifndef __DEBUG
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#define fread fread_unlocked
#define fwrite fwrite_unlocked
#endif
#define INPUT_SIZE 1<<24
#define OUTPUT_SIZE 1<<24
int _i0 = 0, _o0 = 0;
char _, _n, __[20], _i[INPUT_SIZE], _o[OUTPUT_SIZE];
#define readin _i[fread(_i, 1, INPUT_SIZE, stdin)]=0
#define writeout fwrite(_o, 1, _o0, stdout)
#define scanu(x) do{while((_=_i[_i0++])<48);for(x=_-48;47<(_=_i[_i0++]);x=x*10+_-48);}while(0)
#define scan(x) do{while((_n=_i[_i0++])<45);if(_n-45)x=_n;else x=_i[_i0++];for(x-=48;47<(_=_i[_i0++]);x=x*10+_-48);if(_n<46)x=-x;}while(0)
inline void putnum(int x) { if (x < 0) { _o[_o0++] = '-'; x = -x; }_ = 0; do __[_++] = x % 10; while (x /= 10); while (_--)_o[_o0++] = __[_] + '0'; }



#ifdef _DEBUG
#define MaxVal 16
#else
#define MaxVal 0x40000000
#endif
int A[100000];

struct Node {
	int sz = 0;
	int val = 0;
	Node *c1 = 0, *c2 = 0;
} *R;

void addElement(Node* R, int v, int S = MaxVal) {
	R->sz++;
	if (S == 1) {
		R->val = v;
	}
	else {
		if (v < R->val + S / 2) {
			if (!R->c1) {
				R->c1 = new Node;
				R->c1->val = R->val;
			}
			addElement(R->c1, v, S / 2);
		}
		else {
			if (!R->c2) {
				R->c2 = new Node;
				R->c2->val = R->val + S / 2;
			}
			addElement(R->c2, v, S / 2);
		}
	}
}

bool removeElement(Node* R, int v, int S = MaxVal) {
	if (S == 1) {
		if (v == R->val && R->sz) {
			R->sz--; return true;
		}
		return false;
	}
	else {
		if (v < R->val + S / 2) {
			if (!R->c1) return false;
			if (removeElement(R->c1, v, S / 2)) {
				R->sz--; return true;
			}
			return false;
		}
		else {
			if (!R->c2) return false;
			if (removeElement(R->c2, v, S / 2)) {
				R->sz--; return true;
			}
			return false;
		}
	}
}

int nth_element(Node* R, int n, int S = MaxVal) {
	if (S == 1) {
		return R->val;
	}
	else {
		if (R->c1) {
			if (n < R->c1->sz) return nth_element(R->c1, n, S / 2);
			return nth_element(R->c2, n - R->c1->sz, S / 2);
		}
		else {
			return nth_element(R->c2, n, S / 2);
		}
	}
}

int first_occurence(Node* R, int v, int S = MaxVal) {
	if (R == 0) return -1;
	if (S == 1) {
		if (R->sz == 0) return -1;
		return R->val == v ? 0 : -1;
	}
	else {
		if (v < R->val + S / 2) {
			return first_occurence(R->c1, v, S / 2);
		}
		else {
			int t = first_occurence(R->c2, v, S / 2);
			return t == -1 ? t : (R->c1 ? R->c1->sz : 0) + t;
		}
	}
}

void debug_enum(Node* R, int S = MaxVal) {
	if (S == 1) {
		for (int i = 0; i < R->sz; i++)
			putnum(R->val), _o[_o0++] = ' ';
	}
	else {
		if (R->c1) debug_enum(R->c1, S / 2);
		if (R->c2) debug_enum(R->c2, S / 2);
	}
}




int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	readin;
	int N, M; scanu(N); scanu(M);
	R = new Node;
	for (int i = 0; i < N; i++) {
		int v; scanu(v);
		addElement(R, v);
	}
	int lastAns = 0;
	while (M--) {
		char cmd;
		do { cmd = _i[_i0++]; } while (cmd < 'A');
		int v; scan(v);
		v ^= lastAns;
		if (cmd == 'I') {
			addElement(R, v);
		}
		else if (cmd == 'R') {
			if (R->sz) removeElement(R, v);
		}
		else if (cmd == 'S') {
			lastAns = nth_element(R, v - 1);
			//putnum(lastAns); _o[_o0++] = '\n';
			printf("%d\n", lastAns);
		}
		else if (cmd == 'L') {
			lastAns = first_occurence(R, v);
			if (lastAns != -1) lastAns++;
			//putnum(lastAns); _o[_o0++] = '\n';
			printf("%d\n", lastAns);
		}
	}
	if (R->sz != 0) {
		debug_enum(R);
		_o[_o0 - 1] = '\n';
	}
	writeout;
	return 0;
}