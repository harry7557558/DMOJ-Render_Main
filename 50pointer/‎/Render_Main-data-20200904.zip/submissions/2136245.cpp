#include <bits/stdc++.h>
using namespace std;

template<typename T> T gcd(T a, T b) {
	while (b) {
		T t = b;
		b = a % b;
		a = t;
	}
	return a;
}


int bruteforce(int a, int b, int d) {
	int count = 0;
	for (int x = 1; x <= a; x++)
		for (int y = 1; y <= b; y++)
			count += gcd(x, y) == d;
	return count;
}


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	int n; cin >> n;
	while (n--) {
		int a, b, d; cin >> a >> b >> d;
		int c = bruteforce(a, b, d);
		cout << c << endl;
	}
	return 0;
}