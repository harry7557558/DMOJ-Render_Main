#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

typedef long long lint;

class ivec2 {
public:
	lint x, y;
	ivec2() {}
	explicit ivec2(lint a) :x(a), y(a) {}
	ivec2(lint x, lint y) :x(x), y(y) {}
	bool operator == (ivec2 v) const { return x == v.x && y == v.y; }
	ivec2 operator - () const { return ivec2(-x, -y); }
	ivec2 operator + (ivec2 v) const { return ivec2(x + v.x, y + v.y); }
	ivec2 operator - (ivec2 v) const { return ivec2(x - v.x, y - v.y); }
	ivec2 operator * (lint a) const { return ivec2(x*a, y*a); }
	lint sqr() const { return x * x + y * y; }
	friend lint dot(ivec2 u, ivec2 v) { return u.x*v.x + u.y*v.y; }
	friend lint det(ivec2 u, ivec2 v) { return u.x*v.y - u.y*v.x; }
	ivec2 rot() const { return ivec2(-y, x); }
};

#define MAXN 800
ivec2 P[MAXN];
int N; lint KM;

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
	cin >> N >> KM; KM *= 2;
	for (int i = 0; i < N; i++) cin >> P[i].x >> P[i].y;
	lint mS = 0x7FFFFFFFFFFFFFFF; int mv[4];
	for (int i = 0; i < N; i++) {
		ivec2 I = P[i];
		for (int j = 0; j < N; j++) if (j != i) {
			ivec2 J = P[j], JI = I - J;
			for (int k = 0; k < N; k++) if (k != i && k != j) {
				ivec2 K = P[k], JK = K - J;
				lint S0 = det(JI, JK);
				for (int t = 0; t < N; t++) if (t != i && t != j && t != k) {
					lint S1 = det(JK, P[t] - J);
					if ((S0 > 0) == (S1 > 0)) {
						lint S = abs(abs(S0 + S1) - KM);
						if (S < mS) {
							mS = S;
							mv[0] = j, mv[1] = i, mv[2] = k, mv[3] = t;
							if (!mS) goto Finish;
						}
					}
				}
			}
		}
	}
Finish:;
	for (int i = 0; i < 4; i++) mv[i]++;
	cout << mv[0] << " " << mv[1] << " " << mv[2] << " " << mv[3] << endl;
	return 0;
}