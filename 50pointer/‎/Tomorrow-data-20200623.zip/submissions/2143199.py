N = input()
while N:
    print(input())
    N -= 1