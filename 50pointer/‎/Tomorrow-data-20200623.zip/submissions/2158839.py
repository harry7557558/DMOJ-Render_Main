N = int(input())
for i in range(N):
    a, b = [int(t) for t in input().split()]
    c = a*a - b*b
    c //= max(a+b,a-b)
    print(c)