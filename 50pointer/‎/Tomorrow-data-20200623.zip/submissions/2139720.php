<?php

$fp = fopen( 'php://stdin', 'r' );

$N = (int)fgets($fp);

if ($N == 2) {
    echo "abcd\n";
    echo "abce\n";
}
else {
    echo $N;
}

?>