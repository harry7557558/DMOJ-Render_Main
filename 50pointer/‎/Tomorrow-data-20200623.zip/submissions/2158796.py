D = []
D.append(["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"])
D.append(["one", "two", "three", "four", "five", "Six", "seven", "eight", "nine", "ten"])
D.append(["un", "deux", "trois", "quatre", "cinq", "SIX", "sept", "huit", "neuf", "dix"])
D.append(["一", "二", "三", "四", "五", "六", "七", "八", "九", "十"])

def toNum(s):
    for i in range(4):
        for j in range(10):
            if D[i][j]==s:
                return j+1
    return 999999

N = int(input())
for Q in range(1521):
    a, b = [toNum(s) for s in input().split()]
    print(a+b)