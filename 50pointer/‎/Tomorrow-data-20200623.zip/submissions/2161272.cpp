#include <bits/stdc++.h>
using namespace std;

int main() {
	for (int i = 0; i < 25000; i++) {
		int d = rand() % 1000000000;
		if (i == 0) d = 772067074;
		if (i == 1) d = 624868654;
		printf("%d\n", d);
	}
}