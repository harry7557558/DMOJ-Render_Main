#include <bits/stdc++.h>
using namespace std;

const string D[4][10] = {
	{ "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" },
	{ "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten" },
	{ "un", "deux", "trois", "quatre", "cinq", "seis", "sept", "huit", "neuf", "dix" },
	{ "一", "二", "三", "四", "五", "六", "七", "八", "九", "十" }
};

int main() {
	int N; cin >> N;
	for (int i = 0; i < 1521; i++) {
		string a, b; cin >> a >> b;
		int A, B;
		for (int i = 0; i < 4; i++) for (int j = 0; j < 10; j++) if (a == D[i][j]) A = j + 1;
		for (int i = 0; i < 4; i++) for (int j = 0; j < 10; j++) if (b == D[i][j]) B = j + 1;
		cout << (A + B) << endl;
	}
}