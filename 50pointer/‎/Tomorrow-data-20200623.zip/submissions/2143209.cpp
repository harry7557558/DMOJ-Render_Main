#include <stdio.h>
int main(){
    int N; scanf("%d",&N);
    char c;
    while ((c=getchar_unlocked())!=EOF) putchar_unlocked(c);
    return 0;
}