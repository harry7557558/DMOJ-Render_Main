#include <bits/stdc++.h>
using namespace std;

string f(int N) {
	long long n = N;
	char s[20];
	sprintf(s, "%lld", n*n);
	return string(s);
}

int main(){
	cout << f(1234) << endl;
}