#include <bits/stdc++.h>
using namespace std;

int main() {
	for (int i = 0; i < 25000; i++) {
		printf("%d\n", rand() % 1000000000);
	}
}