#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

long long f(string s) {
	long long D = 0, M = 0, O = 0, J = 0;
	for (int i = s.size() - 1; i >= 0; i--) {
		if (s[i] == 'D') D += M;
		if (s[i] == 'M') M += O;
		if (s[i] == 'O') O += J;
		if (s[i] == 'J') J++;
	}
	return D;
}