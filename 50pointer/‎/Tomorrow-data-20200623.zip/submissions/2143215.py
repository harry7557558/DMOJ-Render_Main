import sys
input = sys.stdin.readline
for i in range(int(input())):
    print input()