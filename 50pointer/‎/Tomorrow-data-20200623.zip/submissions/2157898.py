s = input().split()
P = int(s[len(s)-1])

N = int(input())
cnt = 0
for i in range(N):
    s = input().split()
    if P > int(s[len(s)-1]):
        cnt += 1
print(cnt)