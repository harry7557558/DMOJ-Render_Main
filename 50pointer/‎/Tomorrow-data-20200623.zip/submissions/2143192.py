print(input())
print(raw_input())