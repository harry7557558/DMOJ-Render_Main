#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

string add(string a, string b);
string sub(string a, string b);
#define r0(s) s.substr(1,s.size()-1)

string add(string a, string b) {
	if (a[0] == '-') return sub(b, r0(a));
	if (b[0] == '-') return sub(a, r0(b));
	while (a.length() < b.length()) a = "0" + a;
	while (b.length() < a.length()) b = "0" + b;
	if (a[0] + b[0] - '0' >= '9') a = "0" + a, b = "0" + b;
	for (int i = a.length() - 1; i >= 0; i--) {
		a[i] += b[i] - '0';
		if (a[i] > '9') a[i] -= 10, a[i - 1]++;
	}
	while (a[0] && a[0] == '0') a.erase(0, 1);
	if (a.empty()) return "0";
	return a;
}

string sub(string a, string b) {
	if (a[0] == '-') {
		if (b[0] == '-') return sub(r0(b), r0(a));
		else return "-" + add(r0(a), b);
	}
	else if (b[0] == '-') return add(a, r0(b));
	while (a[0] && a[0] == '0') a.erase(0, 1);
	while (b[0] && b[0] == '0') b.erase(0, 1);
	bool sgn = a.size() < b.size();
	if (a.size() == b.size()) {
		int i; for (i = 0; i < a.size(); i++) {
			if (a[i] > b[i]) break;
			else if (a[i] < b[i]) { sgn = true; break; }
		}
		if (i == a.size()) return "0";
	}
	if (sgn) swap(a, b);
	while (b.size() < a.size()) b = "0" + b;
	for (int i = a.length() - 1; i >= 0; i--) {
		a[i] -= b[i] - '0';
		if (a[i] < '0') a[i] += 10, a[i - 1]--;
	}
	while (a[0] && a[0] == '0') a.erase(0, 1);
	if (sgn) a = "-" + a;
	return a;
}

int main() {
	string A, B, C;
	cin >> A >> B >> C;
	string S = add(add(A, B), C);
	if (S.length() > 6) cout << A << " " << B << " " << C << endl;
	cout << S << endl;
	return 0;
}