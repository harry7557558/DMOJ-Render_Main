#pragma GCC optimize "Os"
#include <algorithm>
#include <stdio.h>
using namespace std;

typedef long long int lint;

lint D[340000];

int main() {
	int N; scanf("%d", &N);
	if (N < 0x40000) {
	//if (false) {
		for (int i = 0; i < N; i++) scanf("%lld", D + i);
		std::sort(D, D + N);
		for (int i = 0; i < N; i++) printf("%lld\n", D[i]);
	}
	else {
		printf("%d\n", N);
		int M = N / 2; N -= M;  // M<=N

		for (int i = 0; i < N; i++) scanf("%lld", &D[i]);
		std::sort(D, D + N);
		FILE *fp1 = tmpfile();
		fwrite(&D[0], sizeof(lint), N, fp1);

		for (int i = 0; i < M; i++) scanf("%lld", &D[i]);
		std::sort(D, D + M);
		FILE *fp2 = tmpfile();
		fwrite(&D[0], sizeof(lint), M, fp2);

		rewind(fp1); rewind(fp2);

		lint C1, C2;
#define up1 fread(&C1, sizeof(lint), 1, fp1)
#define up2 fread(&C2, sizeof(lint), 1, fp2)
		up1, up2;
		int i, j;
		for (i = j = 0; i < M || j < N; ) {
			if (i < M && C1 < C2) printf("%lld\n", C1), up1, i++;
			else printf("%lld\n", C2), up2, j++;
		}
		fclose(fp1); fclose(fp2);
	}
	return 0;
}