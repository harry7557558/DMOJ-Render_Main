#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;


#define bd 1000000000

int main() {
	ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
	int N; cin >> N;
	cout << N << endl;
	for (int i = 0; i < N; i++) {
		int A, B; cin >> A >> B;
		cout << A << " " << B << endl;
	}
}