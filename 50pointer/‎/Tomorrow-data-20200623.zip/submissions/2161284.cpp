#include <bits/stdc++.h>
using namespace std;

string f(int N) {
	unsigned long long n = N;
	ostringstream os;
	os << (n*n);
	return os.str();
}

int main(){
	cout << f(1234) << endl;
}