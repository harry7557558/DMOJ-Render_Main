for i in xrange(input()):
    print input()