#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

long long f(string s) {
	long long ans = 0;
	for (int e = 0; e < s.length(); e++) {
		if (s[e] == 'e') for (int v = 0; v < e; v++) {
			if (s[v] == 'v')for (int o = 0; o < v; o++) {
				if (s[o] == 'o') for (int l = 0; l < o; l++) {
					if (s[l] == 'l') ans++;
				}
			}
		}
	}
	return ans;
}

int main() {
	string s; cin >> s;
	cout << f(s) << endl;
}