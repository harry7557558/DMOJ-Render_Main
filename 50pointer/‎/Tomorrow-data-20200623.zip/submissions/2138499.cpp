#include <bits/stdc++.h>
using namespace std;

bool f(int n) {
	if (n < 0) return false;
	int k = sqrt(0.5*n) + 0.5;
	for (int x = 0; x <= k; x++) {
		int y = sqrt(n - x * x) + 0.5;
		if (x*x + y * y == n) return true;
	}
	return false;
}

int main() {
	freopen("stdin.dat", "r", stdin);
	int Q; cin >> Q;
	while (Q--) {
		int N; cin >> N;
		cout << f(N) << endl;
	}
}