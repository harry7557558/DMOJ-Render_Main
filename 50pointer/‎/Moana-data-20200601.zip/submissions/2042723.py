import sys
N = int(sys.stdin.readline())
M = [int(t) for t in sys.stdin.read().split()]
_ = 1000000007
d = 1
for i in range(N):
    """if M[i*N+i]==0:
        for j in range(i+1,N):
            if M[j*N+i]!=0:
                for k in range(i,N):
                    t = M[i*N+k]
                    M[i*N+k]=M[j*N+k]
                    M[j*N+k]=t
                d=-d
                break"""
    v = -pow(M[i*N+i],_-2,_)
    for j in range(i+1,N):
        if M[j*N+i]!=0:
            m=(M[j*N+i]*v)%_
            for k in range(i,N):
                M[j*N+k]=(M[i*N+k]*m+M[j*N+k])%_
    d=(M[i*N+i]*d)%_
print((d+_)%_)