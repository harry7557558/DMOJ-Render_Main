#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

#define MAXN 2000
bool R[MAXN][MAXN];
int N;

int main() {
	cin >> N; char t;
	for (int i = 1; i < N; i++) {
		for (int j = 0; j < i; j++) {
			while ((t = getchar()) < 'A');
			R[i][j] = R[j][i] = t == 'R';
		}
	}
	printf("i give up bye ;)\n");
	return 0;
}