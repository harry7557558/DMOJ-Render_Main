#include <stdio.h>
#include <thread>
#include <chrono>
int main(){
    #if defined(_WIN32)
    printf("Windows\n");
    #endif
    #if defined(_WIN64)
    printf("Windows 64bit\n");
    #endif
    #if defined(unix) || defined(__unix__) || defined(__unix)
    printf("Unix\n");
    #endif
    #if defined(__APPLE__) || defined(__MACH__)
    printf("Mac OS X\n");
    #endif
    #if defined(__linux__) || defined(linux) || defined(__linux)
    printf("Linux\n");
    #endif
    #if defined(__FreeBSD__)
    printf("FreeBSD\n");
    #endif
    #if defined(__ANDROID__)
    printf("Android\n");
    #endif
    printf("%s %s\n",__DATE__,__TIME__);
    printf("%s %d\n",__FILE__,__LINE__);
    printf("%d\n",std::thread::hardware_concurrency());
    //printf("%d %d %d %d %d %d %d %d\n",sizeof(short),sizeof(int),sizeof(long int),sizeof(long long int),sizeof(float),sizeof(double),sizeof(long double),sizeof(void*));
    std::thread T([](const char* s){printf("%s\n",s);},"Hello, World!");
    std::this_thread::sleep_for(std::chrono::microseconds(1));
}