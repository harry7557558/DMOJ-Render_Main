import math
a = int(input())
b = int(input())
m = math.gcd(a,b)
a //= m
b //= m
if b==1:
    print(a)
elif a<b:
    print("%d/%d"%(a,b))
else:
    print("%d %d/%d"%(a//b,a%b,b))