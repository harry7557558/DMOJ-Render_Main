#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#include <bits/stdc++.h>
using namespace std;

#if _DEBUG
std::ifstream fin("stdin.dat");
#define cin fin
#endif

#define Mod 4294967291
typedef unsigned long long lint;

int main() {
	int N; cin >> N;
	while (N--) {
		lint n; cin >> n;
		if (n >= Mod) {
			cout << "0\n";
		}
		else {
			lint r = n;
			while (n-- > 2) r = r * n % Mod;
			cout << r << endl;
		}
	}
	return 0;
}