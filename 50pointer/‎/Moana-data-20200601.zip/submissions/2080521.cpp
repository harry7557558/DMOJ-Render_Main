#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

#if _DEBUG
std::ifstream fin("stdin.dat");
#define cin fin
#endif

typedef unsigned long long lint;
#define Mod 998244353

#define D 2000
lint M[D][D], R[D][D], T[D][D];
lint A[D];


int main() {
	int N; lint K;
	cin >> N >> K; K--;
	for (int i = 0; i < N; i++) cin >> A[i];
	for (int i = 0; i < N; i++) cin >> M[0][i];
	for (int i = 1; i < N; i++) M[i][i - 1] = 1;
	for (int i = 0; i < N; i++) R[i][i] = 1;
	while (K) {
		if (K & 1) {
			for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) {
				T[i][j] = 0;
				for (int k = 0; k < N; k++) T[i][j] += R[i][k] * M[k][j];
			}
			for (int i = 0; i < N; i++) for (int j = 0; j < N; j++)
				R[i][j] = T[i][j] % Mod;
		}
		for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) {
			T[i][j] = 0;
			for (int k = 0; k < N; k++) T[i][j] += M[i][k] * M[k][j];
		}
		for (int i = 0; i < N; i++) for (int j = 0; j < N; j++)
			M[i][j] = T[i][j] % Mod;
		K >>= 1;
	}
	lint F = 0;
	for (int i = 0; i < N; i++) F = (F + R[0][i] * A[i]) % Mod;
	cout << (F%Mod) << endl;
	return 0;
}