#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

#pragma region fast_io
#ifndef __DEBUG
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#define fread fread_unlocked
#define fwrite fwrite_unlocked
#endif
#define INPUT_SIZE 1<<22
#define OUTPUT_SIZE 1<<22
int _i0 = 0, _o0 = 0;
char _, _n, __[20], _i[INPUT_SIZE], _o[OUTPUT_SIZE];
#define readin _i[fread(_i, 1, INPUT_SIZE, stdin)]=0
#define writeout fwrite(_o, 1, _o0, stdout)
#define scanu(x) do{while((_=_i[_i0++])<48);for(x=_-48;47<(_=_i[_i0++]);x=x*10+_-48);}while(0)
#define scan(x) do{while((_n=_i[_i0++])<45);if(_n-45)x=_n;else x=_i[_i0++];for(x-=48;47<(_=_i[_i0++]);x=x*10+_-48);if(_n<46)x=-x;}while(0)
inline void putnumu(int x) { _ = 0; do __[_++] = x % 10; while (x /= 10); while (_--)_o[_o0++] = __[_] + '0'; }
#define putnl _o[_o0++]='\n'
#pragma endregion


int A[200000];
int N, Mod;

struct Node {
	int l, r;
	int Sum = 0;
	Node *c1 = 0, *c2 = 0;
} R;

void initTree(Node *R, int l, int r) {
	R->l = l, R->r = r;
	if (r - l < 2) {
		for (int i = l; i < r; i++) R->Sum = (R->Sum + A[i]) % Mod;
		return;
	}
	int c = (l + r) / 2;
	R->c1 = new Node, R->c2 = new Node;
	initTree(R->c1, l, c);
	initTree(R->c2, c, r);
	R->Sum = (R->c1->Sum + R->c2->Sum) % Mod;
}
void modifyTree(Node *R, int x, int v) {
	if (!(R->c1 || R->c2)) {
		R->Sum = v; return;
	}
	if (x < R->c1->r) {
		modifyTree(R->c1, x, v);
	}
	else {
		modifyTree(R->c2, x, v);
	}
	R->Sum = (R->c1->Sum + R->c2->Sum) % Mod;
}

int qSum(Node *R, int l, int r) {
	int sub = 0;
	Node *p = R;
	while (p->c1 && p->c2) {
		if (l < p->c1->r) {
			p = p->c1;
		}
		else {
			sub = (sub + p->c1->Sum) % Mod;
			p = p->c2;
		}
	}
	p = R;
	while (p->c1 && p->c2) {
		if (r <= p->c1->r) {
			sub = (sub + p->c2->Sum) % Mod;
			p = p->c1;
		}
		else {
			p = p->c2;
		}
	}
	return (R->Sum + Mod - sub) % Mod;
}


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	readin;
	int Q;
	scanu(Mod); scanu(N); scanu(Q);
	for (int i = 0; i < N; i++) {
		scanu(A[i]);
		A[i] %= Mod;
	}
	initTree(&R, 0, N);
	while (Q--) {
		int cmd; scanu(cmd);
#if 0
		// bruteforce solution as reference
		if (cmd == 1) {
			int l, r, x; scanu(l); scanu(r); scan(x); l--;
			for (int i = l; i < r; i++) A[i] = (A[i] + x) % Mod;
		}
		else {
			int l, r; scanu(l); scanu(r); l--;
			int cnt = 0;
			for (int i = l; i < r; i++) cnt = (cnt + A[i]) % Mod;
			putnumu(cnt); putnl;
		}
#else
		if (cmd == 1) {
			int l, r, x; scanu(l); scanu(r); scan(x); l--, x %= Mod;
			for (int i = l; i < r; i++) {
				A[i] = (A[i] + x) % Mod;
				modifyTree(&R, i, A[i]);
			}
		}
		else {
			int l, r; scanu(l); scanu(r); l--;
			int cnt = qSum(&R, l, r);
			putnumu(cnt); putnl;
		}
#endif
	}
	writeout;
	return 0;
}