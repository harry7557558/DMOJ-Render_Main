b, n = input().split()
b = int(b)
n = int(n)
print("Sun Mon Tue Wed Thr Fri Sat")
for d in range(1,b):
    print("    ", end='')
for i in range(n):
    print("{:3}".format(i+1), end='')
    if (i+b)%7==0 or i+1==n:
        print()
    else:
        print(' ',end='')