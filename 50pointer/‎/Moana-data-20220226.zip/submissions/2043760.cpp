#include <cmath>
#include <cstdio>
using namespace std;
#define PI 3.1415926535897932384626
#define mix(x,y,a) ((x)*(1.0-(a))+(y)*(a))
#define clamp(x,a,b) ((x)<(a)?(a):(x)>(b)?(b):(x))

class vec2 {
public:
	double x, y;
	vec2() {}
	vec2(double a) :x(a), y(a) {}
	vec2(double x, double y) :x(x), y(y) {}
	vec2 operator - () const { return vec2(-x, -y); }
	vec2 operator + (vec2 v) const { return vec2(x + v.x, y + v.y); }
	vec2 operator - (vec2 v) const { return vec2(x - v.x, y - v.y); }
	vec2 operator * (vec2 v) const { return vec2(x * v.x, y * v.y); } 	// non-standard
	vec2 operator * (double a) const { return vec2(x*a, y*a); }
	double sqr() const { return x * x + y * y; } 	// non-standard
	friend double length(vec2 v) { return sqrt(v.x*v.x + v.y*v.y); }
	friend vec2 normalize(vec2 v) { return v * (1. / sqrt(v.x*v.x + v.y*v.y)); }
	friend double dot(vec2 u, vec2 v) { return u.x*v.x + u.y*v.y; }
	friend double det(vec2 u, vec2 v) { return u.x*v.y - u.y*v.x; } 	// non-standard
	vec2 rot() const { return vec2(-y, x); }  // rotate 90deg counterclockwise
};

class vec3 {
public:
	double x, y, z;
	vec3() {}
	vec3(double a) :x(a), y(a), z(a) {}
	vec3(double x, double y, double z) :x(x), y(y), z(z) {}
	vec3 operator - () const { return vec3(-x, -y, -z); }
	vec3 operator + (const vec3 &v) const { return vec3(x + v.x, y + v.y, z + v.z); }
	vec3 operator - (const vec3 &v) const { return vec3(x - v.x, y - v.y, z - v.z); }
	vec3 operator * (const double &k) const { return vec3(k * x, k * y, k * z); }
	double sqr() { return x * x + y * y + z * z; } 	// non-standard
	friend double length(vec3 v) { return sqrt(v.x*v.x + v.y*v.y + v.z*v.z); }
	friend vec3 normalize(vec3 v) { return v * (1. / sqrt(v.x*v.x + v.y*v.y + v.z*v.z)); }
	friend double dot(vec3 u, vec3 v) { return u.x*v.x + u.y*v.y + u.z*v.z; }
	friend vec3 cross(vec3 u, vec3 v) { return vec3(u.y*v.z - u.z*v.y, u.z*v.x - u.x*v.z, u.x*v.y - u.y*v.x); }
	vec2 xy() const { return vec2(x, y); }
};

void printVec2(vec2 p, const char* end = "") { printf("(%lg,%lg)%s", p.x, p.y, end); }
void printVec3(vec3 p, const char* end = "") { printf("(%lg,%lg,%lg)%s", p.x, p.y, p.z, end); }
void printTetrahedra(vec3 A, vec3 B, vec3 C, vec3 D) {
	printf("Polyline(");
	printVec3(A, ","); printVec3(B, ","); printVec3(C, ","); printVec3(A, ",");
	printVec3(A, ","); printVec3(C, ","); printVec3(D, ","); printVec3(A, ",");
	printVec3(A, ","); printVec3(D, ","); printVec3(B, ","); printVec3(A, ")\n");
}
void printTriangle(vec3 A, vec3 B, vec3 C) {
	printf("Surface(If(u+v<1,");
	printVec3(A, "*(1-u-v)+"); printVec3(B, "*u+"); printVec3(C, "*v),u,0,1,v,0,1)\n");
}
void printPolygon(const vec2 *p, int N) { printf("Polyline("); for (int i = 0; i < N; i++) printVec2(p[i], ","); if (N) printVec2(p[0]); printf(")\n"); }


// test if segment a and b intersect each other
bool intersect(vec2 ap, vec2 aq, vec2 bp, vec2 bq) {
	if (det(aq - ap, bp - ap) * det(aq - ap, bq - ap) >= 0) return false;
	if (det(bq - bp, ap - bp) * det(bq - bp, aq - bp) >= 0) return false;
	return true;
}
// return the point of intersection
vec2 Intersect(vec2 P0, vec2 P1, vec2 d0, vec2 d1) {
	double t = det(d1, P1 - P0) / det(d1, d0);
	return P0 + d0 * t;
}

vec2 IntersectXOY(vec3 A, vec3 B) {
	double t = A.z / (A.z - B.z);
	return A.xy()*(1.0 - t) + B.xy()*t;
}


#include <vector>
typedef vector<vec2> polygon;

// # return the area of a polygon, negative when vertexes ordered clockwise
double calcArea(const polygon &p) {
	double A = 0;
	for (int i = 0, n = p.size(); i < n; i++) {
		A += det(p[i], p[(i + 1) % n]);
	}
	return 0.5*A;
}



// $ cut a polygon, where dot(p-p0,n)>0 part is cut off
polygon cutPolygonFromPlane(const polygon &fig, vec2 p0, vec2 n) {
	const double c = dot(p0, n);
	int l = fig.size();
	polygon res;

	// find a point that will not be cut off
	int d0;
	for (d0 = 0; d0 < l; d0++) {
		if (dot(fig[d0], n) < c) break;
	}
	if (d0 >= l) return res;  // the whole shape is cut off

	// trace segment
	auto intersect = [](vec2 p, vec2 q, const double &d, const vec2 &n)->vec2 {
		q = q - p;
		double t = (d - dot(n, p)) / dot(n, q);   // sometimes NAN
		return p + q * t;
	};
	for (int i = 0, d = d0, e = (d + 1) % l; i < l; i++, d = e, e = (e + 1) % l) {
		if (dot(fig[d], n) < c) {
			if (dot(fig[e], n) <= c) res.push_back(fig[e]);
			else res.push_back(intersect(fig[d], fig[e], c, n));
		}
		else {
			if (dot(fig[e], n) > c);
			else {
				res.push_back(intersect(fig[d], fig[e], c, n));
				res.push_back(fig[e]);
			}
		}
	}

	return res;
}


polygon Tetrahetra_IntXOY(vec3 A, vec3 B, vec3 C, vec3 D) {
	bool a = A.z > 0, b = B.z > 0, c = C.z > 0, d = D.z > 0;
	int s = int(a) + int(b) + int(c) + int(d);
	if (s % 4 == 0) return polygon();
	if (s == 3) a ^= 1, b ^= 1, c ^= 1, d ^= 1, s = 1;
	if (s == 1) {
		if (b) swap(A, B); else if (c) swap(A, C); else if (d) swap(A, D);
		return polygon({ IntersectXOY(A,B), IntersectXOY(A,C), IntersectXOY(A,D) });
	}
	else if (s == 2) {
		if (A.z < B.z) swap(A, B); if (B.z < C.z) swap(B, C); if (C.z < D.z) swap(C, D); if (A.z < B.z) swap(A, B); if (B.z < C.z) swap(B, C); if (A.z < B.z) swap(A, B);
		vec2 a = IntersectXOY(A, C), b = IntersectXOY(A, D), c = IntersectXOY(B, C), d = IntersectXOY(B, D);
		if (intersect(a, d, b, c)) swap(a, b);
		else if (intersect(a, b, c, d)) swap(b, c);
		return polygon({ a, b, c, d });
	}
}


vec3 tP(vec3 p, vec3 i, vec3 j, vec3 k) {
	return vec3(dot(p, i), dot(p, j), dot(p, k));
}

double subA(vec3 P, vec3 Q, vec3 R, vec3 A, vec3 B, vec3 C, vec3 D) {
	vec3 i = Q - P, j = R - P, k = cross(i, j);
	double det = dot(k, k);
	vec3 Mi(j.y * k.z - j.z * k.y, j.z * k.x - j.x * k.z, j.x * k.y - j.y * k.x), Mj(i.z * k.y - i.y * k.z, i.x * k.z - i.z * k.x, i.y * k.x - i.x * k.y), Mk(i.y * j.z - i.z * j.y, i.z * j.x - i.x * j.z, i.x * j.y - i.y * j.x);
	Mi = Mi * (1. / det), Mj = Mj * (1. / det), Mk = Mk * (1. / det);
	auto tP = [&](vec3 &p) { p = p - P; p = vec3(dot(p, Mi), dot(p, Mj), dot(p, Mk)); };
	tP(A), tP(B), tP(C), tP(D);
	polygon clip = Tetrahetra_IntXOY(A, B, C, D);
	if (clip.size() == 0) return 0.5*sqrt(det);
	polygon path({ vec2(0,0), vec2(1,0), vec2(0,1) });
	if (calcArea(clip) < 0.0) {
		for (int i = 0, n = clip.size(); i < n; i++)
			path = cutPolygonFromPlane(path, clip[i], (clip[(i + 1) % n] - clip[i]).rot());
	}
	else {
		for (int i = 0, n = clip.size(); i < n; i++)
			path = cutPolygonFromPlane(path, clip[i], -(clip[(i + 1) % n] - clip[i]).rot());
	}
	return (0.5 - calcArea(path))*sqrt(det);
}

#ifdef _DEBUG
#include <bits/stdc++.h>
ifstream fin("stdin.dat");
#define cin fin
#endif

#include <iostream>
istream& operator >> (istream& is, vec3 &p) {
	is >> p.x >> p.y >> p.z;
	return is;
}
int main() {
	vec3 A1, A2, A3, A4, B1, B2, B3, B4;
	cin >> A1 >> A2 >> A3 >> A4 >> B1 >> B2 >> B3 >> B4;
	double SAB = subA(A1, A2, A3, B1, B2, B3, B4) + subA(A1, A2, A4, B1, B2, B3, B4) + subA(A1, A3, A4, B1, B2, B3, B4) + subA(A2, A3, A4, B1, B2, B3, B4);
	double SBA = subA(B1, B2, B3, A1, A2, A3, A4) + subA(B1, B2, B4, A1, A2, A3, A4) + subA(B1, B3, B4, A1, A2, A3, A4) + subA(B2, B3, B4, A1, A2, A3, A4);
	printf("%.16lf\n", SAB + SBA);
}