#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

int N;
int M[100000];

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	//freopen("stdout.dat", "w", stdout);
#endif
	cin >> N;
	for (int i = 0; i < N; i++) cin >> M[i];
	int Q; cin >> Q;
	while (Q--) {
		int a, b, q; cin >> a >> b >> q;
		int count = 0;
		for (int i = a; i <= b; i++) count += M[i] * (M[i] >= q);
		cout << count << endl;
	}
	return 0;
}