import math

Prime = []

def isPrime(N):
    if N<2: return False
    if N==2 or N==3: return True
    if N%2==0 or N%3==0: return False
    k = int(math.sqrt(N))
    for i in range(4,k,6):
        if N%(i+1)==0 or N%(i+3)==0: return False
    return True

i = 2
while len(Prime)<100000:
    if isPrime(i):
        Prime.append(i)
    i += 1

def Phi(x, a, sgn=1):
    if a==0: return sgn*x
    if a==1: return sgn*(x-x//2)
    if a==2: return sgn*(x-x//2-x//3+x//6)
    r = 0
    while a > 3:
        if a < 100000 and x < Prime[a]:
            return r + sgn
        a -= 1
        r += Phi(x//Prime[a], a, -sgn)
    return r + sgn*(x-x//2-x//3+x//6-x//5+x//10+x//15-x//30)

def Pi(x):
    if x < 2:
        return 0
    if x <= Prime[99999]:
        p0 = 0
        p1 = 99999
        while p1-p0>1:
            p = (p0+p1)//2
            if Prime[p]>x:
                p1 = p
            elif Prime[p]<x:
                p0 = p
            else:
                print("Find: ", p)
                return p + 1
        print("Between: ", p0, p1)
        if x == Prime[p1]:
            return p1 + 1
        return p1
    a = Pi(math.sqrt(math.sqrt(x)))
    b = Pi(math.sqrt(x))
    c = Pi(math.pow(x,1/3))
    res = Phi(x,a)+(b+a-2)*(b-a+1)//2
    for i in range(a,b):
        k = x // Prime[i]
        res -= Pi(k)
        if i<c:
            j1 = Pi(math.sqrt(k))
            for j in range(i,j1):
                res -= Pi(k//Prime[j])
    return res

#while 1: print(Pi(int(input("Enter integer: "))))

a = int(input())
b = int(input())
print(a,b)
print(Pi(b-1)-Pi(a-1))