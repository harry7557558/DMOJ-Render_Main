#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

//typedef long long lint;
#define lint int

#ifndef __DEBUG
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#define fread fread_unlocked
#define fwrite fwrite_unlocked
#endif

#define INPUT_SIZE 1<<22
#define OUTPUT_SIZE 1<<22
int _i0 = 0, _o0 = 0;
char _, _n, __[20], _i[INPUT_SIZE], _o[OUTPUT_SIZE];
#define scanu(x) do{while((_=_i[_i0++])<48);for(x=_-48;47<(_=_i[_i0++]);x=x*10+_-48);}while(0)
#define scan(x) do{while((_n=_i[_i0++])<45);if(_n-45)x=_n;else x=_i[_i0++];for(x-=48;47<(_=_i[_i0++]);x=x*10+_-48);if(_n<46)x=-x;}while(0)
#define putnumu(x) { _ = 0; do __[_++] = x % 10; while (x /= 10); while (_--)_o[_o0++] = __[_] + '0'; }

#define MAXN 100000
lint x[MAXN];
int vx[MAXN], vy[MAXN];

int V[0x1000000];
int S[MAXN + 1];


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	//freopen("stdout.dat", "w", stdout);
#endif
	fread(_i, 1, INPUT_SIZE, stdin);
	int N; scanu(N);
	lint L, R, Y; scan(L); scan(R); scan(Y);
	for (int i = 0; i < N; i++) {
		lint t; scan(t); x[i] = t;
		scanu(t); vy[i] = t; scanu(t); vx[i] = t;
	}
	R++;

	lint dX = R - L;
	//for (int i = 0; i <= N; i++) S[i] = dX;

	for (int d = 0; d < N; d++) {
		int X = Y * vx[d], vd = vy[d]; X = (X - (X%vd == 0)) / vd;
		lint i0 = x[d] - X, i1 = x[d] + X + 1;
		i0 = i0<L ? L : i0, i1 = i1>R ? R : i1;
		int* Vi = &V[i0 - L];
		for (lint i = 0, im = i1 - i0; i < im; i++) {
			(*(Vi++))++;
		}
	}

	for (int i = 0; i < dX; i++) S[V[i]]++;
	for (int i = 1; i <= N; i++) S[i] += S[i - 1];

	for (int i = 0; i <= N; i++) {
		int t = S[i]; putnumu(t); _o[_o0++] = '\n';
	}
	fwrite(_o, 1, _o0, stdout);
	return 0;
}