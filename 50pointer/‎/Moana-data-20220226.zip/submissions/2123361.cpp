#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

#pragma region fast_io
#ifndef __DEBUG
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#define fread fread_unlocked
#define fwrite fwrite_unlocked
#endif
#define INPUT_SIZE 1<<22
#define OUTPUT_SIZE 1<<22
int _i0 = 0, _o0 = 0;
char _, _n, __[20], _i[INPUT_SIZE], _o[OUTPUT_SIZE];
#define readin _i[fread(_i, 1, INPUT_SIZE, stdin)]=0
#define writeout fwrite(_o, 1, _o0, stdout)
#define scanu(x) do{while((_=_i[_i0++])<48);for(x=_-48;47<(_=_i[_i0++]);x=x*10+_-48);}while(0)
#define scan(x) do{while((_n=_i[_i0++])<45);if(_n-45)x=_n;else x=_i[_i0++];for(x-=48;47<(_=_i[_i0++]);x=x*10+_-48);if(_n<46)x=-x;}while(0)
inline void putnumu(int x) { _ = 0; do __[_++] = x % 10; while (x /= 10); while (_--)_o[_o0++] = __[_] + '0'; }
#define putnl _o[_o0++]='\n'
#pragma endregion


int A[200000];

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	readin;
	int M, N, Q;
	scanu(M); scanu(N); scanu(Q);
	for (int i = 0; i < N; i++) scanu(A[i]);
	while (Q--) {
		int cmd; scanu(cmd);
		if (cmd == 1) {
			int l, r, x; scanu(l); scanu(r); scan(x); l--;
			for (int i = l; i < r; i++) A[i] += x;
		}
		else {
			int l, r; scanu(l); scanu(r); l--;
			int cnt = 0;
			for (int i = l; i < r; i++) cnt = (cnt + A[i]) % M;
			putnumu(cnt); putnl;
		}
	}
	writeout;
	return 0;
}