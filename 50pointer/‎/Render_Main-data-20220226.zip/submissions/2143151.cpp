#include <bits/stdc++.h>
using namespace std;

/*
-1000000 ~ 1000000
0: 500001
1: 500000
2: 500000
3: 500000
0,0,0,0 - 500001**4 = 62500500001500002000001
0,0,2,2 - 6*500001**2*500000**2 = 375001500001500000000000
1,1,1,1 - 500000**4 = 62500000000000000000000
1,1,3,3 - 6*500000**2*500000**2 = 375000000000000000000000
2,2,2,2 - 500000**4 = 62500000000000000000000
3,3,3,3 - 500000**4 = 62500000000000000000000
tot: 1000002000003000002000001 (50979099)
*/


#define X 0x3FFFFFFF

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif

	// readin
	int A[3][3];
	char s[12];
	for (int i = 0; i < 9; i++) {
		scanf("%s", &s);
		(&A[0][0])[i] = s[0] == 'X' ? X : stoi(s);
	}

	// reducing terms
#define sgX(a, b, c) (a==X && b!=X && c!=X)
#define to0(_0, _1, _2) _0 = 2*_1 - _2
#define to1(_0, _1, _2) _1 = (_0 + _2) / 2
#define to2(_0, _1, _2) _2 = 2*_1 - _0
	bool opr;
	do {
		opr = false;
		for (int i = 0; i < 3; i++) {
			if (sgX(A[i][0], A[i][1], A[i][2])) to0(A[i][0], A[i][1], A[i][2]), opr = true;
			if (sgX(A[i][1], A[i][0], A[i][2])) to1(A[i][0], A[i][1], A[i][2]), opr = true;
			if (sgX(A[i][2], A[i][0], A[i][1])) to2(A[i][0], A[i][1], A[i][2]), opr = true;
			if (sgX(A[0][i], A[1][i], A[2][i])) to0(A[0][i], A[1][i], A[2][i]), opr = true;
			if (sgX(A[1][i], A[0][i], A[2][i])) to1(A[0][i], A[1][i], A[2][i]), opr = true;
			if (sgX(A[2][i], A[0][i], A[1][i])) to2(A[0][i], A[1][i], A[2][i]), opr = true;
		}
	} while (opr);

	for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
		printf("%d%c", A[i][j], j == 2 ? '\n' : ' ');
	}
	return 0;
}