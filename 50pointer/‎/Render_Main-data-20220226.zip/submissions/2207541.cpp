#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)


typedef long long lint;
int N, K;
lint A[100000], S[200001];

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	scanu(N); scanu(K);
	for (int i = 0; i < N; i++) {
		int t; scan(t); A[i] = t;
	}
	S[0] = 0; for (int i = 0; i < N; i++) S[i + 1] = S[i] + A[i];
	for (int i = 0; i < K; i++) S[i + N + 1] = S[i + N] + A[i];

	lint mm = 0;
	for (int i = 0; i < N; i++) {
		for (int j = 1; j <= K; j++) {
			lint m = S[i + j] - S[i];
			mm = max(mm, m);
		}
	}
	printf("%lld\n", mm);
	return 0;
}