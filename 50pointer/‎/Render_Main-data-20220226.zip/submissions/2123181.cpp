#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

int modInverse(int a, int m) {
	int m0 = m;
	int y = 0, x = 1;
	if (m == 1) return 0;
	while (a > 1) {
		int q = a / m;
		int t = m;
		m = a % m, a = t;
		t = y;
		y = x - q * y;
		x = t;
	}
	if (x < 0) x += m0;
	return x;
}


int main() {
	int N, M; cin >> N >> M;
	cout << modInverse(N, M) << endl;
	return 0;
}