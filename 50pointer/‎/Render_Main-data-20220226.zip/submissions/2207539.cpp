// https://dmoj.ca/src/1672625
// should get TLE?

#pragma GCC optimize "Ofast"

#include <iostream>
using namespace std;

int main() {
	ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
	int N, K;
	cin >> N >> K;
	int *d = new int[N];
	long long *s = new long long[2 * N];
	long long max = -0x7FFFFFFFFFFFFFFF;
	for (int i = 0; i < N; i++) {
		cin >> d[i];
		if (d[i] > max) max = d[i];
		s[i] = d[i];
		if (i) s[i] += s[i - 1];
	}
	for (int i = 0; i < N; i++) {
		s[i + N] = s[i + N - 1] + d[i];
	}
	//for (int i = 0; i < N; i++) cout << d[i] << " "; cout << endl;
	//for (int i = 0; i < 2 * N; i++) cout << s[i] << " "; cout << endl;
	long long V;
	for (int i = N; i < 2 * N; i++) {
		for (int j = 1; j < K; j++) {
			if (i - j - 1 < 0) V = s[i];
			else V = s[i] - s[i - j - 1];
			if (V > max) max = V;
		}
	}
	cout << max << endl;
	delete d, s;
	return 0;
}