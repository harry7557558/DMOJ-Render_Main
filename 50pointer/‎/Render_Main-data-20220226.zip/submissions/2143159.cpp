#include <bits/stdc++.h>
using namespace std;

/*
-1000000 ~ 1000000
0: 500001
1: 500000
2: 500000
3: 500000
0,0,0,0 - 500001**4 = 62500500001500002000001
0,0,2,2 - 6*500001**2*500000**2 = 375001500001500000000000
1,1,1,1 - 500000**4 = 62500000000000000000000
1,1,3,3 - 6*500000**2*500000**2 = 375000000000000000000000
2,2,2,2 - 500000**4 = 62500000000000000000000
3,3,3,3 - 500000**4 = 62500000000000000000000
total: 1000002000003000002000001
*/

#define _0000 505052029
#define _0022 253060764  // need to multiply by 6
#define _1111 3062500
#define _1133 3062500  // need to multiply by 6
#define _2222 3062500
#define _3333 3062500
#define _XXXX 50979099


#define X 0x3FFFFFFF
#define Mod 1000000007
#define Finish(x) { printf("%d\n", ((x)%Mod+Mod)%Mod); exit(0); }

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif

	// readin
	int A[3][3], *Al = &A[0][0];
	char s[12];
	for (int i = 0; i < 9; i++) {
		scanf("%s", &s);
		Al[i] = s[0] == 'X' ? X : stoi(s);
	}

	// reducing terms
#define sgX(a, b, c) (a==X && b!=X && c!=X)
#define to0(_0, _1, _2) _0 = 2*_1 - _2
#define to1(_0, _1, _2) _1 = (_0 + _2) / 2
#define to2(_0, _1, _2) _2 = 2*_1 - _0
	bool opr;
	do {
		opr = false;
		for (int i = 0; i < 3; i++) {
			if (sgX(A[i][0], A[i][1], A[i][2])) to0(A[i][0], A[i][1], A[i][2]), opr = true;
			if (sgX(A[i][1], A[i][0], A[i][2])) to1(A[i][0], A[i][1], A[i][2]), opr = true;
			if (sgX(A[i][2], A[i][0], A[i][1])) to2(A[i][0], A[i][1], A[i][2]), opr = true;
			if (sgX(A[0][i], A[1][i], A[2][i])) to0(A[0][i], A[1][i], A[2][i]), opr = true;
			if (sgX(A[1][i], A[0][i], A[2][i])) to1(A[0][i], A[1][i], A[2][i]), opr = true;
			if (sgX(A[2][i], A[0][i], A[1][i])) to2(A[0][i], A[1][i], A[2][i]), opr = true;
		}
	} while (opr);

	// count the number of Xs
	int nX = 0;
	for (int i = 0; i < 9; i++) nX += Al[i] == X;

	// the ****ing casing
	if (nX == 9) Finish(_XXXX);

	if (nX == 8) {
		int V; for (int i = 0; i < 9; i++) if (Al[i] != X) V = Al[i];
		if (A[0][0] != X || A[0][2] != X || A[2][0] != X || A[2][2] != X) {
			if (V % 4 == 0) Finish(_XXXX - _0000 - 3 * _0022);
			if (V % 4 == 1) Finish(_XXXX - _1111 - 3 * _1133);
			if (V % 4 == 2) Finish(_XXXX - _2222 - 3 * _0022);
			if (V % 4 == 3) Finish(_XXXX - _3333 - 3 * _1133);
		}
	}

	for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
		printf("%d%c", A[i][j], j == 2 ? '\n' : ' ');
	}
	return 0;
}