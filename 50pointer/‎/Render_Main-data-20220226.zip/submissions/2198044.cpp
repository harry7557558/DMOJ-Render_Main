#include <bits/stdc++.h>
using namespace std;

typedef unsigned long long lint;

int digitsum(lint x) {
	int s = 0;
	while (x) s += x % 10, x /= 10;
	return s;
}

int maxDigitSum_BF(lint N, lint M) {
	int ms = 0;
	for (lint i = N; i <= M; i++) {
		ms = max(digitsum(i), ms);
	}
	return ms;
}

int digitcount(lint N) {
	int n = 0;
	while (N) n++, N /= 10;
	return n;
}
lint exp10i(int n) {
	lint r = 1;
	while (n--) r *= 10;
	return r;
}
int maxDigitSum(lint N, lint M, bool checkDigit = true) {
	if (checkDigit) {
		int n = digitcount(N), m = digitcount(M);
		if (n != m) {
			int ms = 9 * (m - 1);
			ms = max(ms, maxDigitSum(N, exp10i(n) - 1, false));
			ms = max(ms, maxDigitSum(exp10i(m - 1), M, false));
			return ms;
		}
	}
	return maxDigitSum_BF(N, M);
}


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	int Q; cin >> Q;
	while (Q--) {
		lint N, M; cin >> N >> M;
		cout << maxDigitSum(N, M) << endl;
	}
}