#include <bits/stdc++.h>
using namespace std;

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	for (int Q = 0; Q < 5; Q++) {
		string s; getline(cin, s);
		vector<string> ss;
		for (int i = 0; i < s.size(); i++) {
			if (s[i] == '"') {
				string t;
				while (s[++i] != '"') t.push_back(s[i]);
				ss.push_back(t);
			}
			else if (s[i] == '\'') {
				string t;
				while (s[++i] != '\'') t.push_back(s[i]);
				ss.push_back(t);
			}
			else if (s[i] == '/' && s[i + 1] == '*') {
				string t; i += 2;
				while (!(s[i] == '*' && s[i + 1] == '/')) {
					t.push_back(s[i++]);
				}
				ss.push_back(t);
			}
			else if (s[i] == '/' && s[i + 1] == '/') {
				string t; i++;
				while (s[++i]) t.push_back(s[i]);
				ss.push_back(t);
			}
		}
		for (int i = 0; i < ss.size(); i++) {
			cout << ss[i] << char(i + 1 == ss.size() ? '\n' : ' ');
		}
	}
}