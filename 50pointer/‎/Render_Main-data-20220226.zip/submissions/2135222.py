N = int(input())
for i in range(N):
    a, b = [int(t) for t in input().split()]
    if a<1: a=1
    if b<1: b=1
    if a>10: a=10
    if b>10: b=10
    print(a+b)