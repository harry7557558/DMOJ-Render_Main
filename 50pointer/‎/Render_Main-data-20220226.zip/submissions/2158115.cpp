#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;


//====================== Primes ==============================

int Primes[2000000], PrimeN = 0;

void initPrimes(int N = 9000000) {
	bool *p = new bool[N];
	for (int i = 0; i < N; i++) p[i] = true;
	for (int i = 2; i < N; i++) {
		if (p[i]) {
			for (int j = 0; j < PrimeN; j++) {
				int k = i * Primes[j];
				if (k < N) p[k] = false;
				else break;
				//if (i%Primes[j] == 0) break;
			}
			Primes[PrimeN++] = i;
		}
	}
	delete p;
}

//====================== Factors ==============================

int *Factors[9000000], NFactor[9000000];
void initFactor(int N) {
	if (NFactor[N]) return;
	int N0 = N;
	int PFs[20], PFRep[20], PFn = 0;
	for (int t = 0; N > 1; t++) {
		int p = Primes[t];
		if (p*p > N) break;
		if (N%p == 0) {
			PFs[PFn] = p;
			PFRep[PFn] = 1;
			N /= p;
			while (N%p == 0) PFRep[PFn]++, N /= p;
			PFn++;
		}
	}
	if (N > 1) {
		PFs[PFn] = N;
		PFRep[PFn] = 1;
		PFn++;
	}
	int Fn = 1;
	for (int i = 0; i < PFn; i++) Fn *= PFRep[i] + 1;
	NFactor[N0] = Fn;
	int *F = Factors[N0] = new int[Fn];
	F[0] = 1; int tp = 1;
	for (int i = 0; i < PFn; i++) {
		int pd = PFs[i], *k = &F[tp];
		for (int r = 1; r <= PFRep[i]; r++) {
			for (int t = 0; t < tp; t++) *k = pd * F[t], k++;
			pd *= PFs[i];
		}
		tp *= PFRep[i] + 1;
	}
	sort(F, F + Fn);
}


//====================== Global Vars ==============================

#define INF 0x7FFFFFFF

int S[3001][3001];

int aR[1000000], aC[1000000], aN = 0;
int a0R[1000000], a0C[1000000], a0N = 0;


//====================== Main ==============================

bool can_escape(int M, int N, vector<vector<int>> G) {
	int maxVal = 0;
	for (int i = 1; i <= M; i++) for (int j = 1; j <= N; j++) {
		S[i][j] = INF;
		maxVal = max(maxVal, G[i][j]);
	}
	S[1][1] = 0;
	a0R[0] = a0C[0] = 1, a0N = 1;
	initPrimes(maxVal);

	bool opr; int d = 1;
	do {
		opr = false;
		aN = 0;
		for (int u = 0; u < a0N; u++) {
			int i = a0R[u], j = a0C[u];
			int P = G[i][j];
			initFactor(P);
			int *F = Factors[P], Fn = NFactor[P];
			for (int t = 0, tm = (Fn >> 1) + (Fn & 1); t < tm; t++) {
				int r = F[t], c = F[Fn - t - 1];
				if (r <= M && c <= N) if (S[r][c] > d) {
					S[r][c] = d, opr = true;
					aR[aN] = r, aC[aN] = c, aN++;
				}
				swap(r, c);
				if (r <= M && c <= N) if (S[r][c] > d) {
					S[r][c] = d, opr = true;
					aR[aN] = r, aC[aN] = c, aN++;
				}
			}
			if (S[M][N] != INF) return true;
		}
		d++;
		a0N = aN;
		for (int u = 0; u < aN; u++) a0C[u] = aC[u], a0R[u] = aR[u];
	} while (opr);

	return false;
}

#define Rand() (rand()*RAND_MAX+rand())
int main() {
	int M = 3000, N = 3000;
	//initPrimes(M*N); return 0;
	vector<vector<int>> G;
	G.reserve(M + 1); G.push_back(vector<int>());
	for (int i = 1; i <= M; i++) {
		vector<int> t; t.reserve(N + 1);
		t.push_back(0); for (int j = 1; j <= N; j++) t.push_back(Rand() % (M*N) + 1);
		G.push_back(t);
	}
	cout << can_escape(M, N, G) << endl;
}