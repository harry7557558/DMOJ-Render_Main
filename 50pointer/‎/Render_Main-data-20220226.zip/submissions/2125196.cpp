#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

#pragma region fast_io
#ifndef __DEBUG
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#define fread fread_unlocked
#define fwrite fwrite_unlocked
#endif
#define INPUT_SIZE 1<<25
#define OUTPUT_SIZE 1<<24
int _i0 = 0, _o0 = 0;
char _, _n, __[20], _i[INPUT_SIZE], _o[OUTPUT_SIZE];
#define readin _i[fread(_i, 1, INPUT_SIZE, stdin)]=0
#define writeout fwrite(_o, 1, _o0, stdout)
#define scanu(x) do{while((_=_i[_i0++])<48);for(x=_-48;47<(_=_i[_i0++]);x=x*10+_-48);}while(0)
#define putnl _o[_o0++]='\n'
#pragma endregion


bool isPower2(unsigned long long x) {
	unsigned long long k = (int)log2(x);
	return (1 << k) == x;
}


int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
#endif
	readin;
	int N; scanu(N);
	while (N--) {
		unsigned long long x;
		scanu(x);
		_o[_o0++] = isPower2(x) ? 'T' : 'F';
		_o[_o0++] = '\n';
	}
	writeout;
}