#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

int main() {
	unsigned N, M; scanf("%u%u", &N, &M);
	for (unsigned i = 0; i < N; i++) {
		unsigned q = 1024 * (i ^ (i >> 1));
		for (unsigned j = 0; j < M; j++) {
			printf("%u%c", q | (j ^ (j >> 1)), j == M - 1 ? '\n' : ' ');
		}
	}
	return 0;
}