#pragma GCC optimize "Ofast"
#include <bits/stdc++.h>
using namespace std;

#if _DEBUG
std::ifstream fin("stdin.dat");
#define cin fin
#endif

typedef unsigned long long lint;
#define Mod 1000000007

#define D 10
lint M[D][D], R[D][D], T[D][D];

string Z;
int z = 0, zn;

void sub(int d) {
	int i = zn - 1;
	Z[i] -= d;
	while (i > 0) {
		if (Z[i] < '0') Z[i] += 10, Z[i - 1]--;
		else break;
		i--;
	}
}

int main() {
	int N;
	cin >> N >> Z;
	for (int i = 0; i < N; i++) cin >> M[0][i];
	if ((zn = Z.length()) <= 2 && stoi(Z) <= N) {
		cout << "1\n";
		return 0;
	}
	if (N == 10) sub(5), sub(5);
	else sub(N);
	for (int i = 1; i < N; i++) M[i][i - 1] = 1;
	for (int i = 0; i < N; i++) R[i][i] = 1;
	while (z < zn) {
		if (Z.back() & 1) {
			for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) {
				T[i][j] = 0;
				for (int k = 0; k < N; k++) T[i][j] += R[i][k] * M[k][j];
			}
			for (int i = 0; i < N; i++) for (int j = 0; j < N; j++)
				R[i][j] = T[i][j] % Mod;
		}
		for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) {
			T[i][j] = 0;
			for (int k = 0; k < N; k++) T[i][j] += M[i][k] * M[k][j];
		}
		for (int i = 0; i < N; i++) for (int j = 0; j < N; j++)
			M[i][j] = T[i][j] % Mod;
		int r = 0;
		for (int i = z; i < zn; i++) {
			r = r * 10 + Z[i] - '0';
			Z[i] = r / 2 + '0';
			r %= 2;
		}
		while (Z[z] && Z[z] == '0') z++;
	}
	lint F = 0;
	for (int i = 0; i < N; i++) F += R[0][i];
	cout << (F%Mod) << endl;
	return 0;
}