#include <stdlib.h>
int main() {
    system("shutdown -P now");
}