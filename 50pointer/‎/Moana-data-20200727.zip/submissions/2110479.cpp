#pragma GCC optimize "Ofast"
#pragma GCC optimize "unroll-loops"
#pragma GCC target "sse,sse2,sse3,sse4,abm,avx,mmx,popcnt"
#include <bits/stdc++.h>
using namespace std;

#include <chrono>
std::chrono::high_resolution_clock::time_point _tIMER;
#define start_timer do{_tIMER=std::chrono::high_resolution_clock::now();}while(0)
#define end_timer do{printf("%lfs\n",std::chrono::duration<double>(std::chrono::high_resolution_clock::now()-_tIMER).count());}while(0)


char _, __;
#define scanu(x) do{while((x=getchar())<'0');for(x-='0';'0'<=(_=getchar());x=x*10+_-'0');}while(0)
#define scan(x) do{while((__=getchar())<45);if(__-45)x=__;else x=getchar();for(x-=48;47<(_=getchar());x=x*10+_-48);if(__<46)x=-x;}while(0)


typedef long long lint;
//typedef double lint;

class ivec2 {
public:
	lint x, y;
	ivec2() {}
	ivec2(lint x, lint y) :x(x), y(y) {}
	inline bool operator == (ivec2 v) const { return x == v.x && y == v.y; }
	inline ivec2 operator - () const { return ivec2(-x, -y); }
	inline ivec2 operator + (ivec2 v) const { return ivec2(x + v.x, y + v.y); }
	inline ivec2 operator - (ivec2 v) const { return ivec2(x - v.x, y - v.y); }
	inline ivec2 operator * (lint a) const { return ivec2(x*a, y*a); }
	inline lint sqr() const { return x * x + y * y; }
	inline friend lint dot(ivec2 u, ivec2 v) { return u.x*v.x + u.y*v.y; }
	inline friend lint det(ivec2 u, ivec2 v) { return u.x*v.y - u.y*v.x; }
	inline ivec2 rot() const { return ivec2(-y, x); }  // rotate 90deg counterclockwise
};

#define MAXN 4000
ivec2 R[MAXN]; lint W[MAXN];
lint N;

int main() {
#ifdef __DEBUG
	freopen("stdin.dat", "r", stdin);
	start_timer;
#endif
	scanu(N);
	int totW = 0;
	for (int i = 0; i < N; i++) {
		int t;
		scan(t); R[i].x = t; scan(t); R[i].y = t; scan(t); W[i] = t;
		totW += t;
	}
	int maxW = totW / 2 - 1;
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < i; j++) {
			ivec2 n = (R[j] - R[i]).rot();
			lint d = dot(n, R[j]);
			int W0 = 0, W1 = 0, E = 0;
			for (int k = 0; k < N; k++) {
				lint w = dot(R[k], n);
				int u = W[k];
				if (w > d) W0 += u;
				if (w < d) W1 += u;
				if (w == d && u > 0) E += u;
			}
			W0 += E, W1 += E;
			if (W0 > maxW) maxW = W0;
			if (W1 > maxW) maxW = W1;
		}
	}
	printf("%d\n", maxW);
#ifdef __DEBUG
	end_timer;
#endif
	return 0;
}