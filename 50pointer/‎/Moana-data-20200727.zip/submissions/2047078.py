import sys
P = [i>1 for i in range(int(raw_input())+2)]
for i in range(2,len(P)-2):
    if P[i]:
        P=[P[j] if not(j!=i and j%i==0) else False for j in range(len(P))]
        sys.stdout.write(str(i)+'*\n' if P[i-2] or P[i+2] else str(i)+'\n')