import math
print("The largest square has side length %d."%(int(math.sqrt(int(input())))))