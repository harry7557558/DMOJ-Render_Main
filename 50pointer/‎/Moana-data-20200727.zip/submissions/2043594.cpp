#include <cmath>
using namespace std;
#define PI 3.1415926535897932384626
#define mix(x,y,a) ((x)*(1.0-(a))+(y)*(a))
#define clamp(x,a,b) ((x)<(a)?(a):(x)>(b)?(b):(x))

class vec2 {
public:
	double x, y;
	vec2() {}
	vec2(double a) :x(a), y(a) {}
	vec2(double x, double y) :x(x), y(y) {}
	vec2 operator - () const { return vec2(-x, -y); }
	vec2 operator + (vec2 v) const { return vec2(x + v.x, y + v.y); }
	vec2 operator - (vec2 v) const { return vec2(x - v.x, y - v.y); }
	vec2 operator * (vec2 v) const { return vec2(x * v.x, y * v.y); } 	// non-standard
	vec2 operator * (double a) const { return vec2(x*a, y*a); }
	double sqr() const { return x * x + y * y; } 	// non-standard
	friend double length(vec2 v) { return sqrt(v.x*v.x + v.y*v.y); }
	friend vec2 normalize(vec2 v) { return v * (1. / sqrt(v.x*v.x + v.y*v.y)); }
	friend double dot(vec2 u, vec2 v) { return u.x*v.x + u.y*v.y; }
	friend double det(vec2 u, vec2 v) { return u.x*v.y - u.y*v.x; } 	// non-standard
	vec2 rot() const { return vec2(-y, x); }  // rotate 90deg counterclockwise
};

// test if segment a and b intersect each other
bool intersect(vec2 ap, vec2 aq, vec2 bp, vec2 bq) {
	if (det(aq - ap, bp - ap) * det(aq - ap, bq - ap) >= 0) return false;
	if (det(bq - bp, ap - bp) * det(bq - bp, aq - bp) >= 0) return false;
	return true;
}
// return the point of intersection
vec2 Intersect(vec2 P0, vec2 P1, vec2 d0, vec2 d1) {
	double t = det(d1, P1 - P0) / det(d1, d0);
	return P0 + d0 * t;
}


#include <vector>
typedef vector<vec2> polygon;

// # return the area of a polygon, negative when vertexes ordered clockwise
double calcArea(const polygon &p) {
	double A = 0;
	for (int i = 0, n = p.size(); i < n; i++) {
		A += det(p[i], p[(i + 1) % n]);
	}
	return 0.5*A;
}



// $ cut a polygon, where dot(p-p0,n)>0 part is cut off
polygon cutPolygonFromPlane(const polygon &fig, vec2 p0, vec2 n) {
	const double c = dot(p0, n);
	int l = fig.size();
	polygon res;

	// find a point that will not be cut off
	int d0;
	for (d0 = 0; d0 < l; d0++) {
		if (dot(fig[d0], n) < c) break;
	}
	if (d0 >= l) return res;  // the whole shape is cut off

	// trace segment
	auto intersect = [](vec2 p, vec2 q, const double &d, const vec2 &n)->vec2 {
		q = q - p;
		double t = (d - dot(n, p)) / dot(n, q);   // sometimes NAN
		return p + q * t;
	};
	for (int i = 0, d = d0, e = (d + 1) % l; i < l; i++, d = e, e = (e + 1) % l) {
		if (dot(fig[d], n) < c) {
			if (dot(fig[e], n) <= c) res.push_back(fig[e]);
			else res.push_back(intersect(fig[d], fig[e], c, n));
		}
		else {
			if (dot(fig[e], n) > c);
			else {
				res.push_back(intersect(fig[d], fig[e], c, n));
				res.push_back(fig[e]);
			}
		}
	}

	return res;
}



double calcUA(polygon A, polygon B) {
	A = cutPolygonFromPlane(A, B[0], (B[1] - B[0]).rot());
	A = cutPolygonFromPlane(A, B[1], (B[2] - B[1]).rot());
	return calcArea(A);
}

double testTriangle(double a0, double b0, double c0, double a1, double b1, double c1) {
	double ct = (a0*a0 + c0 * c0 - b0 * b0) / (2.0*a0*c0), st = sqrt(1.0 - ct * ct);
	polygon T0({ vec2(0,0), vec2(a0*ct,a0*st), vec2(c0,0) });
	ct = (a1*a1 + c1 * c1 - b1 * b1) / (2.0*a1*c1), st = sqrt(1.0 - ct * ct);
	polygon T({ vec2(0,0), vec2(a1*ct,a1*st), vec2(c1,0) });
	double x0 = -c1, x1 = c0;
	auto f = [&](double d)->double {
		return abs(calcUA(T0, polygon({ T[0] + vec2(d,0), T[1] + vec2(d,0), T[2] + vec2(d,0) })));
	};
	auto maxima = [&](double x0, double x1) {
		double x, u1, u2, y0, y1, y, v1, v2;
		for (int i = 0; i < 15; i++) {
			x = 0.5*(x0 + x1), u1 = 0.5*(x0 + x), u2 = 0.5*(x + x1);
			y0 = f(x0), v1 = f(u1), y = f(x), v2 = f(u2), y1 = f(x1);
			if (y0 >= v1) x0 = x0, x1 = u1;
			else if (v1 >= y) x0 = x0, x1 = x;
			else if (y >= v2) x0 = u1, x1 = u2;
			else if (v2 >= y1) x0 = x, x1 = x1;
			else x0 = u2, x1 = x1;
			if (x0 == x1) break;
		}
		return f(0.5*(x0 + x1));
	};
	int N = 17; double dx = (x1 - x0) / N;
	double my = 0;
	for (int i = 0; i < N; i++) {
		double y = maxima(x0 + i * dx, x0 + (i + 1)*dx);
		if (y > my) my = y;
	}
	return my;
}

#include <iostream>
int main() {
	double A[3], B[3];
	cin >> A[0] >> A[1] >> A[2] >> B[0] >> B[1] >> B[2];
	double s = 0.5*(A[0] + A[1] + A[2]);
	double SA = sqrt(s*(s - A[0])*(s - A[1])*(s - A[2]));
	s = 0.5*(B[0] + B[1] + B[2]);
	double SB = sqrt(s*(s - B[0])*(s - B[1])*(s - B[2]));
	double mu = 0;
	for (int i0 = 0; i0 < 3; i0++) for (int j0 = 0; j0 < 3; j0++) if (j0 != i0) for (int k0 = 0; k0 < 3; k0++) if (k0 != i0 && k0 != j0) {
		for (int i1 = 0; i1 < 3; i1++) for (int j1 = 0; j1 < 3; j1++) if (j1 != i1) for (int k1 = 0; k1 < 3; k1++) if (k1 != i1 && k1 != j1) {
			double u = testTriangle(A[i0], A[j0], A[k0], B[i1], B[j1], B[k1]);
			if (u > mu) mu = u;
		}
	}
	printf("%.16lf\n", SA + SB - mu);
}