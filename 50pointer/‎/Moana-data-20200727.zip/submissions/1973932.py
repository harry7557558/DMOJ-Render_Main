R, C = [int(t) for t in raw_input().split()]
i0, j0 = [int(t) for t in raw_input().split()]
i1, j1 = [int(t) for t in raw_input().split()]
S = s = []
INF = float('inf')
for i in range(R):
    S.append([c for c in raw_input()])
    for j in range(C):
        if S[i][j]=='O': S[i][j]=INF
T = [[False for i in range(C)] for j in range(R)]
Tn = int(input())
for t in range(Tn):
    i, j = raw_input().split()
    T[int(i)][int(j)] = True

import sys
def dbgPrint(k):
    for i in range(R):
        for j in range(C):
            sys.stdout.write(str(k[i][j])[0])
        sys.stdout.write('\n')
    sys.stdout.write('\n')

S[i0][j0] = 0
D0 = 0
D1 = INF
while S[i1][j1]==INF:
    for i in range(R):
        for j in range(C):
            if S[i][j]==INF:
                if i>0 and S[i-1][j]==D0:
                    S[i][j]=D0+1
                if j>0 and S[i][j-1]==D0:
                    S[i][j]=D0+1
                if i+1<R and S[i+1][j]==D0:
                    S[i][j]=D0+1
                if j+1<C and S[i][j+1]==D0:
                    S[i][j]=D0+1
                if S[i][j]!=INF and T[i][j] and D1==INF:
                    D1 = S[i][j]
    D0 = D0 + 1
    #dbgPrint(S)
D0 = S[i1][j1]

print(D0-D1)