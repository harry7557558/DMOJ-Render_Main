import os
subs = os.listdir("submissions/")
infos = open("submissions_info.txt").read().strip().split('\n')

if len(subs)!=len(infos):
    raise (len(subs), len(infos))

def comp(s1, s2):
    s1 = s1.replace('.txt','')
    s2 = s2.replace('.txt','')
    return int(s1)-int(s2)
subs = sorted(subs, key=__import__('functools').cmp_to_key(comp))
print(subs)

N = len(subs)

fp = open("README.md", "w")
fp.write("# List of fully AC Text submissions to https://dmoj.ca/problem/piggy\n\n")

for i in range(N):
    fp.write(infos[i] + "\n\n")
    fp.write("```\n" + open('submissions/'+subs[i]).read() + "\n```\n\n")

fp.close()
