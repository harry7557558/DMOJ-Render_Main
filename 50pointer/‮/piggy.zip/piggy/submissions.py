import json
page_1 = json.loads(open("submissions_page=1.json").read())
page_2 = json.loads(open("submissions_page=2.json").read())

submissions = page_1['data']['objects'] + page_2['data']['objects']

fp = open("submissions.txt", "w")
fp_info = open("submissions_info.txt", "w")

for sub in submissions:
    if sub['points']==7.0:
        sub_id = sub['id']
        fp.write(str(sub_id) + ',')
        fp_info.write(f"Submission {sub_id} by {sub['user']} at {sub['date']}\n")

fp.close()
fp_info.close()
