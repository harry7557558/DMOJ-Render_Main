import requests
import time

submission_ids = open("submissions.txt").read().split(',')

for sub_id in submission_ids:
    print(sub_id, end=' ')
    url = f"https://dmoj.ca/src/{sub_id}/raw"

    r = requests.get(url, headers={
        'Authorization': 'Bearer AADu2C4M3_TUf2fCpYQN6synGrM3g3FAqrFE4SNmilFAL4yN'})
    
    print(r.status_code)

    open(f"submissions/{sub_id}.txt", "wb").write(r.content)

    # got captcha'd for forgetting this line
    time.sleep(2)

